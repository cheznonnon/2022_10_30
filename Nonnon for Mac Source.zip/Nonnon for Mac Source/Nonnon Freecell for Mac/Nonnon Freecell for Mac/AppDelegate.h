//
//  AppDelegate.h
//  Nonnon Freecell for Mac
//
//  Created by のんのん on 2022/07/20.
//

#import <Cocoa/Cocoa.h>

@interface AppDelegate : NSObject <NSApplicationDelegate>


@end

