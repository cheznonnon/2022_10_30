//
//  AppDelegate.m
//  Nonnon Paint for Mac
//
//  Created by のんのん on 2022/09/13.
//

#import "AppDelegate.h"



#include "../../nonnon/neutral/bmp/all.c"
#include "../../nonnon/neutral/curico.c"
#include "../../nonnon/neutral/jpg.c"


#include "../../nonnon/mac/_mac.c"
#include "../../nonnon/mac/draw.c"
#include "../../nonnon/mac/image.c"
#include "../../nonnon/mac/window.c"

#include "../../nonnon/mac/n_button.c"
#include "../../nonnon/mac/n_scrollbar.c"
#include "../../nonnon/mac/n_txtbox.c"




void
n_paint_bmp_carboncopy( n_bmp *f, n_bmp *t )
{
//return;

	n_bmp_free( t );
	n_bmp_carboncopy( f, t );


	return;
}




#define N_PAINT_ID_PENSIZE (  1 )
#define N_PAINT_ID_MIX     (  2 )
#define N_PAINT_ID_BOOST   (  3 )
#define N_PAINT_ID_AIR     (  4 )
#define N_PAINT_ID_ZOOM    (  5 )
#define N_PAINT_ID_COLOR_A (  6 )
#define N_PAINT_ID_COLOR_R (  7 )
#define N_PAINT_ID_COLOR_G (  8 )
#define N_PAINT_ID_COLOR_B (  9 )
#define N_PAINT_ID_BLEND   ( 10 )

#define N_PAINT_ID_RESIZER_ROTATE     ( 100 )
#define N_PAINT_ID_RESIZER_GAMMA      ( 101 )
#define N_PAINT_ID_RESIZER_COLORWHEEL ( 102 )
#define N_PAINT_ID_RESIZER_VIVIDNESS  ( 103 )
#define N_PAINT_ID_RESIZER_SHARPNESS  ( 104 )
#define N_PAINT_ID_RESIZER_CONTRAST   ( 105 )

#define N_PAINT_ID_LAYER_BLUR         ( 200 )
#define N_PAINT_ID_LAYER_BLEND        ( 201 )

#define N_PAINT_ID_CLEAR_A ( 300 )
#define N_PAINT_ID_CLEAR_R ( 301 )
#define N_PAINT_ID_CLEAR_G ( 302 )
#define N_PAINT_ID_CLEAR_B ( 303 )

#define N_PAINT_ID_REPLACER_FR_A ( 400 )
#define N_PAINT_ID_REPLACER_FR_R ( 401 )
#define N_PAINT_ID_REPLACER_FR_G ( 402 )
#define N_PAINT_ID_REPLACER_FR_B ( 403 )
#define N_PAINT_ID_REPLACER_TO_A ( 404 )
#define N_PAINT_ID_REPLACER_TO_R ( 405 )
#define N_PAINT_ID_REPLACER_TO_G ( 406 )
#define N_PAINT_ID_REPLACER_TO_B ( 407 )

#define N_PAINT_ID_FORMATTER_CUR_X ( 500 )
#define N_PAINT_ID_FORMATTER_CUR_Y ( 501 )




void
n_paint_debug_save( n_bmp *bmp_save )
{

	if ( n_bmp_error( bmp_save ) ) 
	{
NSLog( @"n_paint_debug_save() : Error" );
		return;
	}


	NSArray      *paths   = NSSearchPathForDirectoriesInDomains( NSDesktopDirectory, NSUserDomainMask, YES );
	NSString     *desktop = [paths objectAtIndex:0];
	n_posix_char  tmpname[ 100 ]; n_string_path_tmpname( tmpname );
	NSString     *name    = [NSString stringWithFormat:@"%@/%s.png", desktop, tmpname];
//NSLog( @"%@", name );


	n_bmp bmp; n_bmp_carboncopy( bmp_save, &bmp );


	n_bmp_mac_color( &bmp );


	n_posix_char *str = n_mac_nsstring2str( name );

	n_png png = n_png_template;

	n_png_compress( &png, &bmp );
	n_png_save( &png, str );

	n_png_free( &png );

	n_memory_free( str );


	n_bmp_free( &bmp );


	return;
}

n_posix_bool
n_paint_load( n_posix_char *path, n_bmp *bmp, n_curico *curico )
{

	if ( n_posix_stat_is_dir( path ) ) { return n_posix_true; }

	if (
		( n_png_png2bmp( path, bmp ) )
		&&
		( n_jpg_jpg2bmp( path, bmp ) )
		&&
		( n_curico_load( curico, bmp, path ) )
		&&
		( n_bmp_load( bmp, path ) )
	)
	{
		return n_posix_true;
	} else {
		n_bmp_mac_color( bmp );
	}

// [!] : for debugging
//n_bmp_scaler_big( bmp, 2 );


	return n_posix_false;
}




#include "_bmp.c"

#include "canvas.c"
#include "save.c"
#include "xmouse.c"




void
n_paint_layer_select( n_paint *p, int index )
{

	p->layer_index = index;
//NSLog( @"%d", p->layer_index );

	p->pen_bmp_data = &p->layer_data[ p->layer_index ].bmp_data;
	p->pen_bmp_grab = &p->layer_data[ p->layer_index ].bmp_grab;

}




@interface NonnonPaintColorPreview : NSView

@property u32 *color;

@end


@implementation NonnonPaintColorPreview

@synthesize color;

- (instancetype)initWithCoder:(NSCoder *)coder
{
	self = [super initWithCoder:coder];

	if ( self )
	{
		color = NULL;
	}

	return self;
}

-(void) drawRect:(NSRect) rect
{
	NSColor *clr = n_mac_argb2nscolor( n_bmp_color_mac( *color ) );
	n_mac_draw_roundrect( clr, rect, 4 );
}

@end




@interface AppDelegate ()

@property (strong) IBOutlet NSWindow *window;

@property (strong) IBOutlet NonnonPaintStub *n_tool_stub;
@property (strong) IBOutlet NonnonPaintStub *n_layer_stub;
@property (strong) IBOutlet NonnonPaintStub *n_resizer_stub;


// Tool Window

@property (weak) IBOutlet NonnonPaintCanvas *n_paint_canvas;

@property (weak) IBOutlet NSWindow        *n_toolwindow;

@property (weak) IBOutlet NSTextField     *n_size_value;
@property (weak) IBOutlet NonnonScrollbar *n_size_scrollbar;

@property (weak) IBOutlet NSTextField     *n_mix_value;
@property (weak) IBOutlet NonnonScrollbar *n_mix_scrollbar;

@property (weak) IBOutlet NSTextField     *n_boost_value;
@property (weak) IBOutlet NonnonScrollbar *n_boost_scrollbar;

@property (weak) IBOutlet NSTextField     *n_air_value;
@property (weak) IBOutlet NonnonScrollbar *n_air_scrollbar;

@property (weak) IBOutlet NSTextField     *n_zoom_value;
@property (weak) IBOutlet NonnonScrollbar *n_zoom_scrollbar;

@property (weak) IBOutlet NonnonPaintColorPreview *n_color_preview;

@property (weak) IBOutlet NSTextField     *n_color_a_value;
@property (weak) IBOutlet NonnonScrollbar *n_color_a_scrollbar;

@property (weak) IBOutlet NSTextField     *n_color_r_value;
@property (weak) IBOutlet NonnonScrollbar *n_color_r_scrollbar;

@property (weak) IBOutlet NSTextField     *n_color_g_value;
@property (weak) IBOutlet NonnonScrollbar *n_color_g_scrollbar;

@property (weak) IBOutlet NSTextField     *n_color_b_value;
@property (weak) IBOutlet NonnonScrollbar *n_color_b_scrollbar;

@property (weak) IBOutlet NonnonButton    *n_button_0_0;
@property (weak) IBOutlet NonnonButton    *n_button_1_0;
@property (weak) IBOutlet NonnonButton    *n_button_2_0;
@property (weak) IBOutlet NonnonButton    *n_button_3_0;
@property (weak) IBOutlet NonnonButton    *n_button_4_0;

@property (weak) IBOutlet NonnonButton    *n_button_3_1;
@property (weak) IBOutlet NonnonButton    *n_button_4_1;

@property (weak) IBOutlet NonnonButton    *n_button_0_2;
@property (weak) IBOutlet NonnonButton    *n_button_1_2;
@property (weak) IBOutlet NonnonButton    *n_button_2_2;
@property (weak) IBOutlet NonnonButton    *n_button_4_2;

@property (weak) IBOutlet NSButton        *n_ppa_check;

@property (weak) IBOutlet NSTextField     *n_grabber_blend_label;
@property (weak) IBOutlet NSTextField     *n_grabber_blend_value;
@property (weak) IBOutlet NonnonScrollbar *n_grabber_blend_scrollbar;

@property (weak) IBOutlet NSTextField     *n_status1;
@property (weak) IBOutlet NSTextField     *n_status2;
@property (weak) IBOutlet NSTextField     *n_status3;


// Menu

@property (weak) IBOutlet NSMenuItem *n_menu_grid;
@property (weak) IBOutlet NSMenuItem *n_menu_pixelgrid;


// Resizer

@property (weak) IBOutlet NSWindow        *n_resizer_window;
@property (weak) IBOutlet NSComboBox      *n_resizer_combo;
@property (weak) IBOutlet NSTextField     *n_resizer_sx;
@property (weak) IBOutlet NSTextField     *n_resizer_sy;
@property (weak) IBOutlet NSTextField     *n_resizer_rotate_value;
@property (weak) IBOutlet NonnonScrollbar *n_resizer_rotate_scrollbar;
@property (weak) IBOutlet NSComboBox      *n_resizer_color_combobox;

@property (weak) IBOutlet NSTextField     *n_resizer_gamma_value;
@property (weak) IBOutlet NonnonScrollbar *n_resizer_gamma_scrollbar;

@property (weak) IBOutlet NSTextField     *n_resizer_colorwheel_value;
@property (weak) IBOutlet NonnonScrollbar *n_resizer_colorwheel_scrollbar;

@property (weak) IBOutlet NSTextField     *n_resizer_vividness_value;
@property (weak) IBOutlet NonnonScrollbar *n_resizer_vividness_scrollbar;

@property (weak) IBOutlet NSTextField     *n_resizer_sharpness_value;
@property (weak) IBOutlet NonnonScrollbar *n_resizer_sharpness_scrollbar;

@property (weak) IBOutlet NSTextField     *n_resizer_contrast_value;
@property (weak) IBOutlet NonnonScrollbar *n_resizer_contrast_scrollbar;

@property (weak) IBOutlet NSButton        *n_resizer_button_go;


// Formatter

@property (weak) IBOutlet NSWindow        *n_formatter_bmp_window;

@property (weak) IBOutlet NSWindow        *n_formatter_cur_window;

@property (weak) IBOutlet NSTextField     *n_formatter_cur_hotspot_x_value;
@property (weak) IBOutlet NonnonScrollbar *n_formatter_cur_hotspot_x_scrollbar;

@property (weak) IBOutlet NSTextField     *n_formatter_cur_hotspot_y_value;
@property (weak) IBOutlet NonnonScrollbar *n_formatter_cur_hotspot_y_scrollbar;

@property (weak) IBOutlet NSButton        *n_formatter_cur_button_go;

@property (weak) IBOutlet NonnonButton    *n_formatter_icon_cur;
@property (weak) IBOutlet NonnonButton    *n_formatter_icon_etc;


// Layer

@property (weak) IBOutlet NSWindow        *n_layer_window;

@property (weak) IBOutlet NonnonTxtbox    *n_layer_listbox;

@property (weak) IBOutlet NSButton        *n_layer_whole_preview_checkbox;
@property (weak) IBOutlet NSButton        *n_layer_whole_grab_checkbox;

@property (weak) IBOutlet NSTextField     *n_layer_blur_value;
@property (weak) IBOutlet NonnonScrollbar *n_layer_blur_scrollbar;

@property (weak) IBOutlet NSTextField     *n_layer_blend_value;
@property (weak) IBOutlet NonnonScrollbar *n_layer_blend_scrollbar;

@property (weak) IBOutlet NSMenu          *n_layer_popup_menu;
@property (weak) IBOutlet NSMenuItem      *n_layer_popup_menu_up;
@property (weak) IBOutlet NSMenuItem      *n_layer_popup_menu_down;



// Clear Canvas

@property (weak) IBOutlet NSWindow        *n_clear_window;

@property (weak) IBOutlet NonnonPaintColorPreview *n_clear_preview;

@property (weak) IBOutlet NSTextField     *n_clear_a_value;
@property (weak) IBOutlet NonnonScrollbar *n_clear_a_scrollbar;

@property (weak) IBOutlet NSTextField     *n_clear_r_value;
@property (weak) IBOutlet NonnonScrollbar *n_clear_r_scrollbar;

@property (weak) IBOutlet NSTextField     *n_clear_g_value;
@property (weak) IBOutlet NonnonScrollbar *n_clear_g_scrollbar;

@property (weak) IBOutlet NSTextField     *n_clear_b_value;
@property (weak) IBOutlet NonnonScrollbar *n_clear_b_scrollbar;

@property (weak) IBOutlet NSButton        *n_clear_go;


// Color Replacer

@property (weak) IBOutlet NSWindow        *n_replacer_window;

@property (weak) IBOutlet NonnonPaintColorPreview *n_replacer_fr_preview;

@property (weak) IBOutlet NSTextField     *n_replacer_fr_a_value;
@property (weak) IBOutlet NonnonScrollbar *n_replacer_fr_a_scrollbar;

@property (weak) IBOutlet NSTextField     *n_replacer_fr_r_value;
@property (weak) IBOutlet NonnonScrollbar *n_replacer_fr_r_scrollbar;

@property (weak) IBOutlet NSTextField     *n_replacer_fr_g_value;
@property (weak) IBOutlet NonnonScrollbar *n_replacer_fr_g_scrollbar;

@property (weak) IBOutlet NSTextField     *n_replacer_fr_b_value;
@property (weak) IBOutlet NonnonScrollbar *n_replacer_fr_b_scrollbar;

@property (weak) IBOutlet NonnonPaintColorPreview *n_replacer_to_preview;

@property (weak) IBOutlet NSTextField     *n_replacer_to_a_value;
@property (weak) IBOutlet NonnonScrollbar *n_replacer_to_a_scrollbar;

@property (weak) IBOutlet NSTextField     *n_replacer_to_r_value;
@property (weak) IBOutlet NonnonScrollbar *n_replacer_to_r_scrollbar;

@property (weak) IBOutlet NSTextField     *n_replacer_to_g_value;
@property (weak) IBOutlet NonnonScrollbar *n_replacer_to_g_scrollbar;

@property (weak) IBOutlet NSTextField     *n_replacer_to_b_value;
@property (weak) IBOutlet NonnonScrollbar *n_replacer_to_b_scrollbar;

@property (weak) IBOutlet NSButton        *n_replacer_go;


// Alpha Tweaker

@property (weak) IBOutlet NSWindow     *n_alpha_tweaker_window;

@property (weak) IBOutlet NonnonButton *n_alpha_tweaker_icon;

@property (weak) IBOutlet NSButton     *n_alpha_tweaker_clear_checkbox;
@property (weak) IBOutlet NSButton     *n_alpha_tweaker_reverse_checkbox;

@property (weak) IBOutlet NSButton     *n_alpha_tweaker_go;


@end




@implementation AppDelegate {

	n_paint paint;

	// Resizer

	int  resizer_rotate;
	int  resizer_gamma;
	BOOL resizer_is_ok;

}




- (void) NonnonSettings : (BOOL) is_read
{

	NSString *str;

	if ( is_read )
	{

		str = n_mac_settings_read( @"pensize" );
		if ( str.length == 0 ) { str = [NSString stringWithFormat:@"5"]; }
		paint.pensize = [str intValue];

		str = n_mac_settings_read( @"mix" );
		if ( str.length == 0 ) { str = [NSString stringWithFormat:@"10"]; }
		paint.mix = [str intValue];

		str = n_mac_settings_read( @"boost" );
		if ( str.length == 0 ) { str = [NSString stringWithFormat:@"0"]; }
		paint.boost = [str intValue];

		str = n_mac_settings_read( @"air" );
		if ( str.length == 0 ) { str = [NSString stringWithFormat:@"0"]; }
		paint.air = [str intValue];


		str = n_mac_settings_read( @"a" );
		if ( str.length == 0 ) { str = [NSString stringWithFormat:@"255"]; }
		int a = [str intValue];

		str = n_mac_settings_read( @"r" );
		if ( str.length == 0 ) { str = [NSString stringWithFormat:@"255"]; }
		int r = [str intValue];

		str = n_mac_settings_read( @"g" );
		if ( str.length == 0 ) { str = [NSString stringWithFormat:@"255"]; }
		int g = [str intValue];

		str = n_mac_settings_read( @"b" );
		if ( str.length == 0 ) { str = [NSString stringWithFormat:@"255"]; }
		int b = [str intValue];

		paint.color = n_bmp_argb_mac( a,r,g,b );

	} else {

		str = [NSString stringWithFormat:@"%d", paint.pensize];
		n_mac_settings_write( @"pensize", str );

		str = [NSString stringWithFormat:@"%d", paint.mix];
		n_mac_settings_write( @"mix", str );

		str = [NSString stringWithFormat:@"%d", paint.boost];
		n_mac_settings_write( @"boost", str );

		str = [NSString stringWithFormat:@"%d", paint.air];
		n_mac_settings_write( @"air", str );


		str = [NSString stringWithFormat:@"%d", n_bmp_a( paint.color )];
		n_mac_settings_write( @"a", str );

		str = [NSString stringWithFormat:@"%d", n_bmp_b( paint.color )];
		n_mac_settings_write( @"r", str );

		str = [NSString stringWithFormat:@"%d", n_bmp_g( paint.color )];
		n_mac_settings_write( @"g", str );

		str = [NSString stringWithFormat:@"%d", n_bmp_r( paint.color )];
		n_mac_settings_write( @"b", str );

	}

}




- (void) NonnonTxtbox_delegate_edited:(id)txtbox onoff:(BOOL)onoff;
{
}

- (void) NonnonTxtbox_delegate_find
{
}

- (void) NonnonTxtbox_delegate_listbox_edited : (n_type_int) i;
{
//NSLog( @"%s", paint.layer_data[ i ].name );

	n_posix_char *str = n_txt_get( _n_layer_listbox.n_txt_data, i );

	n_paint_layer_text_mod( &paint, i, &str[ 3 ] );

}

- (void) NonnonDragAndDrop_dropped : (NSString*) nsstr
{

	if ( paint.readonly ) { return; }


	n_posix_char *str = n_mac_nsstring2str( nsstr );
//NSLog( @"%@", nsstr );

	if ( n_paint_layer_load( &paint, str ) )
	{
		if ( paint.tooltype == N_PAINT_TOOL_TYPE_GRABBER )
		{
			n_bmp    bmp; n_bmp_zero( &bmp );
			n_curico curico; n_curico_zero( &curico );
			n_paint_load( str, &bmp, &curico );

			n_paint_grabber_select( &bmp, TRUE );

			paint.grabber_mode = N_PAINT_GRABBER_DRAG_OK;
		} else
		if ( n_paint_load( str, &paint.bmp_data, &paint.curico ) )
		{
			//
		} else {
			paint.filename = nsstr;
			n_bmp_free( &paint.bmp_grab );

			[self NonnonPaintTitle];

			paint.scroll = NSMakePoint( 0, 0 );
			[self NonnonPaintResize];

			[self NonnonPaintResizerReset];

			n_mac_window_hide( _n_layer_window );
		}
	} else {
//NSLog( @"layer" );

		n_bmp_free( &paint.bmp_data );
		n_bmp_free( &paint.bmp_grab );

		[self NonnonPaintLayerSelect:paint.layer_index];


		n_posix_char *newname = n_string_alloccopy( n_posix_strlen( str ) * 2, str );
		n_string_path_ext_add( ".lyr\0\0", newname );
//NSLog( @"%s", newname );

		paint.filename = n_mac_str2nsstring( newname );
		
		n_string_path_free( newname );


		[self NonnonPaintTitle];

		paint.scroll = NSMakePoint( 0, 0 );
		[self NonnonPaintResize];

		[self NonnonPaintResizerReset];

		[_n_paint_canvas n_paint_canvas_reset_cache];


		_n_layer_listbox.n_focus = paint.layer_index;
//NSLog( @"%f", _n_layer_listbox.n_focus );

		[_n_layer_listbox NonnonTxtboxFocus2Caret];
		[_n_layer_listbox NonnonTxtboxCaretOutOfCanvasUpDown];

		[_n_layer_listbox display];


		[self NonnonPaintLayerRefresh];

		n_mac_window_show( _n_layer_window );

	}

	[self NonnonPaintIconDisplay:_n_button_4_1];

	n_string_free( str );

}




- (void) NonnonPaintTitle
{

	n_type_gfx bmpsx = N_BMP_SX( paint.pen_bmp_data );
	n_type_gfx bmpsy = N_BMP_SY( paint.pen_bmp_data );

	NSString *fname;

	if ( paint.layer_onoff )
	{
		fname = [paint.filename stringByDeletingPathExtension];
	} else {
		fname = paint.filename;
	}

	NSString *title = [NSString stringWithFormat:@"%@ (%d x %d)", fname, bmpsx, bmpsy];
	[_window setTitle:title];

}

- (void) NonnonPaintZoomUI
{

	if ( paint.zoom > 0 )
	{
		[_n_zoom_value setIntegerValue:paint.zoom];
	} else {
		NSString *nsstr = [NSString stringWithFormat:@"1/%d", paint.zoom * -1];
		[_n_zoom_value setStringValue:nsstr];
	}

	[_n_paint_canvas display_optimized];

}

- (void) NonnonPaintResize
{

	CGFloat sx = N_BMP_SX( &paint.bmp_data );
	CGFloat sy = N_BMP_SY( &paint.bmp_data );

	CGFloat dsx,dsy; n_mac_desktop_size( &dsx, &dsy );

	{
//NSLog( @"%0.2f %0.2f", dsx, dsy );

		sx = dsx * 0.6;
		sy = dsy * 0.6;

		paint.inner_sx = sx;
		paint.inner_sy = sy;

		paint.margin = n_posix_min_n_type_real( dsx, dsy ) * 0.1;

		sx += paint.margin;
		sy += paint.margin;
	}

	[self NonnonPaintZoomUI];

	[_window setContentSize:NSMakeSize( sx,sy )];
	n_mac_window_centering( _window );

	[_n_paint_canvas setFrame:NSMakeRect( 0,0,sx,sy )];
	[_n_paint_canvas display_optimized];

}

- (void) NonnonPaintColorSet
{

	int a = n_bmp_a( paint.color );
	int r = n_bmp_r( paint.color );
	int g = n_bmp_g( paint.color );
	int b = n_bmp_b( paint.color );
//NSLog( @"%d %d %d %d", a,r,g,b );

	[_n_color_a_value setIntegerValue:a];
	[_n_color_r_value setIntegerValue:b];
	[_n_color_g_value setIntegerValue:g];
	[_n_color_b_value setIntegerValue:r];

	[_n_color_a_scrollbar n_scrollbar_position_set:a redraw:YES];
	[_n_color_r_scrollbar n_scrollbar_position_set:b redraw:YES];
	[_n_color_g_scrollbar n_scrollbar_position_set:g redraw:YES];
	[_n_color_b_scrollbar n_scrollbar_position_set:r redraw:YES];


	[_n_color_preview display];

}

- (void) NonnonPaintClearCanvasColorSet
{

	int a = n_bmp_a( paint.clear_color );
	int r = n_bmp_r( paint.clear_color );
	int g = n_bmp_g( paint.clear_color );
	int b = n_bmp_b( paint.clear_color );
//NSLog( @"%d %d %d %d", a,r,g,b );

	[_n_clear_a_value setIntegerValue:a];
	[_n_clear_r_value setIntegerValue:b];
	[_n_clear_g_value setIntegerValue:g];
	[_n_clear_b_value setIntegerValue:r];

	[_n_clear_a_scrollbar n_scrollbar_position_set:a redraw:YES];
	[_n_clear_r_scrollbar n_scrollbar_position_set:b redraw:YES];
	[_n_clear_g_scrollbar n_scrollbar_position_set:g redraw:YES];
	[_n_clear_b_scrollbar n_scrollbar_position_set:r redraw:YES];


	[_n_color_preview display];

}

- (void) NonnonPaintColorReplacerColorSet
{

	{

		int a = n_bmp_a( paint.replacer_fr_color );
		int r = n_bmp_r( paint.replacer_fr_color );
		int g = n_bmp_g( paint.replacer_fr_color );
		int b = n_bmp_b( paint.replacer_fr_color );
//NSLog( @"%d %d %d %d", a,r,g,b );

		[_n_replacer_fr_a_value setIntegerValue:a];
		[_n_replacer_fr_r_value setIntegerValue:b];
		[_n_replacer_fr_g_value setIntegerValue:g];
		[_n_replacer_fr_b_value setIntegerValue:r];

		[_n_replacer_fr_a_scrollbar n_scrollbar_position_set:a redraw:YES];
		[_n_replacer_fr_r_scrollbar n_scrollbar_position_set:b redraw:YES];
		[_n_replacer_fr_g_scrollbar n_scrollbar_position_set:g redraw:YES];
		[_n_replacer_fr_b_scrollbar n_scrollbar_position_set:r redraw:YES];

		[_n_replacer_fr_preview display];

	}

	{

		int a = n_bmp_a( paint.replacer_to_color );
		int r = n_bmp_r( paint.replacer_to_color );
		int g = n_bmp_g( paint.replacer_to_color );
		int b = n_bmp_b( paint.replacer_to_color );
//NSLog( @"%d %d %d %d", a,r,g,b );

		[_n_replacer_to_a_value setIntegerValue:a];
		[_n_replacer_to_r_value setIntegerValue:b];
		[_n_replacer_to_g_value setIntegerValue:g];
		[_n_replacer_to_b_value setIntegerValue:r];

		[_n_replacer_to_a_scrollbar n_scrollbar_position_set:a redraw:YES];
		[_n_replacer_to_r_scrollbar n_scrollbar_position_set:b redraw:YES];
		[_n_replacer_to_g_scrollbar n_scrollbar_position_set:g redraw:YES];
		[_n_replacer_to_b_scrollbar n_scrollbar_position_set:r redraw:YES];

		[_n_replacer_to_preview display];

	}

}

- (void) NonnonPaintGrabberUIOnOff:(BOOL)onoff
{

	NSColor *color;
	if ( onoff )
	{
		color = [NSColor textColor];
	} else {
		color = [NSColor secondarySelectedControlColor];
	}

	[_n_ppa_check            setEnabled  :onoff];
	[_n_grabber_blend_label  setTextColor:color];
	[_n_grabber_blend_value  setTextColor:color];
	[_n_grabber_blend_scrollbar n_scrollbar_enable:onoff redraw:YES];

}

- (void) NonnonPaintStatus
{
//return;

	n_posix_char str1[ 100 ];
	n_posix_char str2[ 100 ];
	n_posix_char str3[ 100 ];

	if ( paint.tooltype == N_PAINT_TOOL_TYPE_PEN )
	{

		n_posix_sprintf_literal( str1, "Pen" );

		NSPoint pt = [_n_paint_canvas n_paint_canvaspos];
		n_posix_sprintf_literal( str2, "X:%0.0f", pt.x );
		n_posix_sprintf_literal( str3, "Y:%0.0f", pt.y );

	} else
	if ( paint.tooltype == N_PAINT_TOOL_TYPE_FILL )
	{

		n_posix_sprintf_literal( str1, "Fill" );

		NSPoint pt = [_n_paint_canvas n_paint_canvaspos];
		n_posix_sprintf_literal( str2, "X:%0.0f", pt.x );
		n_posix_sprintf_literal( str3, "Y:%0.0f", pt.y );

	} else
	if ( paint.tooltype == N_PAINT_TOOL_TYPE_GRABBER )
	{

		if ( paint.grabber_mode == N_PAINT_GRABBER_NEUTRAL )
		{
			n_posix_sprintf_literal( str1, "Neutral" );
		} else
		if ( paint.grabber_mode == N_PAINT_GRABBER_SELECTING )
		{
			n_posix_sprintf_literal( str1, "Selecting" );
		} else
		if ( paint.grabber_mode == N_PAINT_GRABBER_DRAG_OK )
		{
			n_posix_sprintf_literal( str1, "Drag OK" );
		} else
		if ( paint.grabber_mode == N_PAINT_GRABBER_DRAGGING )
		{
			n_posix_sprintf_literal( str1, "Dragging" );
		} else {
			n_posix_sprintf_literal( str1, "N/A" );
		}


		n_type_gfx x,y,sx,sy,fx,fy;

		if ( paint.grabber_mode == N_PAINT_GRABBER_NEUTRAL )
		{
			x = y = sx = sy = fx = fy = 0;
		} else {
			n_paint_grabber_system_get( &x,&y, &sx,&sy, &fx,&fy );
		}

		n_posix_sprintf_literal( str2, "X:%d Y:%d", x,y );
		n_posix_sprintf_literal( str3, "%d x %d", sx,sy );

	}

	[_n_status1 setStringValue:n_mac_str2nsstring( str1 )];
	[_n_status2 setStringValue:n_mac_str2nsstring( str2 )];
	[_n_status3 setStringValue:n_mac_str2nsstring( str3 )];


	return;
}

- (void) NonnonPaintResizerReset
{

	[_n_resizer_combo selectItemAtIndex:2];


	n_type_gfx bmpsx;
	n_type_gfx bmpsy;

//NSLog( @"%d", n_paint_global.paint->grabber_mode );
	if ( n_paint_global.paint->grabber_mode == N_PAINT_GRABBER_NEUTRAL )
	{
		bmpsx = N_BMP_SX( paint.pen_bmp_data );
		bmpsy = N_BMP_SY( paint.pen_bmp_data );
	} else {
		bmpsx = N_BMP_SX( paint.pen_bmp_grab );
		bmpsy = N_BMP_SY( paint.pen_bmp_grab );
	}

	[_n_resizer_sx setEnabled:TRUE];
	[_n_resizer_sy setEnabled:TRUE];

	NSNumberFormatter *formatter = [[NSNumberFormatter alloc] init];
	formatter.hasThousandSeparators = NO;

	[_n_resizer_sx setFormatter:formatter];
	[_n_resizer_sy setFormatter:formatter];

	[_n_resizer_sx setStringValue:[NSString stringWithFormat:@"%d", bmpsx]];
	[_n_resizer_sy setStringValue:[NSString stringWithFormat:@"%d", bmpsy]];


	resizer_rotate = 360;

	_n_resizer_rotate_scrollbar.delegate = self;
	[_n_resizer_rotate_scrollbar n_scrollbar_parameter:N_PAINT_ID_RESIZER_ROTATE step:1 page:10 max:720 pos:resizer_rotate redraw:n_posix_true];

	[self NonnonScrollbarMessage:N_PAINT_ID_RESIZER_ROTATE value:resizer_rotate];


	[_n_resizer_color_combobox selectItemAtIndex:0];

	resizer_gamma = 10;
	_n_resizer_gamma_scrollbar.delegate = self;
	[_n_resizer_gamma_scrollbar n_scrollbar_parameter:N_PAINT_ID_RESIZER_GAMMA step:1 page:5 max:20 pos:resizer_gamma redraw:n_posix_true];
	[_n_resizer_gamma_value setIntegerValue:resizer_gamma];

	[self NonnonScrollbarMessage:N_PAINT_ID_RESIZER_GAMMA value:resizer_gamma];

	_n_resizer_colorwheel_scrollbar.delegate = self;
	[_n_resizer_colorwheel_scrollbar n_scrollbar_parameter:N_PAINT_ID_RESIZER_COLORWHEEL step:1 page:10 max:256 pos:128 redraw:n_posix_true];
	[_n_resizer_colorwheel_value setIntegerValue:0];

	_n_resizer_vividness_scrollbar.delegate = self;
	[_n_resizer_vividness_scrollbar n_scrollbar_parameter:N_PAINT_ID_RESIZER_VIVIDNESS step:1 page:10 max:200 pos:100 redraw:n_posix_true];
	[_n_resizer_vividness_value setIntegerValue:0];

	_n_resizer_sharpness_scrollbar.delegate = self;
	[_n_resizer_sharpness_scrollbar n_scrollbar_parameter:N_PAINT_ID_RESIZER_SHARPNESS step:1 page:10 max:200 pos:100 redraw:n_posix_true];
	[_n_resizer_sharpness_value setIntegerValue:0];

	_n_resizer_contrast_scrollbar.delegate = self;
	[_n_resizer_contrast_scrollbar n_scrollbar_parameter:N_PAINT_ID_RESIZER_CONTRAST step:1 page:10 max:100 pos:0 redraw:n_posix_true];
	[_n_resizer_contrast_value setIntegerValue:0];


	n_paint_global.paint->grabber_rect_resizer = n_paint_global.paint->grabber_rect;


	resizer_is_ok = FALSE;


	return;
}

- (void) NonnonPaintIconSet:(NSString*) rc_name button:(NonnonButton*)button
{

	n_bmp bmp_icon; n_bmp_zero( &bmp_icon );

	n_mac_image_rc_load_bmp( rc_name, &bmp_icon );

	n_mac_button_system_themed( &bmp_icon );

	[button n_icon_set:&bmp_icon];

}

- (void) NonnonPaintIconDisplay:(NonnonButton*)button
{

	n_posix_char *path = n_mac_nsstring2str( paint.filename );

	if ( n_string_path_ext_is_same_literal( ".BMP\0\0", path ) )
	{
		[self NonnonPaintIconSet:@"rc/save"     button:button];
	} else
	if ( n_string_path_ext_is_same_literal( ".ICO\0\0", path ) )
	{
		[self NonnonPaintIconSet:@"rc/save/ico" button:button];
	} else
	if ( n_string_path_ext_is_same_literal( ".CUR\0\0", path ) )
	{
		[self NonnonPaintIconSet:@"rc/save/cur" button:button];
	} else
	if ( n_string_path_ext_is_same_literal( ".JPG\0\0", path ) )
	{
		[self NonnonPaintIconSet:@"rc/save/jpg" button:button];
	} else
	if ( n_string_path_ext_is_same_literal( ".PNG\0\0", path ) )
	{
		[self NonnonPaintIconSet:@"rc/save/png" button:button];
	} else
	if ( n_string_path_ext_is_same_literal( ".LYR\0\0", path ) )
	{
		[self NonnonPaintIconSet:@"rc/save/lyr" button:button];
	}

	[button display];

	n_string_free( path );

}

- (void) NonnonPaintLayerSync
{

	n_type_int     index = paint.layer_index;
	n_paint_layer *layer = &paint.layer_data[ index ];

	_n_layer_listbox.n_focus = index;

	layer->blur    = (int) [_n_layer_blur_value  integerValue];
	layer->percent = (int) [_n_layer_blend_value integerValue];
	layer->blend   = (n_type_real) layer->percent * 0.01;

	[_n_paint_canvas display_optimized];

}

- (void) NonnonPaintLayerRefresh
{

	if ( paint.layer_onoff == FALSE ) { return; }


	n_type_int     index = paint.layer_index;
	n_paint_layer *layer = &paint.layer_data[ index ];

	_n_layer_listbox.n_focus = index;
	[_n_layer_listbox display];

	[_n_layer_blur_value  setIntegerValue:layer->blur   ];
	[_n_layer_blend_value setIntegerValue:layer->percent];

	[_n_layer_blur_scrollbar  n_scrollbar_position_set:layer->blur    redraw:YES];
	[_n_layer_blend_scrollbar n_scrollbar_position_set:layer->percent redraw:YES];

}

- (void) NonnonPaintLayerSelect:(int)index
{

	paint.layer_index = index;
//NSLog( @"%d", paint.layer_index );

	paint.pen_bmp_data = &paint.layer_data[ paint.layer_index ].bmp_data;
	paint.pen_bmp_grab = &paint.layer_data[ paint.layer_index ].bmp_grab;

}

- (void) NonnonPaintSave
{

	n_posix_char *path = n_mac_nsstring2str( paint.filename );

	if ( n_paint_save( path, &paint.bmp_data, &paint.curico ) )
	{
		// [!] : when error

		// [x] : crash without "App Sandbox" "User Selected File"

		NSString *name = [paint.filename lastPathComponent];

		NSSavePanel *panel = [NSSavePanel savePanel];
		[panel setNameFieldStringValue:name];
		[panel beginSheetModalForWindow:_window completionHandler:^(NSInteger result)
		{
			if ( result == NSModalResponseOK )
			{
				NSString     *nsstring = [[panel URL] path];
				n_posix_char *str      = n_mac_nsstring2str( nsstring );
//NSLog( @"Saved : %s", str );
				n_paint_save( str, &self->paint.bmp_data, &self->paint.curico );

				self->paint.filename = nsstring;
				[self NonnonPaintTitle];

				n_string_free( str );
			}

		}];

	}

	n_string_free( path );

}




- (void)awakeFromNib
{

	// [!] : Global

	n_bmp_safemode = n_posix_false;


	// [!] : Instance

	n_paint_zero( &paint );

	paint.scroller_size = 12;


	// [!] : Resources

	paint.cursor_arrow = [NSCursor arrowCursor];
	paint.cursor_no    = [NSCursor operationNotAllowedCursor];
	paint.cursor_hand  = [NSCursor closedHandCursor];

	{
		n_bmp bmp; n_bmp_zero( &bmp );
		n_mac_image_rc_load_bmp( @"rc/cursor/pen", &bmp );

		NSImage *img = n_mac_image_nbmp2nsimage( &bmp );

		int hotspot_x = N_BMP_SX( &bmp ) / 2; hotspot_x--;
		int hotspot_y = N_BMP_SY( &bmp ) / 2; hotspot_y--;

		paint.cursor_pen_off = [[NSCursor alloc] initWithImage:img hotSpot:NSMakePoint( hotspot_x, hotspot_y )];

		n_bmp_free_fast( &bmp );
	}

	{
		n_bmp bmp; n_bmp_zero( &bmp );
		n_mac_image_rc_load_bmp( @"rc/cursor/pen_on", &bmp );

		NSImage *img = n_mac_image_nbmp2nsimage( &bmp );

		int hotspot_x = N_BMP_SX( &bmp ) / 2; hotspot_x--;
		int hotspot_y = N_BMP_SY( &bmp ) / 2; hotspot_y--;

		paint.cursor_pen_on = [[NSCursor alloc] initWithImage:img hotSpot:NSMakePoint( hotspot_x, hotspot_y )];

		n_bmp_free_fast( &bmp );
	}

	{
		n_bmp bmp; n_bmp_zero( &bmp );
		n_mac_image_rc_load_bmp( @"rc/cursor/eraser", &bmp );

		NSImage *img = n_mac_image_nbmp2nsimage( &bmp );

		int hotspot_x = N_BMP_SX( &bmp ) / 2; hotspot_x--;
		int hotspot_y = N_BMP_SY( &bmp ) / 2; hotspot_y--;

		paint.cursor_eraser = [[NSCursor alloc] initWithImage:img hotSpot:NSMakePoint( hotspot_x, hotspot_y )];

		n_bmp_free_fast( &bmp );
	}


	// [!] : Tool Window : Settings

	paint.color = n_bmp_rgb_mac( 0,200,255 );

	[self NonnonSettings:YES];


	// [!] : XMouse

	_n_tool_stub = [[NonnonPaintStub alloc] init];
	[_n_tool_stub setFrame:[[NSScreen mainScreen] frame]];
	[[_n_toolwindow contentView] addSubview:_n_tool_stub];

	_n_tool_stub.delegate = self;


	_n_layer_stub = [[NonnonPaintStub alloc] init];
	[_n_layer_stub setFrame:[[NSScreen mainScreen] frame]];
	[[_n_layer_window contentView] addSubview:_n_layer_stub];

	_n_layer_stub.delegate = self;


	_n_resizer_stub = [[NonnonPaintStub alloc] init];
	[_n_resizer_stub setFrame:[[NSScreen mainScreen] frame]];
	[[_n_resizer_window contentView] addSubview:_n_resizer_stub];

	_n_resizer_stub.delegate = self;


	// [!] : Tool Window

	paint.tooltype = N_PAINT_TOOL_TYPE_PEN;
	//paint.tooltype = N_PAINT_TOOL_TYPE_FILL;
	//paint.tooltype = N_PAINT_TOOL_TYPE_GRABBER;

	paint.zoom     = 1;
	paint.scroll   = NSMakePoint( 0, 0 );

	_n_size_scrollbar.delegate = self;
	[_n_size_scrollbar  n_scrollbar_parameter:N_PAINT_ID_PENSIZE step:1 page:10 max:100 pos:paint.pensize redraw:n_posix_true];
	[_n_size_value  setIntegerValue:paint.pensize + 1];

	_n_mix_scrollbar.delegate = self;
	[_n_mix_scrollbar   n_scrollbar_parameter:N_PAINT_ID_MIX     step:1 page:10 max:100 pos:paint.mix     redraw:n_posix_true];
	[_n_mix_value  setIntegerValue:paint.mix];

	_n_boost_scrollbar.delegate = self;
	[_n_boost_scrollbar n_scrollbar_parameter:N_PAINT_ID_BOOST   step:1 page:10 max:100 pos:paint.boost   redraw:n_posix_true];
	[_n_boost_value  setIntegerValue:paint.boost];

	_n_air_scrollbar.delegate = self;
	[_n_air_scrollbar   n_scrollbar_parameter:N_PAINT_ID_AIR     step:1 page:10 max:100 pos:paint.air     redraw:n_posix_true];
	[_n_air_value  setIntegerValue:paint.air];

	_n_zoom_scrollbar.delegate = self;
	[_n_zoom_scrollbar  n_scrollbar_parameter:N_PAINT_ID_ZOOM    step:1 page:10 max:100 pos:paint.zoom+50 redraw:n_posix_true];
	[_n_zoom_value  setIntegerValue:paint.zoom];


	_n_color_preview.color = &paint.color;

	[self NonnonPaintColorSet];

	_n_color_a_scrollbar.delegate = self;
	_n_color_r_scrollbar.delegate = self;
	_n_color_g_scrollbar.delegate = self;
	_n_color_b_scrollbar.delegate = self;

	[_n_color_a_scrollbar n_scrollbar_parameter:N_PAINT_ID_COLOR_A step:1 page:10 max:255 pos:n_bmp_a( paint.color ) redraw:n_posix_true];
	[_n_color_r_scrollbar n_scrollbar_parameter:N_PAINT_ID_COLOR_R step:1 page:10 max:255 pos:n_bmp_b( paint.color ) redraw:n_posix_true];
	[_n_color_g_scrollbar n_scrollbar_parameter:N_PAINT_ID_COLOR_G step:1 page:10 max:255 pos:n_bmp_g( paint.color ) redraw:n_posix_true];
	[_n_color_b_scrollbar n_scrollbar_parameter:N_PAINT_ID_COLOR_B step:1 page:10 max:255 pos:n_bmp_r( paint.color ) redraw:n_posix_true];

	[_n_color_r_scrollbar n_scrollbar_gradient:nil from:n_bmp_black to:n_bmp_rgb_mac( 255,0,0 )];
	[_n_color_g_scrollbar n_scrollbar_gradient:nil from:n_bmp_black to:n_bmp_rgb_mac( 0,255,0 )];
	[_n_color_b_scrollbar n_scrollbar_gradient:nil from:n_bmp_black to:n_bmp_rgb_mac( 0,0,255 )];


	{
		[self NonnonPaintIconSet:@"rc/small" button:_n_button_0_0];

		[_n_button_0_0 n_enable:TRUE];

		[_n_button_0_0 n_border:TRUE];
		[_n_button_0_0 n_direct_click:YES];

		_n_button_0_0.delegate = self;
	}

	{
		[self NonnonPaintIconSet:@"rc/large" button:_n_button_1_0];

		[_n_button_1_0 n_enable:TRUE];
		
		[_n_button_1_0 n_border:TRUE];
		[_n_button_1_0 n_direct_click:YES];

		_n_button_1_0.delegate = self;
	}

	{
		[self NonnonPaintIconSet:@"rc/mirror" button:_n_button_2_0];

		[_n_button_2_0 n_enable:TRUE];

		[_n_button_2_0 n_border:TRUE];
		[_n_button_2_0 n_direct_click:YES];

		_n_button_2_0.delegate = self;
	}

	{
		[self NonnonPaintIconSet:@"rc/rotate_left" button:_n_button_3_0];

		[_n_button_3_0 n_enable:TRUE];

		[_n_button_3_0 n_border:TRUE];
		[_n_button_3_0 n_direct_click:YES];

		_n_button_3_0.delegate = self;
	}

	{
		[self NonnonPaintIconSet:@"rc/rotate_right" button:_n_button_4_0];

		[_n_button_4_0 n_enable:TRUE];

		[_n_button_4_0 n_border:TRUE];
		[_n_button_4_0 n_direct_click:YES];

		_n_button_4_0.delegate = self;
	}

	{
		[self NonnonPaintIconSet:@"rc/new" button:_n_button_3_1];

		[_n_button_3_1 n_enable:TRUE];

		[_n_button_3_1 n_border:TRUE];
		[_n_button_3_1 n_direct_click:YES];

		_n_button_3_1.delegate = self;
	}

	{
		[self NonnonPaintIconSet:@"rc/save/png" button:_n_button_4_1];

		[_n_button_4_1 n_enable:TRUE];

		[_n_button_4_1 n_border:TRUE];
		[_n_button_4_1 n_direct_click:YES];

		_n_button_4_1.delegate = self;
	}

	{
		[self NonnonPaintIconSet:@"rc/pen" button:_n_button_0_2];

		[_n_button_0_2 n_enable:TRUE];

		[_n_button_0_2 n_border:TRUE];
		[_n_button_0_2 n_direct_click:YES];

		[_n_button_0_2 n_press:TRUE];

		_n_button_0_2.delegate = self;
	}

	{
		[self NonnonPaintIconSet:@"rc/brush" button:_n_button_1_2];

		[_n_button_1_2 n_enable:TRUE];

		[_n_button_1_2 n_border:TRUE];
		[_n_button_1_2 n_direct_click:YES];

		_n_button_1_2.delegate = self;
	}

	{
		[self NonnonPaintIconSet:@"rc/grabber" button:_n_button_2_2];

		[_n_button_2_2 n_enable:TRUE];

		[_n_button_2_2 n_border:TRUE];
		[_n_button_2_2 n_direct_click:YES];

		_n_button_2_2.delegate = self;
	}

	{
		[self NonnonPaintIconSet:@"rc/color" button:_n_button_4_2];

		[_n_button_4_2 n_enable:TRUE];

		[_n_button_4_2 n_border:TRUE];
		[_n_button_4_2 n_direct_click:YES];

		_n_button_4_2.delegate = self;
	}

	_n_grabber_blend_scrollbar.delegate = self;
	[_n_grabber_blend_scrollbar n_scrollbar_parameter:N_PAINT_ID_BLEND step:1 page:10 max:100 pos:paint.grabber_blend redraw:n_posix_true];
	[_n_grabber_blend_value setIntegerValue:paint.grabber_blend];

	[self NonnonPaintGrabberUIOnOff:FALSE];


	{
		NSArray      *paths   = NSSearchPathForDirectoriesInDomains( NSDesktopDirectory, NSUserDomainMask, YES );
		NSString     *desktop = [paths objectAtIndex:0];
		n_posix_char  tmpname[ 100 ]; n_string_path_tmpname( tmpname );

		paint.filename = [NSString stringWithFormat:@"%@/%s.png", desktop, tmpname];
//NSLog( @"%@", path );
	}

	n_bmp_new_fast( &paint.bmp_data, 512,512 );
	n_bmp_flush( &paint.bmp_data, n_bmp_white );

	paint.pen_bmp_data = &paint.bmp_data;
	paint.pen_bmp_grab = &paint.bmp_grab;

	_n_paint_canvas.delegate = self;
	_n_paint_canvas.paint    = &paint;

	[self NonnonPaintResize];
	[self NonnonPaintStatus];
	[self NonnonPaintTitle];


	// Resizer

	paint.resizer_onoff = FALSE;

	[self NonnonPaintResizerReset];


	// Formatter

	_n_formatter_cur_hotspot_x_scrollbar.delegate = self;
	[_n_formatter_cur_hotspot_x_scrollbar n_scrollbar_parameter:N_PAINT_ID_FORMATTER_CUR_X step:1 page:10 max:255 pos:paint.curico.hotspotx redraw:n_posix_true];
	[_n_formatter_cur_hotspot_x_value setIntegerValue:paint.curico.hotspotx];

	_n_formatter_cur_hotspot_y_scrollbar.delegate = self;
	[_n_formatter_cur_hotspot_y_scrollbar n_scrollbar_parameter:N_PAINT_ID_FORMATTER_CUR_Y step:1 page:10 max:255 pos:paint.curico.hotspoty redraw:n_posix_true];
	[_n_formatter_cur_hotspot_y_value setIntegerValue:paint.curico.hotspoty];

	[_n_formatter_icon_cur n_enable:TRUE]; [_n_formatter_icon_cur n_border:TRUE];
	[_n_formatter_icon_etc n_enable:TRUE]; [_n_formatter_icon_etc n_border:TRUE];


	// Layer

	paint.layer_onoff = false;
	paint.layer_count = N_PAINT_LAYER_MAX;

	paint.layer_data  = n_memory_new( sizeof( n_paint_layer ) * paint.layer_count );
	n_memory_zero( paint.layer_data, sizeof( n_paint_layer ) * paint.layer_count );

	_n_layer_listbox.delegate            = self;
	_n_layer_listbox.n_mode              = N_MAC_TXTBOX_MODE_LISTBOX;
	_n_layer_listbox.n_txt_data          = &paint.layer_txt;
	_n_layer_listbox.n_focus             = 0;
	_n_layer_listbox.n_option_linenumber = N_MAC_TXTBOX_DRAW_LINENUMBER_ZEROBASED_INDEX;
	_n_layer_listbox.n_decoration_onoff  = TRUE;

	NSFont *font = [NSFont systemFontOfSize:15 weight:NSFontWeightRegular];
	[_n_layer_listbox NonnonTxtboxFontChange:font];

	[_n_layer_listbox NonnonTxtboxReset];

	_n_layer_blur_scrollbar.delegate  = self;
	_n_layer_blend_scrollbar.delegate = self;

	[_n_layer_blur_scrollbar  n_scrollbar_parameter:N_PAINT_ID_LAYER_BLUR  step:1 page: 2 max: 10 pos:0 redraw:n_posix_true];
	[_n_layer_blend_scrollbar n_scrollbar_parameter:N_PAINT_ID_LAYER_BLEND step:1 page:10 max:100 pos:0 redraw:n_posix_true];

	_n_paint_canvas.txtbox = _n_layer_listbox;


	// Clear Canvas

	_n_clear_preview.color = &paint.clear_color;

	_n_clear_a_scrollbar.delegate = self;
	_n_clear_r_scrollbar.delegate = self;
	_n_clear_g_scrollbar.delegate = self;
	_n_clear_b_scrollbar.delegate = self;

	[_n_clear_a_scrollbar n_scrollbar_parameter:N_PAINT_ID_CLEAR_A step:1 page:10 max:255 pos:n_bmp_a( paint.clear_color ) redraw:n_posix_true];
	[_n_clear_r_scrollbar n_scrollbar_parameter:N_PAINT_ID_CLEAR_R step:1 page:10 max:255 pos:n_bmp_b( paint.clear_color ) redraw:n_posix_true];
	[_n_clear_g_scrollbar n_scrollbar_parameter:N_PAINT_ID_CLEAR_G step:1 page:10 max:255 pos:n_bmp_g( paint.clear_color ) redraw:n_posix_true];
	[_n_clear_b_scrollbar n_scrollbar_parameter:N_PAINT_ID_CLEAR_B step:1 page:10 max:255 pos:n_bmp_r( paint.clear_color ) redraw:n_posix_true];

	[_n_clear_r_scrollbar n_scrollbar_gradient:nil from:n_bmp_black to:n_bmp_rgb_mac( 255,0,0 )];
	[_n_clear_g_scrollbar n_scrollbar_gradient:nil from:n_bmp_black to:n_bmp_rgb_mac( 0,255,0 )];
	[_n_clear_b_scrollbar n_scrollbar_gradient:nil from:n_bmp_black to:n_bmp_rgb_mac( 0,0,255 )];


	// Color Replacer

	_n_replacer_fr_preview.color = &paint.replacer_fr_color;

	_n_replacer_fr_a_scrollbar.delegate = self;
	_n_replacer_fr_r_scrollbar.delegate = self;
	_n_replacer_fr_g_scrollbar.delegate = self;
	_n_replacer_fr_b_scrollbar.delegate = self;

	[_n_replacer_fr_a_scrollbar n_scrollbar_parameter:N_PAINT_ID_REPLACER_FR_A step:1 page:10 max:255 pos:n_bmp_a( paint.replacer_fr_color ) redraw:n_posix_true];
	[_n_replacer_fr_r_scrollbar n_scrollbar_parameter:N_PAINT_ID_REPLACER_FR_R step:1 page:10 max:255 pos:n_bmp_b( paint.replacer_fr_color ) redraw:n_posix_true];
	[_n_replacer_fr_g_scrollbar n_scrollbar_parameter:N_PAINT_ID_REPLACER_FR_G step:1 page:10 max:255 pos:n_bmp_g( paint.replacer_fr_color ) redraw:n_posix_true];
	[_n_replacer_fr_b_scrollbar n_scrollbar_parameter:N_PAINT_ID_REPLACER_FR_B step:1 page:10 max:255 pos:n_bmp_r( paint.replacer_fr_color ) redraw:n_posix_true];

	[_n_replacer_fr_r_scrollbar n_scrollbar_gradient:nil from:n_bmp_black to:n_bmp_rgb_mac( 255,0,0 )];
	[_n_replacer_fr_g_scrollbar n_scrollbar_gradient:nil from:n_bmp_black to:n_bmp_rgb_mac( 0,255,0 )];
	[_n_replacer_fr_b_scrollbar n_scrollbar_gradient:nil from:n_bmp_black to:n_bmp_rgb_mac( 0,0,255 )];

	_n_replacer_to_preview.color = &paint.replacer_to_color;

	_n_replacer_to_a_scrollbar.delegate = self;
	_n_replacer_to_r_scrollbar.delegate = self;
	_n_replacer_to_g_scrollbar.delegate = self;
	_n_replacer_to_b_scrollbar.delegate = self;

	[_n_replacer_to_a_scrollbar n_scrollbar_parameter:N_PAINT_ID_REPLACER_TO_A step:1 page:10 max:255 pos:n_bmp_a( paint.replacer_to_color ) redraw:n_posix_true];
	[_n_replacer_to_r_scrollbar n_scrollbar_parameter:N_PAINT_ID_REPLACER_TO_R step:1 page:10 max:255 pos:n_bmp_b( paint.replacer_to_color ) redraw:n_posix_true];
	[_n_replacer_to_g_scrollbar n_scrollbar_parameter:N_PAINT_ID_REPLACER_TO_G step:1 page:10 max:255 pos:n_bmp_g( paint.replacer_to_color ) redraw:n_posix_true];
	[_n_replacer_to_b_scrollbar n_scrollbar_parameter:N_PAINT_ID_REPLACER_TO_B step:1 page:10 max:255 pos:n_bmp_r( paint.replacer_to_color ) redraw:n_posix_true];

	[_n_replacer_to_r_scrollbar n_scrollbar_gradient:nil from:n_bmp_black to:n_bmp_rgb_mac( 255,0,0 )];
	[_n_replacer_to_g_scrollbar n_scrollbar_gradient:nil from:n_bmp_black to:n_bmp_rgb_mac( 0,255,0 )];
	[_n_replacer_to_b_scrollbar n_scrollbar_gradient:nil from:n_bmp_black to:n_bmp_rgb_mac( 0,0,255 )];


	// Alpha Tweaker

	{
		[self NonnonPaintIconSet:@"rc/switch" button:_n_alpha_tweaker_icon];

		[_n_alpha_tweaker_icon n_enable:TRUE];
		[_n_alpha_tweaker_icon n_border:TRUE];
	}


	// Window

	[_window setAcceptsMouseMovedEvents:YES];

	// [Needed] : set every time
	[_window addChildWindow:_n_toolwindow     ordered:NSWindowAbove];
	[_window addChildWindow:_n_resizer_window ordered:NSWindowAbove];
	[_window addChildWindow:_n_layer_window   ordered:NSWindowAbove];

	[[NSNotificationCenter defaultCenter]
	      addObserver: self
		 selector: @selector( windowWillClose: )
		     name: NSWindowWillCloseNotification
		   object: nil
	];

}

- (void) windowWillClose:(NSNotification *)notification
{
//NSLog( @"closed" );

	NSWindow *window = notification.object;
	if ( window == self.window )
	{
		[self NonnonSettings:NO];

		[NSApp terminate:self];
	} else
	if ( window == _n_resizer_window )
	{
		[self NonnonPaintResizerExit:resizer_is_ok];

		n_mac_window_show( _n_toolwindow     );
		n_mac_window_hide( _n_resizer_window );

		// [Needed] : set every time
		[_window addChildWindow:_n_toolwindow ordered:NSWindowAbove];

//NSLog( @"Layer On/Off : %d", paint.layer_onoff );
		if ( paint.layer_onoff )
		{
			[_window addChildWindow:_n_layer_window ordered:NSWindowAbove];
		} else {
			n_mac_window_hide( _n_layer_window );
		}

		if ( resizer_is_ok == FALSE )
		{
			n_paint_global.paint->grabber_rect = n_paint_global.paint->grabber_rect_resizer;
		}

		paint.readonly      = FALSE;
		paint.resizer_onoff = FALSE;

		[_n_paint_canvas display_optimized];
	}

}




- (void)applicationWillFinishLaunching:(NSNotification *)aNotification {
	// Insert code here to initialize your application
}

- (void)applicationDidFinishLaunching:(NSNotification *)aNotification {
	// Insert code here to initialize your application

//NSRect rect_window = [_window frame];
//NSLog( @"Window : %f %f", NSWidth( rect_window ), NSHeight( rect_window ) );

//NSRect rect_canvas = [_n_paint_canvas frame];
//NSLog( @"Canvas : %f %f", NSWidth( rect_canvas ), NSHeight( rect_canvas ) );

	[_window makeKeyWindow];

	n_mac_window_centering( _window );
}


- (void)applicationWillTerminate:(NSNotification *)aNotification {
	// Insert code here to tear down your application
}




- (void) keyDown : (NSEvent*) event
{
//NSLog( @"Key Code = %d", event.keyCode );

	switch( event.keyCode ) {

	case N_MAC_KEYCODE_F2: 
	{

		// [!] : fork

		n_posix_char *str = n_mac_nsstring2str( paint.filename );
		n_posix_char *dir = n_string_path_upperfolder_new( str );
		n_posix_char *ext = n_string_path_ext_get_new( str );
		n_posix_char *nam = n_string_path_tmpname_new( ext );
		n_posix_char *tmp = n_string_path_make_new( dir, nam );

		paint.filename = [NSString stringWithFormat:@"%s", tmp];

		n_string_free( str );
		n_string_free( dir );
		n_string_free( ext );
		n_string_free( nam );
		n_string_free( tmp );

		[self NonnonPaintTitle];
	}
	break;

	} // switch

}




- (IBAction)n_menu_grid_method:(NSMenuItem *)sender {

	NSControlStateValue s = [_n_menu_grid state];
	if ( s == NSControlStateValueOff )
	{
		[_n_menu_grid setState:NSControlStateValueOn];
		paint.grid_onoff = TRUE;
	} else {
		[_n_menu_grid setState:NSControlStateValueOff];
		paint.grid_onoff = FALSE;
	}

	[_n_paint_canvas display_optimized];

}

- (IBAction)n_menu_pixelgrid_method:(id)sender {

	NSControlStateValue s = [_n_menu_pixelgrid state];
	if ( s == NSControlStateValueOff )
	{
		[_n_menu_pixelgrid setState:NSControlStateValueOn];
		paint.pixel_grid_onoff = TRUE;
	} else {
		[_n_menu_pixelgrid setState:NSControlStateValueOff];
		paint.pixel_grid_onoff = FALSE;
	}

	[_n_paint_canvas display_optimized];

}

- (IBAction)n_menu_clear_canvas_method:(id)sender {

	paint.clear_color = paint.color;
	[self NonnonPaintClearCanvasColorSet];

	n_mac_window_show( _n_clear_window );

}

- (IBAction)n_clear_go_method:(id)sender {

	u32 color = n_bmp_argb_mac(
		(int) [_n_clear_a_value integerValue],
		(int) [_n_clear_r_value integerValue],
		(int) [_n_clear_g_value integerValue],
		(int) [_n_clear_b_value integerValue]
	);

	if ( paint.grabber_mode == N_PAINT_GRABBER_NEUTRAL )
	{
		n_bmp_flush( paint.pen_bmp_data, color );
	} else {
		n_bmp_flush( paint.pen_bmp_grab, color );
	}

	[_n_paint_canvas display_optimized];

	n_mac_window_hide( _n_clear_window );

}

- (IBAction)n_replacer_method:(id)sender {

	paint.replacer_fr_color = paint.color;
	paint.replacer_to_color = paint.color;

	[self NonnonPaintColorReplacerColorSet];

	n_mac_window_show( _n_replacer_window );

}

- (IBAction)n_replacer_go_method:(id)sender {

	u32 color_fr = n_bmp_argb_mac(
		(int) [_n_replacer_fr_a_value integerValue],
		(int) [_n_replacer_fr_r_value integerValue],
		(int) [_n_replacer_fr_g_value integerValue],
		(int) [_n_replacer_fr_b_value integerValue]
	);

	u32 color_to = n_bmp_argb_mac(
		(int) [_n_replacer_to_a_value integerValue],
		(int) [_n_replacer_to_r_value integerValue],
		(int) [_n_replacer_to_g_value integerValue],
		(int) [_n_replacer_to_b_value integerValue]
	);

	if ( paint.grabber_mode == N_PAINT_GRABBER_NEUTRAL )
	{
		n_bmp_flush_replacer( paint.pen_bmp_data, color_fr, color_to );
	} else {
		n_bmp_flush_replacer( paint.pen_bmp_grab, color_fr, color_to );
	}

	[_n_paint_canvas display_optimized];

	n_mac_window_hide( _n_replacer_window );

}

- (IBAction)n_formatter_go_method:(NSButton *)sender {

	paint.curico.hotspotx = (int) [_n_formatter_cur_hotspot_x_value integerValue];
	paint.curico.hotspoty = (int) [_n_formatter_cur_hotspot_y_value integerValue];

	n_mac_window_hide( _n_formatter_cur_window );

	[self NonnonPaintSave];

}

- (IBAction)n_formatter_bmp_go_method:(id)sender {

	n_mac_window_hide( _n_formatter_bmp_window );

	[self NonnonPaintSave];

}

- (IBAction)n_menu_alpha_tweaker_method:(id)sender {

	n_mac_window_show( _n_alpha_tweaker_window );

}

- (IBAction)n_alpha_tweaker_go_method:(id)sender {

	NSControlStateValue state_clear   = [_n_alpha_tweaker_clear_checkbox state];
	NSControlStateValue state_reverse = [_n_alpha_tweaker_reverse_checkbox state];

	BOOL onoff_clear;
	BOOL onoff_reverse;

	if ( state_clear == NSControlStateValueOff )
	{
		onoff_clear = FALSE;
	} else {
		onoff_clear = TRUE;
	}

	if ( state_reverse == NSControlStateValueOff )
	{
		onoff_reverse = FALSE;
	} else {
		onoff_reverse = TRUE;
	}

//NSLog( @"Clear %d : Reverse %d", onoff_clear, onoff_reverse );

	if ( onoff_clear )
	{
//NSLog( @"Clear" );
		n_paint_layer_bmp_alpha( N_PAINT_FILTER_ALPHA_CLR );
		[_n_paint_canvas display_optimized];
	}

	if ( onoff_reverse )
	{
//NSLog( @"Reverse" );
		n_paint_layer_bmp_alpha( N_PAINT_FILTER_ALPHA_REV );
		[_n_paint_canvas display_optimized];
	}


	n_mac_window_hide( _n_alpha_tweaker_window );

}

- (IBAction)n_menu_readme:(id)sender {

	NSString *helpFilePath = [[NSBundle mainBundle] pathForResource:@"nonnon_paint" ofType:@"html"];
	NSURL    *helpFileURL  = [NSURL fileURLWithPath:helpFilePath];

	[[NSWorkspace sharedWorkspace] openURL:helpFileURL];

}



- (void) NonnonScrollbarMessage:(int) id  value:(int) v
{

	if ( id == N_PAINT_ID_PENSIZE )
	{
		paint.pensize = v;
		[_n_size_value setIntegerValue:paint.pensize + 1];
	} else
	if ( id == N_PAINT_ID_MIX )
	{
		paint.mix = v;
		[_n_mix_value setIntegerValue:paint.mix];
	} else
	if ( id == N_PAINT_ID_BOOST )
	{
		paint.boost = v;
		[_n_boost_value setIntegerValue:paint.boost];
	} else
	if ( id == N_PAINT_ID_AIR )
	{
		paint.air = v;
		[_n_air_value setIntegerValue:paint.air];
	} else
	if ( id == N_PAINT_ID_ZOOM )
	{
		static int prev = 1;

		paint.zoom = v - 50;

		if ( ( paint.zoom == 0 )||( paint.zoom == -1 ) )
		{
			if ( prev > 0 ) { paint.zoom = -2; } else { paint.zoom = 1; }
		}

		prev = paint.zoom;

		[self NonnonPaintZoomUI];
	} else
	if ( id == N_PAINT_ID_COLOR_A )
	{
		[_n_color_a_value setIntegerValue:v];

		int a = v;
		int r = n_bmp_b( paint.color );
		int g = n_bmp_g( paint.color );
		int b = n_bmp_r( paint.color );

		paint.color = n_bmp_argb_mac( a,r,g,b );

		[_n_color_preview display];
	} else
	if ( id == N_PAINT_ID_COLOR_R )
	{
		[_n_color_r_value setIntegerValue:v];

		int a = n_bmp_a( paint.color );
		int r = v;
		int g = n_bmp_g( paint.color );
		int b = n_bmp_r( paint.color );

		paint.color = n_bmp_argb_mac( a,r,g,b );

		[_n_color_preview display];
	} else
	if ( id == N_PAINT_ID_COLOR_G )
	{
		[_n_color_g_value setIntegerValue:v];

		int a = n_bmp_a( paint.color );
		int r = n_bmp_b( paint.color );
		int g = v;
		int b = n_bmp_r( paint.color );

		paint.color = n_bmp_argb_mac( a,r,g,b );

		[_n_color_preview display];
	} else
	if ( id == N_PAINT_ID_COLOR_B )
	{
		[_n_color_b_value setIntegerValue:v];

		int a = n_bmp_a( paint.color );
		int r = n_bmp_b( paint.color );
		int g = n_bmp_g( paint.color );
		int b = v;

		paint.color = n_bmp_argb_mac( a,r,g,b );

		[_n_color_preview display];
	} else
	if ( id == N_PAINT_ID_BLEND )
	{
		paint.grabber_blend = v;
		[_n_grabber_blend_value setIntegerValue:paint.grabber_blend];

		paint.grabber_blend_ratio = (double) paint.grabber_blend * 0.01;

		[_n_paint_canvas display_optimized];
	} else
	if ( id == N_PAINT_ID_RESIZER_ROTATE )
	{
		resizer_rotate = v;

		NSString *nsstr = [NSString stringWithFormat:@"%d°", resizer_rotate-360];
		[_n_resizer_rotate_value setStringValue:nsstr];

		[self n_resizer_go];
	} else
	if ( id == N_PAINT_ID_RESIZER_GAMMA )
	{
		resizer_gamma = v;

		NSString *nsstr = [NSString stringWithFormat:@"%0.1f", (double) ( resizer_gamma - 10 ) * 0.1];
		[_n_resizer_gamma_value setStringValue:nsstr];

		[self n_resizer_go];
	} else
	if ( id == N_PAINT_ID_RESIZER_COLORWHEEL )
	{
		[_n_resizer_colorwheel_value setIntegerValue:v - 128];
		[self n_resizer_go];
	} else
	if ( id == N_PAINT_ID_RESIZER_VIVIDNESS )
	{
		[_n_resizer_vividness_value setIntegerValue:v - 100];
		[self n_resizer_go];
	} else
	if ( id == N_PAINT_ID_RESIZER_SHARPNESS )
	{
		[_n_resizer_sharpness_value setIntegerValue:v - 100];
		[self n_resizer_go];
	} else
	if ( id == N_PAINT_ID_RESIZER_CONTRAST )
	{
		[_n_resizer_contrast_value setIntegerValue:v];
		[self n_resizer_go];
	} else
	if ( id == N_PAINT_ID_FORMATTER_CUR_X )
	{
		[_n_formatter_cur_hotspot_x_value setIntegerValue:v];
	} else
	if ( id == N_PAINT_ID_FORMATTER_CUR_Y )
	{
		[_n_formatter_cur_hotspot_y_value setIntegerValue:v];
	} else
	if ( id == N_PAINT_ID_LAYER_BLUR )
	{
		[_n_layer_blur_value setIntegerValue:v];
		[self NonnonPaintLayerSync];
	} else
	if ( id == N_PAINT_ID_LAYER_BLEND )
	{
		[_n_layer_blend_value setIntegerValue:v];
		[self NonnonPaintLayerSync];
	} else
	if ( id == N_PAINT_ID_CLEAR_A )
	{
		[_n_clear_a_value setIntegerValue:v];

		int a = v;
		int r = n_bmp_b( paint.clear_color );
		int g = n_bmp_g( paint.clear_color );
		int b = n_bmp_r( paint.clear_color );

		paint.clear_color = n_bmp_argb_mac( a,r,g,b );

		[_n_clear_preview display];
	} else
	if ( id == N_PAINT_ID_CLEAR_R )
	{
		[_n_clear_r_value setIntegerValue:v];

		int a = n_bmp_a( paint.clear_color );
		int r = v;
		int g = n_bmp_g( paint.clear_color );
		int b = n_bmp_r( paint.clear_color );

		paint.clear_color = n_bmp_argb_mac( a,r,g,b );

		[_n_clear_preview display];
	} else
	if ( id == N_PAINT_ID_CLEAR_G )
	{
		[_n_clear_g_value setIntegerValue:v];

		int a = n_bmp_a( paint.clear_color );
		int r = n_bmp_b( paint.clear_color );
		int g = v;
		int b = n_bmp_r( paint.clear_color );

		paint.clear_color = n_bmp_argb_mac( a,r,g,b );

		[_n_clear_preview display];
	} else
	if ( id == N_PAINT_ID_CLEAR_B )
	{
		[_n_clear_b_value setIntegerValue:v];

		int a = n_bmp_a( paint.clear_color );
		int r = n_bmp_b( paint.clear_color );
		int g = n_bmp_g( paint.clear_color );
		int b = v;

		paint.clear_color = n_bmp_argb_mac( a,r,g,b );

		[_n_clear_preview display];
	} else

	if ( id == N_PAINT_ID_REPLACER_FR_A )
	{
		[_n_replacer_fr_a_value setIntegerValue:v];

		int a = v;
		int r = n_bmp_b( paint.replacer_fr_color );
		int g = n_bmp_g( paint.replacer_fr_color );
		int b = n_bmp_r( paint.replacer_fr_color );

		paint.replacer_fr_color = n_bmp_argb_mac( a,r,g,b );

		[_n_replacer_fr_preview display];
	} else
	if ( id == N_PAINT_ID_REPLACER_FR_R )
	{
		[_n_replacer_fr_r_value setIntegerValue:v];

		int a = n_bmp_a( paint.replacer_fr_color );
		int r = v;
		int g = n_bmp_g( paint.replacer_fr_color );
		int b = n_bmp_r( paint.replacer_fr_color );

		paint.replacer_fr_color = n_bmp_argb_mac( a,r,g,b );

		[_n_replacer_fr_preview display];
	} else
	if ( id == N_PAINT_ID_REPLACER_FR_G )
	{
		[_n_replacer_fr_g_value setIntegerValue:v];

		int a = n_bmp_a( paint.replacer_fr_color );
		int r = n_bmp_b( paint.replacer_fr_color );
		int g = v;
		int b = n_bmp_r( paint.replacer_fr_color );

		paint.replacer_fr_color = n_bmp_argb_mac( a,r,g,b );

		[_n_replacer_fr_preview display];
	} else
	if ( id == N_PAINT_ID_REPLACER_FR_B )
	{
		[_n_replacer_fr_b_value setIntegerValue:v];

		int a = n_bmp_a( paint.replacer_fr_color );
		int r = n_bmp_b( paint.replacer_fr_color );
		int g = n_bmp_g( paint.replacer_fr_color );
		int b = v;

		paint.replacer_fr_color = n_bmp_argb_mac( a,r,g,b );

		[_n_replacer_fr_preview display];
	} else

	if ( id == N_PAINT_ID_REPLACER_TO_A )
	{
		[_n_replacer_to_a_value setIntegerValue:v];

		int a = v;
		int r = n_bmp_b( paint.replacer_to_color );
		int g = n_bmp_g( paint.replacer_to_color );
		int b = n_bmp_r( paint.replacer_to_color );

		paint.replacer_to_color = n_bmp_argb_mac( a,r,g,b );

		[_n_replacer_to_preview display];
	} else
	if ( id == N_PAINT_ID_REPLACER_TO_R )
	{
		[_n_replacer_to_r_value setIntegerValue:v];

		int a = n_bmp_a( paint.replacer_to_color );
		int r = v;
		int g = n_bmp_g( paint.replacer_to_color );
		int b = n_bmp_r( paint.replacer_to_color );

		paint.replacer_to_color = n_bmp_argb_mac( a,r,g,b );

		[_n_replacer_to_preview display];
	} else
	if ( id == N_PAINT_ID_REPLACER_TO_G )
	{
		[_n_replacer_to_g_value setIntegerValue:v];

		int a = n_bmp_a( paint.replacer_to_color );
		int r = n_bmp_b( paint.replacer_to_color );
		int g = v;
		int b = n_bmp_r( paint.replacer_to_color );

		paint.replacer_to_color = n_bmp_argb_mac( a,r,g,b );

		[_n_replacer_to_preview display];
	} else
	if ( id == N_PAINT_ID_REPLACER_TO_B )
	{
		[_n_replacer_to_b_value setIntegerValue:v];

		int a = n_bmp_a( paint.replacer_to_color );
		int r = n_bmp_b( paint.replacer_to_color );
		int g = n_bmp_g( paint.replacer_to_color );
		int b = v;

		paint.replacer_to_color = n_bmp_argb_mac( a,r,g,b );

		[_n_replacer_to_preview display];
	}// else
}




- (void) n_toolwindow_mouseUp:(NSEvent*) theEvent
{

	if ( _n_toolwindow.keyWindow == FALSE ) { return; }

	if ( n_mac_window_is_hovered( _n_button_0_0 ) )
	{
		n_paint_grabber_filter( N_PAINT_FILTER_SCALE_LIL );
		[_n_paint_canvas display_optimized];
		[self NonnonPaintTitle];
	} else
	if ( n_mac_window_is_hovered( _n_button_1_0 ) )
	{
		n_paint_grabber_filter( N_PAINT_FILTER_SCALE_BIG );
		[_n_paint_canvas display_optimized];
		[self NonnonPaintTitle];
	} else
	if ( n_mac_window_is_hovered( _n_button_2_0 ) )
	{
		n_paint_grabber_filter( N_PAINT_FILTER_MIRROR );
		[_n_paint_canvas display_optimized];
	} else
	if ( n_mac_window_is_hovered( _n_button_3_0 ) )
	{
		n_paint_grabber_filter( N_PAINT_FILTER_ROTATE_L );
		[_n_paint_canvas display_optimized];
		[self NonnonPaintTitle];
	} else
	if ( n_mac_window_is_hovered( _n_button_4_0 ) )
	{
		n_paint_grabber_filter( N_PAINT_FILTER_ROTATE_R );
		[_n_paint_canvas display_optimized];
		[self NonnonPaintTitle];
	} else

	if ( n_mac_window_is_hovered( _n_button_3_1 ) )
	{

		[self NonnonPaintResizerReset];
		[self NonnonPaintResizerInit ];

		n_mac_window_hide( _n_toolwindow     );
		n_mac_window_show( _n_resizer_window );

		// [Needed] : set every time
		[_window addChildWindow:_n_resizer_window ordered:NSWindowAbove];

		// [Needed] : hide always
//NSLog( @"Layer On/Off : %d", paint.layer_onoff );
		if ( paint.layer_onoff )
		{
			n_mac_window_hide( _n_layer_window );
		} else {
			n_mac_window_hide( _n_layer_window );
		}

		paint.readonly      = TRUE;
		paint.resizer_onoff = TRUE;

//NSLog( @"%d", paint.readonly );
	} else
	if ( n_mac_window_is_hovered( _n_button_4_1 ) )
	{

		n_posix_char *path = n_mac_nsstring2str( paint.filename );

		if ( n_string_path_ext_is_same_literal( ".CUR\0\0", path ) )
		{
			[_n_formatter_cur_hotspot_x_value setIntegerValue:paint.curico.hotspotx];
			[_n_formatter_cur_hotspot_y_value setIntegerValue:paint.curico.hotspoty];

			[_n_formatter_cur_hotspot_x_scrollbar n_scrollbar_position_set:paint.curico.hotspotx redraw:YES];
			[_n_formatter_cur_hotspot_y_scrollbar n_scrollbar_position_set:paint.curico.hotspotx redraw:YES];

			[self NonnonPaintIconDisplay:_n_formatter_icon_cur];
			n_mac_window_show( _n_formatter_cur_window );
		} else {
			[self NonnonPaintIconDisplay:_n_formatter_icon_etc];
			n_mac_window_show( _n_formatter_bmp_window );
		}

		n_string_free( path );

	} else
	if ( n_mac_window_is_hovered( _n_button_0_2 ) )
	{
//NSLog( @"%d", _n_toolwindow.keyWindow );

		[self NonnonPaintIconSet:@"rc/grabber" button:_n_button_2_2];

		if ( n_paint_global.paint->grabber_mode == N_PAINT_GRABBER_NEUTRAL )
		{
			[self NonnonPaintGrabberUIOnOff:FALSE];
		}

		paint.tooltype = N_PAINT_TOOL_TYPE_PEN;

		[_n_button_0_2 n_press: TRUE]; [_n_button_0_2 display];
		[_n_button_1_2 n_press:FALSE]; [_n_button_1_2 display];
		[_n_button_2_2 n_press:FALSE]; [_n_button_2_2 display];

		[self NonnonPaintStatus];
	} else
	if ( n_mac_window_is_hovered( _n_button_1_2 ) )
	{
		[self NonnonPaintIconSet:@"rc/grabber" button:_n_button_2_2];

		if ( n_paint_global.paint->grabber_mode == N_PAINT_GRABBER_NEUTRAL )
		{
			[self NonnonPaintGrabberUIOnOff:FALSE];
		}

		paint.tooltype = N_PAINT_TOOL_TYPE_FILL;

		[_n_button_0_2 n_press:FALSE]; [_n_button_0_2 display];
		[_n_button_1_2 n_press: TRUE]; [_n_button_1_2 display];
		[_n_button_2_2 n_press:FALSE]; [_n_button_2_2 display];

		[self NonnonPaintStatus];
	} else
	if ( n_mac_window_is_hovered( _n_button_2_2 ) )
	{
		[self NonnonPaintIconSet:@"rc/grabber_close" button:_n_button_2_2];

		[self NonnonPaintGrabberUIOnOff:TRUE];

		if ( paint.tooltype == N_PAINT_TOOL_TYPE_GRABBER )
		{
			n_paint_grabber_reset();
		}

		paint.tooltype = N_PAINT_TOOL_TYPE_GRABBER;

		[_n_button_0_2 n_press:FALSE]; [_n_button_0_2 display];
		[_n_button_1_2 n_press:FALSE]; [_n_button_1_2 display];
		[_n_button_2_2 n_press: TRUE]; [_n_button_2_2 display];

		[self NonnonPaintStatus];
	} else
	if ( n_mac_window_is_hovered( _n_button_4_2 ) )
	{
//NSLog( @"!" );
		NSColorPanel *cp = [NSColorPanel sharedColorPanel];
		[cp setTarget:self];
		cp.showsAlpha = YES;
		[cp orderFront:nil];
		[cp setAction:@selector(colorUpdate:)];

	}// else
}

- (void) n_layer_window_mouseUp:(NSEvent*) theEvent
{

	if ( _n_layer_window.keyWindow == FALSE ) { return; }

	if ( n_mac_window_is_hovered( _n_layer_listbox ) )
	{

		[self NonnonPaintLayerSelect:_n_layer_listbox.n_focus];

		if ( [theEvent clickCount] == 2 )
		{
			if ( paint.layer_whole_grab_onoff ) { return; }

			n_posix_char *str = n_txt_get( &paint.layer_txt, paint.layer_index );

			if ( paint.layer_data[ paint.layer_index ].visible )
			{
				paint.layer_data[ paint.layer_index ].visible = FALSE;
				if ( 3 <= n_posix_strlen( str ) ) { str[ 1 ] = ' '; }
			} else {
				paint.layer_data[ paint.layer_index ].visible = TRUE;
				if ( 3 <= n_posix_strlen( str ) ) { str[ 1 ] = 'B'; }
			}

			[_n_paint_canvas display_optimized];
		}

		[self NonnonPaintLayerRefresh];

	}

}

- (void) mouseUp:(NSEvent*) theEvent
{
//NSLog(@"mouseUp");

	[self n_toolwindow_mouseUp:theEvent];
	[self n_layer_window_mouseUp:theEvent];

}

- (void) n_toolwindow_rightMouseUp:(NSEvent*) theEvent
{

	if ( _n_toolwindow.keyWindow == FALSE ) { return; }

	if ( n_mac_window_is_hovered( _n_button_4_1 ) )
	{

		n_posix_char *path = n_mac_nsstring2str( paint.filename );

		if ( n_string_path_ext_is_same_literal( ".BMP\0\0", path ) )
		{
			n_string_path_ext_mod_literal( ".ico\0\0", path );
		} else
		if ( n_string_path_ext_is_same_literal( ".ICO\0\0", path ) )
		{
			n_string_path_ext_mod_literal( ".cur\0\0", path );
		} else
		if ( n_string_path_ext_is_same_literal( ".CUR\0\0", path ) )
		{
			n_string_path_ext_mod_literal( ".jpg\0\0", path );
		} else
		if ( n_string_path_ext_is_same_literal( ".JPG\0\0", path ) )
		{
			n_string_path_ext_mod_literal( ".png\0\0", path );
		} else
		if ( n_string_path_ext_is_same_literal( ".PNG\0\0", path ) )
		{
			n_string_path_ext_mod_literal( ".lyr\0\0", path );
		} else
		if ( n_string_path_ext_is_same_literal( ".LYR\0\0", path ) )
		{
			n_string_path_ext_mod_literal( ".bmp\0\0", path );
		}

		[self NonnonPaintIconDisplay:_n_button_4_1];

		paint.filename = n_mac_str2nsstring( path );
		n_string_path_free( path );

		[self NonnonPaintTitle];

	}
}

- (void) n_layer_window_rightMouseUp:(NSEvent*) theEvent
{

	if ( _n_layer_window.keyWindow == FALSE ) { return; }

	if ( n_mac_window_is_hovered( _n_layer_listbox ) )
	{
		if ( paint.layer_whole_grab_onoff ) { return; }

//NSLog( @"%d", paint.layer_index );

		if ( paint.layer_index == 0 )
		{
			[_n_layer_popup_menu_up setEnabled:FALSE];
		} else {
			[_n_layer_popup_menu_up setEnabled:TRUE];
		}

		if ( paint.layer_index == ( paint.layer_count - 1 ) )
		{
			[_n_layer_popup_menu_down setEnabled:FALSE];
		} else {
			[_n_layer_popup_menu_down setEnabled:TRUE];
		}

		[NSMenu popUpContextMenu:_n_layer_popup_menu withEvent:theEvent forView:_n_layer_listbox];
	}

}

- (void) rightMouseUp:(NSEvent*) theEvent
{
//NSLog(@"rightMouseUp");

	[self n_toolwindow_rightMouseUp:theEvent];
	[self n_layer_window_rightMouseUp:theEvent];

}

- (void)colorUpdate:(NSColorPanel*)colorPanel{
 
	NSColor *nscolor = colorPanel.color;

	paint.color = n_bmp_color_mac( n_mac_nscolor2argb( nscolor ) );

	[self NonnonPaintColorSet];

}

- (IBAction)n_ppa_method:(NSButton *)sender {

	if ( sender.state == NSControlStateValueOff )
	{
		paint.grabber_per_pixel_alpha_onoff = n_posix_false;
	} else
	if ( sender.state == NSControlStateValueOn )
	{
		paint.grabber_per_pixel_alpha_onoff = n_posix_true;
	}

	[_n_paint_canvas display_optimized];

}




// Resizer

- (void) n_resizer_go_resize:(n_bmp*) resizer_bmp
{

	n_type_gfx sx = (n_type_gfx) [_n_resizer_sx integerValue];
	n_type_gfx sy = (n_type_gfx) [_n_resizer_sy integerValue];

	int index = (int) [_n_resizer_combo indexOfSelectedItem];

	if ( index == 0 )
	{
		n_bmp_resizer( resizer_bmp, sx,sy, n_bmp_white_invisible, N_BMP_RESIZER_NORMAL );
	} else
	if ( index == 1 )
	{
		n_bmp_resizer( resizer_bmp, sx,sy, n_bmp_white_invisible, N_BMP_RESIZER_TILE );
	} else
	if ( index == 2 )
	{
		n_bmp_resizer( resizer_bmp, sx,sy, n_bmp_white_invisible, N_BMP_RESIZER_CENTER );
	} else
	if ( index == 3 )
	{
		n_bmp_resampler
		(
			resizer_bmp,
			(n_type_real) sx / N_BMP_SX( resizer_bmp ),
			(n_type_real) sy / N_BMP_SY( resizer_bmp )
		);
	} else
	if ( index == 4 )
	{
		n_type_real ratio = (n_type_real) sx / N_BMP_SX( resizer_bmp );
		n_bmp_resampler( resizer_bmp, ratio, ratio );
	} else
	if ( index == 5 )
	{
		n_type_real ratio = (n_type_real) sy / N_BMP_SY( resizer_bmp );
		n_bmp_resampler( resizer_bmp, ratio, ratio );
	} else
	if ( index == 6 )
	{
		n_bmp_scaler_big_pixelart( resizer_bmp, 2 );
	} else
	if ( index == 7 )
	{
		n_bmp_scaler_big_pixelart( resizer_bmp, 3 );
	} else
	if ( index == 8 )
	{
		n_bmp_scaler_big( resizer_bmp, 2 );
		n_bmp_scaler_big( resizer_bmp, 2 );

		n_bmp_flush_antialias( resizer_bmp, 1.0 );
		n_bmp_flush_antialias( resizer_bmp, 1.0 );
		n_bmp_flush_antialias( resizer_bmp, 1.0 );
		n_bmp_flush_antialias( resizer_bmp, 1.0 );

		n_bmp_scaler_lil( resizer_bmp, 2 );

		n_bmp_flush_sharpen( resizer_bmp, 0.5 );
	}// else

	n_bmp_matrix_rotate( resizer_bmp, resizer_rotate, n_bmp_white_invisible, n_posix_true );


	return;
}

- (void) n_resizer_go_color:(n_bmp*) resizer_bmp
{

	int index = (int) [_n_resizer_color_combobox indexOfSelectedItem];
	if ( index == 0 )
	{
		// [!] : "None"
	} else
	if ( index == 1 )
	{
		n_bmp_flush_grayscale( resizer_bmp );
	} else
	if ( index == 2 )
	{
		n_bmp_flush_monochrome( resizer_bmp );
	} else
	if ( index == 3 )
	{
		n_paint_flush_reverse( resizer_bmp );
	} else
	if ( index == 4 )
	{
		n_bmp_flush_reducer( resizer_bmp, 4 );
	}// else


	{ // Gamma

		// [!] : shortcut for performance

		n_type_real g = (n_type_real) resizer_gamma / 10.0;

		if ( g == 0.0 ) { n_bmp_flush( resizer_bmp, n_bmp_black ); } else
		if ( g == 2.0 ) { n_bmp_flush( resizer_bmp, n_bmp_white ); } else
		if ( g != 1.0 ) { n_bmp_flush_gamma( resizer_bmp, g );     }

	}

	//if ( 0 )
	{ // Color Wheel & Vividness

		int clrwh = (int) [_n_resizer_colorwheel_scrollbar n_scrollbar_position_get];
		int vivid = (int) [_n_resizer_vividness_scrollbar  n_scrollbar_position_get];

		int h = clrwh - 128;
		int s = vivid - 100;
		int l = 0;

//NSLog( @"%d %d : %d %d : %f", clrwh, vivid, h, s, _n_resizer_colorwheel_scrollbar.scr.unit_pos );

		n_bmp_flush_tweaker_hsl( resizer_bmp, h, s, l );

	}

	//if ( 0 )
	{ // Sharpness

		int s = (int) [_n_resizer_sharpness_scrollbar n_scrollbar_position_get];

		s = s - 100;

		if ( s > 0 )
		{
			n_bmp_flush_sharpen  ( resizer_bmp, (n_type_real) s * 0.01 );
		} else
		if ( s < 0 )
		{
			s *= -1;
			n_bmp_flush_antialias( resizer_bmp, (n_type_real) s * 0.01 );
		}

	}

	//if ( 0 )
	{ // Contrast

		int ctrst = (int) [_n_resizer_contrast_scrollbar n_scrollbar_position_get];

		n_bmp_flush_contrast( resizer_bmp, ctrst );

	}


}

- (void) NonnonPaintResizerInit
{
//return;
//n_mac_debug_count(); return;

	if ( paint.resizer_onoff != FALSE ) { return; }

	if ( paint.layer_onoff )
	{
		paint.resizer_layer_data = n_bmp_layer_raw_copy( paint.layer_data, paint.layer_count );
//n_paint_debug_save( &paint.resizer_layer_data[ paint.layer_index ].bmp_data );
	} else {
		n_paint_bmp_carboncopy( &paint.bmp_data, &paint.resizer_bmp_data );
		n_paint_bmp_carboncopy( &paint.bmp_grab, &paint.resizer_bmp_grab );
//n_paint_debug_save( &paint.bmp_data );
//n_paint_debug_save( &paint.resizer_bmp_data );
	}


	return;
}

- (void) NonnonPaintResizerExit:(BOOL)replace
{
//return;
//n_mac_debug_count(); return;

	if ( paint.resizer_onoff == FALSE ) { return; }

	if ( replace )
	{
//n_mac_debug_count();

		if ( paint.layer_onoff )
		{
			n_bmp_layer_raw_free( paint.resizer_layer_data, paint.layer_count );
		} else {
			n_bmp_free( &paint.resizer_bmp_data );
			n_bmp_free( &paint.resizer_bmp_grab );
		}

	} else {

		if ( paint.layer_onoff )
		{
			n_bmp_layer_raw_free( paint.layer_data, paint.layer_count );
			n_memory_free( paint.layer_data );
			paint.layer_data = paint.resizer_layer_data;
//n_paint_debug_save( &paint.layer_data[ paint.layer_index ].bmp_data );
		} else {
			n_paint_bmp_carboncopy( &paint.resizer_bmp_data, &paint.bmp_data );
			n_paint_bmp_carboncopy( &paint.resizer_bmp_grab, &paint.bmp_grab );
		}

	}

	if ( paint.layer_onoff )
	{
		n_type_int y = paint.layer_index;
		paint.pen_bmp_data = &paint.layer_data[ y ].bmp_data;
		paint.pen_bmp_grab = &paint.layer_data[ y ].bmp_grab;
	}


	return;
}

- (void) n_resizer_go
{
//return;
//n_mac_debug_count(); return;

	if ( paint.resizer_onoff == FALSE ) { return; }

	if ( paint.layer_onoff )
	{

		n_bmp_layer_raw_free( paint.layer_data, paint.layer_count );
		paint.layer_data = n_bmp_layer_raw_copy( paint.resizer_layer_data, paint.layer_count );

		n_type_int i = 0;
		n_posix_loop
		{//break;

			[self n_resizer_go_resize:&paint.layer_data[ i ].bmp_data];
			[self n_resizer_go_resize:&paint.layer_data[ i ].bmp_grab];

			[self n_resizer_go_color :&paint.layer_data[ i ].bmp_data];
			[self n_resizer_go_color :&paint.layer_data[ i ].bmp_grab];

			i++;
			if ( i >= paint.layer_count ) { break; }
		}

		n_type_int y = paint.layer_index;
		paint.pen_bmp_data = &paint.layer_data[ y ].bmp_data;
		paint.pen_bmp_grab = &paint.layer_data[ y ].bmp_grab;

		[_n_paint_canvas n_paint_canvas_reset_cache];

//n_paint_debug_save( &paint.layer_data[ paint.layer_index ].bmp_data );
	} else {

		n_bmp *bmp_target;

		if ( paint.grabber_mode == N_PAINT_GRABBER_NEUTRAL )
		{
			n_paint_bmp_carboncopy( &paint.resizer_bmp_data, &paint.bmp_data );
//n_paint_debug_save( &paint.resizer_bmp_data );
			bmp_target = &paint.bmp_data;
		} else {
			n_paint_bmp_carboncopy( &paint.resizer_bmp_grab, &paint.bmp_grab );
			bmp_target = &paint.bmp_grab;
		}

		[self n_resizer_go_resize:bmp_target];
		[self n_resizer_go_color :bmp_target];

//NSLog( @"%d", n_paint_global.paint->grabber_mode );
		if ( paint.grabber_mode == N_PAINT_GRABBER_NEUTRAL )
		{
			//
		} else {
			n_type_gfx gx,gy,gsx,gsy,gfx,gfy;
			n_paint_grabber_system_get( &gx,&gy, &gsx,&gsy, &gfx,&gfy );

			gsx = N_BMP_SX( bmp_target );
			gsy = N_BMP_SY( bmp_target );

			n_paint_grabber_system_set( &gx,&gy, &gsx,&gsy, &gfx,&gfy );
		}

	}


	[_n_paint_canvas display_optimized];

}

- (IBAction)n_resizer_resize_combobox_method:(id)sender {

	int index = (int) [_n_resizer_combo indexOfSelectedItem];

	if ( index == 4 )
	{
		[_n_resizer_sy setEnabled:FALSE];
	} else {
		[_n_resizer_sy setEnabled:TRUE];
	}

	if ( index == 5 )
	{
		[_n_resizer_sx setEnabled:FALSE];
	} else {
		[_n_resizer_sx setEnabled:TRUE];
	}

	[self n_resizer_go];

}

- (IBAction)n_resizer_sx_method:(id)sender {

//NSLog( @"%ld", [sender integerValue] );

	[self n_resizer_go];

}

- (IBAction)n_resizer_sy_method:(id)sender {

//NSLog( @"%ld", [sender integerValue] );

	[self n_resizer_go];

}

- (IBAction)n_resizer_color_combobox_method:(NSComboBox *)sender {
//NSLog( @"n_resizer_color_combobox_method" );

	[self n_resizer_go];

}

- (IBAction)n_resizer_button_go_method:(NSButton *)sender {

	resizer_is_ok = TRUE;
	[_n_resizer_window close];

}




// [!] : Layer

- (IBAction)n_layer_whole_preview_method:(NSButton *)sender {

	if ( sender.state == NSControlStateValueOff )
	{
		paint.layer_whole_preview_onoff = n_posix_false;
	} else
	if ( sender.state == NSControlStateValueOn )
	{
		paint.layer_whole_preview_onoff = n_posix_true;
	}

	[_n_paint_canvas display_optimized];

}

- (IBAction)n_layer_whole_grab_method:(NSButton *)sender {

	if ( sender.state == NSControlStateValueOff )
	{
		paint.layer_whole_grab_onoff = n_posix_false;
	} else
	if ( sender.state == NSControlStateValueOn )
	{
		paint.layer_whole_grab_onoff = n_posix_true;
	}

}




// [!] : Layer Menu

- (IBAction)n_layer_menu_up:(id)sender {

	if ( n_paint_layer_swap_up( paint.layer_index ) )
	{
		_n_layer_listbox.n_focus = paint.layer_index;
	}

}

- (IBAction)n_layer_menu_down:(id)sender {

	if ( n_paint_layer_swap_down( paint.layer_index ) )
	{
		_n_layer_listbox.n_focus = paint.layer_index;
	}

}

- (IBAction)n_layer_menu_rename:(id)sender {

	if ( _n_layer_listbox.n_listbox_edit_onoff )
	{
		_n_layer_listbox.n_listbox_edit_onoff = FALSE;
	} else {
		_n_layer_listbox.n_listbox_edit_onoff = TRUE;
	}

	[_n_layer_listbox display];

}

- (IBAction)n_layer_menu_all_off:(id)sender {

	n_paint_layer_visibility_onoff_all( n_posix_false );

}

- (IBAction)n_layer_menu_all_on:(id)sender {

	n_paint_layer_visibility_onoff_all( n_posix_true  );

}

- (IBAction)n_layer_menu_this_only:(id)sender {

	n_paint *p = &paint;

	n_paint_layer_visibility_onoff_all( n_posix_false );

	n_type_int i = p->layer_index;

	n_posix_char *nam = n_txt_get( &p->layer_txt, i );

	p->layer_data[ i ].visible = n_posix_true;
	n_paint_layer_text_mod( p, i, &nam[ 3 ] );

	[_n_layer_listbox display];

	[_n_paint_canvas display_optimized];

}

- (IBAction)n_layer_menu_thicken_lines:(id)sender {

	n_type_int y = paint.layer_index;

	if ( paint.grabber_mode == N_PAINT_GRABBER_NEUTRAL )
	{
		n_bmp_thicken( &paint.layer_data[ y ].bmp_data );
	} else {
		n_bmp_thicken( &paint.layer_data[ y ].bmp_grab );
	}

	[_n_paint_canvas display_optimized];

}

- (IBAction)n_layer_menu_thin_lines:(id)sender {

	n_type_int y = paint.layer_index;

	if ( paint.grabber_mode == N_PAINT_GRABBER_NEUTRAL )
	{
		n_bmp_thin( &paint.layer_data[ y ].bmp_data );
	} else {
		n_bmp_thin( &paint.layer_data[ y ].bmp_grab );
	}

	[_n_paint_canvas display_optimized];

}

- (IBAction)n_layer_menu_add_a_new_layer:(id)sender {

	n_paint *p = &paint;


	n_type_int i = p->layer_count;

	p->layer_data = n_memory_resize( p->layer_data, sizeof( n_paint_layer ) * ( i + 1 ) );
	n_paint_layer_zero( &p->layer_data[ i ] );

	n_type_gfx sx = N_BMP_SX( &p->layer_data[ 0 ].bmp_data );
	n_type_gfx sy = N_BMP_SY( &p->layer_data[ 0 ].bmp_data );

	n_bmp_new( &p->layer_data[ i ].bmp_data, sx,sy );

	n_bmp_flush( &p->layer_data[ i ].bmp_data, n_bmp_white_invisible );

	n_txt_add( &p->layer_txt, i, n_posix_literal( "[B]New Layer" ) );


	n_paint_layer_config_default_single( p, i );


	n_posix_char *nam = n_txt_get( &p->layer_txt, i );

	p->layer_data[ i ].visible = n_posix_true;
	n_paint_layer_text_mod( p, i, &nam[ 3 ] );


	p->layer_count++;


	[_n_paint_canvas display_optimized];

}



@end
