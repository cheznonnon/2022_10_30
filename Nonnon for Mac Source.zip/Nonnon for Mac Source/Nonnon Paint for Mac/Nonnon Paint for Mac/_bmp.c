// Nonnon Paint
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Partial File




u32
n_bmp_checker_pixel( n_type_gfx x, n_type_gfx y, n_type_gfx sx, n_type_gfx sy, u32 color )
{

	// [!] : ( n & 31 ) == ( n % 32 )


	n_type_gfx mod_sx = ( sx & 31 ) / 2;
	n_type_gfx mod_sy = ( sy & 31 ) / 2;

	x -= mod_sx;
	y -= mod_sy;


	n_type_gfx mod_x = ( x & 31 );
	n_type_gfx mod_y = ( y & 31 );

	if (
		( ( 16 >  mod_x )&&( 16 >  mod_y ) )
		||
		( ( 16 <= mod_x )&&( 16 <= mod_y ) )
	)
	{
		n_type_real ratio = 0.75;//n_bmp_blend_alpha2ratio( color );
		color = n_bmp_blend_pixel( n_bmp_white, color, ratio );
	}


	return color;
}




void
n_paint_flush_reverse( n_bmp *bmp )
{

	n_type_gfx sx = N_BMP_SX( bmp );
	n_type_gfx sy = N_BMP_SY( bmp );

	n_type_gfx x = 0;
	n_type_gfx y = 0;
	n_posix_loop
	{

		u32 color; n_bmp_ptr_get_fast( bmp, x,y, &color );

		int a =       n_bmp_a( color );
		int r = 255 - n_bmp_r( color );
		int g = 255 - n_bmp_g( color );
		int b = 255 - n_bmp_b( color );

		n_bmp_ptr_set_fast( bmp, x,y, n_bmp_argb( a,r,g,b ) );

		x++;
		if ( x >= sx )
		{
			x = 0;
			y++;
			if ( y >= sy ) { break; }
		}
	}


	return;
}




void
n_bmp_thicken( n_bmp *bmp )
{

	const n_type_real ratio = 1.5;


	n_bmp_flush_antialias( bmp, 1.0 );


	n_type_gfx sx = N_BMP_SX( bmp );
	n_type_gfx sy = N_BMP_SY( bmp );

	n_type_gfx x = 0;
	n_type_gfx y = 0;
	n_posix_loop
	{

		u32 color; n_bmp_ptr_get_fast( bmp, x,y, &color );

		int a = n_bmp_a( color );
		if ( a != 0 )
		{
			u32 c = n_bmp_blend_pixel( n_bmp_white_invisible, n_bmp_black, (n_type_real) a * ratio * n_bmp_coeff_channel );
			n_bmp_ptr_set_fast( bmp, x,y, c );
		}


		x++;
		if ( x >= sx )
		{
			x = 0;
			y++;
			if ( y >= sy ) { break; }
		}
	}


	return;
}

void
n_bmp_thin( n_bmp *bmp )
{

	n_bmp_flush_antialias( bmp, 1.0 );

	n_type_gfx sx = N_BMP_SX( bmp );
	n_type_gfx sy = N_BMP_SY( bmp );

	n_type_gfx x = 0;
	n_type_gfx y = 0;
	n_posix_loop
	{

		u32 color; n_bmp_ptr_get_fast( bmp, x,y, &color );

		int a = n_bmp_a( color );
		if ( ( a != 0 )&&( a != 255 ) )
		{
			if ( a < 128 )
			{
				n_bmp_ptr_set_fast( bmp, x,y, n_bmp_white_invisible );
			}
		}


		x++;
		if ( x >= sx )
		{
			x = 0;
			y++;
			if ( y >= sy ) { break; }
		}
	}

	n_bmp_flush_antialias( bmp, 1.0 );


	return;
}


