// Nonnon Paint
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// [!] : animated frame




#define N_PAINT_FRAME_ANIM




#define N_PAINT_FRAME_ANIM_DOT_SIZE ( 8 )


#define N_PAINT_FRAME_ANIM_INTERVAL ( 100 )

static n_posix_bool  n_paint_frame_anim_onoff = n_posix_false;
static n_posix_bool  n_paint_frame_anim_lock  = n_posix_false;
static NSPoint      *n_paint_frame_anim_path  = NULL;
static n_type_int    n_paint_frame_anim_count =    0;
static n_type_int    n_paint_frame_anim_step  =    0;
static NSTimer      *n_paint_frame_anim_timer;
static NSPoint       n_paint_frame_anim_ctl[ 4 ];




n_type_gfx
n_paint_frame_anim_zoom_get( n_paint *paint )
{

	n_type_gfx z = 1;

	if ( n_paint_global.paint->zoom > 0 )
	{
		z = [n_paint_global n_paint_zoom_get_int:paint->zoom];
	}


	return z;
}

n_type_gfx
n_paint_frame_anim_dot_size( n_type_gfx zoom )
{

	n_type_gfx dot = N_PAINT_FRAME_ANIM_DOT_SIZE;

	n_type_gfx z = zoom;
	if ( n_paint_global.paint->zoom > 0 ) { dot *= z; } else { dot = 4; }


	return dot;
}

n_posix_bool
n_paint_frame_is_hovered( n_paint *paint, int index )
{

	n_posix_bool ret = n_posix_false;


	n_type_gfx z        = n_paint_frame_anim_zoom_get( paint );
	n_type_gfx dot_full = n_paint_frame_anim_dot_size(     z );
	n_type_gfx dot_half = dot_full / 2;


	NSPoint pt = [n_paint_global n_paint_canvaspos];

	n_type_gfx px = pt.x;
	n_type_gfx py = pt.y;

//NSLog( @"%d %d", px, py );

	{
		n_type_gfx x = n_paint_frame_anim_ctl[ index ].x;
		n_type_gfx y = n_paint_frame_anim_ctl[ index ].y;

//NSLog( @"Index %d : P %d %d : C %d %d", index, px, py, x, y );

		if (
			( px >= ( x - dot_half ) )&&( px <= ( x + dot_half ) )
			&&
			( py >= ( y - dot_half ) )&&( py <= ( y + dot_half ) )
		)
		{
			ret = n_posix_true;
		}

	}


	return ret;
}

void
n_paint_frame_mouseDown( n_paint *paint )
{

	if ( n_paint_frame_anim_onoff == n_posix_false ) { return; }


	if (
		( n_paint_frame_anim_lock == n_posix_false )
		&&
		( paint->grabber_mode == N_PAINT_GRABBER_DRAG_OK )
	)
	{
		int i = 0;
		n_posix_loop
		{
			if ( n_paint_frame_is_hovered( paint, i ) )
			{
//NSLog( @"Clicked %d", i );
				paint->grabber_mode = N_PAINT_GRABBER_RESELECT;
				break;
			}

			i++;
			if ( i >= 4 ) { break; }
		}
	}


	return;
}

void
n_paint_frame_anim_init
(
	n_type_gfx bitmap_sx, n_type_gfx bitmap_sy,
	n_type_gfx  frame_fx, n_type_gfx  frame_fy,
	n_type_gfx  frame_tx, n_type_gfx  frame_ty
)
{
//return;


	n_paint_frame_anim_path = n_memory_new( bitmap_sx * bitmap_sy * sizeof( NSPoint ) );


	// [!] : clockwise

	n_type_int i = 0;
	n_type_gfx x = frame_fx;
	n_type_gfx y = frame_fy;

	n_posix_loop
	{
		NSPoint p = { x, y };
		n_paint_frame_anim_path[ i ] = p; i++;

		x++;
		if ( x >= frame_tx ) { break; }
	}

	{
		NSPoint p = { x, y };
		n_paint_frame_anim_ctl[ 1 ] = p;
	}

	n_posix_loop
	{
		NSPoint p = { x, y };
		n_paint_frame_anim_path[ i ] = p; i++;

		y++;
		if ( y >= frame_ty ) { break; }
	}

	{
		NSPoint p = { x, y };
		n_paint_frame_anim_ctl[ 2 ] = p;
	}

	n_posix_loop
	{
		NSPoint p = { x, y };
		n_paint_frame_anim_path[ i ] = p; i++;

		x--;
		if ( x <= frame_fx ) { break; }
	}

	{
		NSPoint p = { x, y };
		n_paint_frame_anim_ctl[ 3 ] = p;
	}

	n_posix_loop
	{
		NSPoint p = { x, y };
		n_paint_frame_anim_path[ i ] = p; i++;

		y--;
		if ( y <= frame_fy ) { break; }
	}

	{
		NSPoint p = { x, y };
		n_paint_frame_anim_ctl[ 0 ] = p;
	}

	n_paint_frame_anim_count = i;


	return;
}

n_posix_bool
n_paint_frame_anim_detect( n_type_gfx x, n_type_gfx y, n_type_gfx zoom )
{
//return n_posix_false;
//return n_posix_true;

	n_posix_bool ret = n_posix_false; 


	if ( n_paint_frame_anim_path == NULL ) { return ret; }


	// [!] : animation will be anti-clockwise : because of macOS is so

	const n_type_int step = 6;

	n_type_int a = ( step - 1 ) - ( n_paint_frame_anim_step % step );

	n_type_int i = 0;
	n_posix_loop
	{//break;

		if ( ( n_paint_frame_anim_path[ i ].x == x )&&( n_paint_frame_anim_path[ i ].y == y ) )
		{
			n_type_int condition = ( i % step );

			if ( condition == a )
			{
				ret = n_posix_true;
				break;
			}
		}

		i++;
		if ( i >= n_paint_frame_anim_count ) { break; }
	}


	return ret;
}

void
n_paint_frame_anim_exit( n_paint *paint, n_bmp *bmp )
{
//return;

	if ( n_paint_frame_anim_path == NULL ) { return; }

	if (
		( paint->grabber_mode == N_PAINT_GRABBER_DRAG_OK )
		||
		( paint->grabber_mode == N_PAINT_GRABBER_SELECTING )
		||
		( paint->grabber_mode == N_PAINT_GRABBER_DRAGGING )
		||
		( paint->grabber_mode == N_PAINT_GRABBER_STRETCH_PROPORTIONAL )
		||
		( paint->grabber_mode == N_PAINT_GRABBER_STRETCH_TRANSFORM )
	)
	{

		const u32 color_border = n_bmp_rgb_mac( 111,111,111 );
		const u32 color_accent = n_bmp_color_mac( n_mac_nscolor2argb( [NSColor controlAccentColor] ) );


		n_type_gfx gx,gy,gsx,gsy;
		n_paint_grabber_system_get( &gx,&gy, &gsx,&gsy, NULL,NULL );
		[n_paint_global n_paint_convert_bitmap2canvas:nil x:&gx y:&gy sx:&gsx sy:&gsy];

		n_type_gfx z        = n_paint_frame_anim_zoom_get( paint );
		n_type_gfx dot_full = n_paint_frame_anim_dot_size(     z );
		n_type_gfx dot_half = dot_full / 2;

		n_type_gfx contour  = n_posix_max_n_type_gfx( 1, z / 3 );


		int i = 0;

		n_type_gfx px = n_paint_frame_anim_path[ i ].x;
		n_type_gfx py = n_paint_frame_anim_path[ i ].y;

		[n_paint_global n_paint_convert_bitmap2canvas:nil x:&px y:&py sx:NULL sy:NULL];


		i++;

		n_posix_loop
		{//break;

			n_type_gfx x = n_paint_frame_anim_path[ i ].x;
			n_type_gfx y = n_paint_frame_anim_path[ i ].y;

			n_type_gfx detect_x = x;
			n_type_gfx detect_y = y;

			[n_paint_global n_paint_convert_bitmap2canvas:nil x:&x y:&y sx:NULL sy:NULL];

			if ( n_paint_frame_anim_detect( detect_x, detect_y, z ) )
			{

				if ( py == y )
				{

					n_type_gfx zsx = z * 4;
					n_type_gfx zsy = z * 2;
					n_type_gfx oy;

					if ( px <= x ) { oy = zsy; } else { oy = 0; }

					if ( ( x + zsx ) < ( gx + gsx ) )
					{

						n_type_gfx o;
						n_type_gfx oo;

						o  = 0;
						oo = o * 2;

						n_bmp_roundrect_ratio( bmp, x+o,y+o-oy, zsx-oo,zsy-oo,  n_bmp_white, 100 );

						o  = contour;
						oo = o * 2;

						n_bmp_roundrect_ratio( bmp, x+o,y+o-oy, zsx-oo,zsy-oo, color_border, 100 );

					}

				} else
				if ( px == x )
				{

					n_type_gfx zsx = z * 2;
					n_type_gfx zsy = z * 4;
					n_type_gfx ox;

					if ( py >= y ) { ox = zsx; } else { ox = 0; }

					if ( ( y + zsy ) < ( gy + gsy ) )
					{

						n_type_gfx o;
						n_type_gfx oo;

						o  = 0;
						oo = o * 2;

						n_bmp_roundrect_ratio( bmp, x+o-ox,y+o, zsx-oo,zsy-oo,  n_bmp_white, 100 );

						o  = contour;
						oo = o * 2;

						n_bmp_roundrect_ratio( bmp, x+o-ox,y+o, zsx-oo,zsy-oo, color_border, 100 );

					}

				}

			} else
			if ( 1 == z )
			{

				u32 c;
				n_bmp_ptr_get( bmp, x,y, &c );
				n_bmp_ptr_set( bmp, x,y, ~c );

			} else {

				// [!] : for debugging
				//n_bmp_box( bmp, x, y, z, z, color_border );

			}


			px = x;
			py = y;

			i++;
			if ( i >= n_paint_frame_anim_count ) { break; }
		}


		i = 0;
		n_posix_loop
		{//break;

			n_type_gfx x = n_paint_frame_anim_ctl[ i ].x;
			n_type_gfx y = n_paint_frame_anim_ctl[ i ].y;

			[n_paint_global n_paint_convert_bitmap2canvas:nil x:&x y:&y sx:NULL sy:NULL];
	
			u32 color;
			if ( n_paint_frame_anim_lock )
			{
				color = color_border;
			} else {
				color = color_accent;
			}

			if ( 1 == z ) { x++; y++; } // [Patch]

			n_bmp_circle
			(
				bmp,
				x - dot_half,
				y - dot_half,
				    dot_full,
				    dot_full,
				n_bmp_white
			);

			n_bmp_circle
			(
				bmp,
				x - dot_half + contour,
				y - dot_half + contour,
				    dot_full - ( contour * 2 ),
				    dot_full - ( contour * 2 ),
				color
			);

			i++;
			if ( i >= 4 ) { break; }
		}

	}


	n_memory_free( n_paint_frame_anim_path );
	n_paint_frame_anim_path = NULL;


	return;
}


