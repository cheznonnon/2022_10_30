// Nonnon Paint
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Partial File




@interface NonnonPaintStub : NSView

@property (nonatomic,assign) id delegate;

@end


@implementation NonnonPaintStub

@synthesize delegate;

- init
{
	self = [super init];
	if ( self )
	{
		[self registerForDraggedTypes:[NSArray arrayWithObject:NSPasteboardTypeFileURL]];
	}

	return self;
}

- (void) updateTrackingAreas
{
//return;

	int options = (
		NSTrackingMouseEnteredAndExited |
		NSTrackingMouseMoved            |
		NSTrackingActiveAlways          |
		NSTrackingActiveInActiveApp
	);

	NSTrackingArea *trackingArea = [
		[NSTrackingArea alloc]
			initWithRect:[self bounds]
			     options:options
			       owner:self
			    userInfo:nil
	];
	
	[self addTrackingArea:trackingArea];

}

- (void) mouseEntered:(NSEvent *)theEvent
{
//NSLog(@"mouseEntered");

	// [Needed] : NSTrackingMouseEnteredAndExited

	[self.window makeKeyWindow];

}




-(NSDragOperation) draggingEntered:( id <NSDraggingInfo> ) sender
{
//NSLog( @"draggingEntered" );

	// [!] : call when hovered

	if ( n_paint_global.paint->readonly ) { return NSDragOperationNone; }

	return NSDragOperationCopy;
}

-(void) draggingExited:( id <NSDraggingInfo> )sender
{
//NSLog( @"draggingExited" );
}

-(BOOL) prepareForDragOperation:( id <NSDraggingInfo> )sender
{
//NSLog( @"prepareForDragOperation" );

	if ( n_paint_global.paint->readonly ) { return NO; }

	return YES;
}

-(BOOL) performDragOperation:( id <NSDraggingInfo> )sender
{
//NSLog( @"performDragOperation" );

	if ( n_paint_global.paint->readonly ) { return NO; }

	return YES;
}

-(void) concludeDragOperation:( id <NSDraggingInfo> )sender
{
//NSLog( @"concludeDragOperation" );

	NSPasteboard *pasteboard = [sender draggingPasteboard];
	NSString     *nsstr      = [[NSURL URLFromPasteboard:pasteboard] path];

	[self.delegate NonnonDragAndDrop_dropped:nsstr];

}

-(NSDragOperation) draggingUpdated:( id <NSDraggingInfo> ) sender
{
//NSLog( @"draggingUpdated" );

	if ( n_paint_global.paint->readonly ) { return NSDragOperationNone; }

	return NSDragOperationCopy;
}
@end


