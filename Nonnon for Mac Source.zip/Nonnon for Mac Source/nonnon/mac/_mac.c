// Project Nonnon
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#ifndef _H_NONNON_MAC
#define _H_NONNON_MAC




#import <Cocoa/Cocoa.h>




#include "../neutral/posix.c"
#include "../neutral/string.c"




// [!] : event.keyCode

#define N_MAC_KEYCODE_ARROW_UP    126
#define N_MAC_KEYCODE_ARROW_DOWN  125
#define N_MAC_KEYCODE_ARROW_LEFT  123
#define N_MAC_KEYCODE_ARROW_RIGHT 124

#define N_MAC_KEYCODE_ENTER        36
#define N_MAC_KEYCODE_RETURN       36

#define N_MAC_KEYCODE_TAB          48

#define N_MAC_KEYCODE_SPACE        49

#define N_MAC_KEYCODE_BACKSPACE    51

#define N_MAC_KEYCODE_CUT          7 // 'x'
#define N_MAC_KEYCODE_COPY         8 // 'c'
#define N_MAC_KEYCODE_PASTE        9 // 'v'
#define N_MAC_KEYCODE_SELECT_ALL   0 // 'a'
#define N_MAC_KEYCODE_SAVE         1 // 's'
#define N_MAC_KEYCODE_UNDO         6 // 'z'
#define N_MAC_KEYCODE_FIND         3 // 'f'

#define N_MAC_KEYCODE_HOME       115
#define N_MAC_KEYCODE_END        119
#define N_MAC_KEYCODE_DELETE     117
#define N_MAC_KEYCODE_PRTSCN     105

#define N_MAC_KEYCODE_F1         122
#define N_MAC_KEYCODE_F2         120
#define N_MAC_KEYCODE_F3          99
#define N_MAC_KEYCODE_F4         118
#define N_MAC_KEYCODE_F5          96
#define N_MAC_KEYCODE_F6          97
#define N_MAC_KEYCODE_F7          98
#define N_MAC_KEYCODE_F8         100
#define N_MAC_KEYCODE_F9         101
#define N_MAC_KEYCODE_F10        109
//#define N_MAC_KEYCODE_F11      handled as special
#define N_MAC_KEYCODE_F12        111

#define N_MAC_KEYCODE_NUMBER_1    18
#define N_MAC_KEYCODE_NUMBER_2    19
#define N_MAC_KEYCODE_NUMBER_3    20
#define N_MAC_KEYCODE_NUMBER_4    21
#define N_MAC_KEYCODE_NUMBER_5    23
#define N_MAC_KEYCODE_NUMBER_6    22
#define N_MAC_KEYCODE_NUMBER_7    26
#define N_MAC_KEYCODE_NUMBER_8    28
#define N_MAC_KEYCODE_NUMBER_9    25
#define N_MAC_KEYCODE_NUMBER_0    29




// [!] : shared

@protocol NonnonDragAndDrop_delegate

- (void) NonnonDragAndDrop_dropped : (NSString*) nsstr;

@end




void
n_mac_debug_count( void )
{

	static int i = 0;

	NSLog( @"%d", i );

	i++;


	return;
}




NSString*
n_mac_str2nsstring( n_posix_char *str )
{
	if ( str == NULL ) { return [[NSString alloc] init]; }

	return [NSString stringWithUTF8String:str];
}

char*
n_mac_nsstring2str( NSString *nsstring )
{
	if ( nsstring == nil ) { return n_string_new( 1 ); }

	return (void*) [nsstring UTF8String];
}




void
n_mac_rect_expand_size( NSRect rect, n_type_gfx *x, n_type_gfx *y, n_type_gfx *sx, n_type_gfx *sy )
{

	if (  x != NULL ) { (* x) = rect.origin.x   ; }
	if (  y != NULL ) { (* y) = rect.origin.y   ; }
	if ( sx != NULL ) { (*sx) = rect.size.width ; }
	if ( sy != NULL ) { (*sy) = rect.size.height; }


	return;
}




NSTimer*
n_mac_timer_init( id self, SEL selector, NSTimeInterval msec )
{

	NSTimer *timer = [NSTimer
		 scheduledTimerWithTimeInterval:msec / 1000
		                         target:self
		                       selector:selector
		                       userInfo:nil
		                        repeats:YES
	];

	timer.tolerance = 1 / 1000;

	return timer;
}

void
n_mac_timer_exit( NSTimer *timer )
{

	[timer invalidate];

	return;
}




void
n_mac_finder_call( NSString *path )
{
	NSArray *array = [NSArray arrayWithObjects:path, nil];
	[[NSWorkspace sharedWorkspace] activateFileViewerSelectingURLs:array];

	return;
}




BOOL
n_mac_is_darkmode( void )
{
	NSString *interfaceStyle = [NSUserDefaults.standardUserDefaults valueForKey:@"AppleInterfaceStyle"];
	return [interfaceStyle isEqualToString:@"Dark"];
}




void
n_mac_desktop_size( CGFloat *sx, CGFloat *sy )
{

	NSRect rect = [[NSScreen mainScreen] frame];

	if ( sx != NULL ) {  (*sx) = NSWidth ( rect ); }
	if ( sy != NULL ) {  (*sy) = NSHeight( rect ); }


	return;
}




void
n_mac_topmost( NSWindow *window, BOOL onoff )
{

	if ( onoff )
	{
		[window setLevel:NSFloatingWindowLevel];
	} else {
		[window setLevel:NSNormalWindowLevel];
	}

	return;
}

void
n_mac_foreground( void )
{
	[NSApp activateIgnoringOtherApps:YES];
	[NSApp activateIgnoringOtherApps: NO];

	return;
}




NSString*
n_mac_settings_read( NSString *nsstr_key )
{

	CFStringRef key = (__bridge CFStringRef) nsstr_key;
	CFStringRef ret = CFPreferencesCopyAppValue( key, kCFPreferencesCurrentApplication );

	return (__bridge NSString*) ret;
}

void
n_mac_settings_write( NSString *nsstr_key, NSString *nsstr_val )
{

	CFStringRef key = (__bridge CFStringRef) nsstr_key;
	CFStringRef val = (__bridge CFStringRef) nsstr_val;

	CFPreferencesSetAppValue( key, val, kCFPreferencesCurrentApplication );

	return;
}




#endif // _H_NONNON_MAC


