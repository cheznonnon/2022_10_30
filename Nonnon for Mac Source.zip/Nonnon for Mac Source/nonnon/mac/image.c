// Project Nonnon
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#ifndef _H_NONNON_MAC_IMAGE
#define _H_NONNON_MAC_IMAGE




#import <Cocoa/Cocoa.h>


#include "../neutral/bmp/all.c"
#include "../neutral/png.c"


#include "./_mac.c"




void
n_bmp_mac_color( n_bmp *bmp )
{

	// [!] : format
	//
	//	ABGR
	//	upside down


	n_type_gfx x = 0;
	n_type_gfx y = 0;
	n_posix_loop
	{
		u32 color;
		n_bmp_ptr_get_fast( bmp, x,y, &color );

		color = n_bmp_argb
		(
			n_bmp_a( color ),
			n_bmp_b( color ),
			n_bmp_g( color ),
			n_bmp_r( color )
		);

		n_bmp_ptr_set_fast( bmp, x,y,  color );

		x++;
		if ( x >= N_BMP_SX( bmp ) )
		{

			x = 0;

			y++;
			if ( y >= N_BMP_SY( bmp ) ) { break; }
		}
	}


	return;
}

void
n_bmp_mac( n_bmp *bmp )
{

	n_bmp_mac_color( bmp );

	n_bmp_flush_mirror( bmp, N_BMP_MIRROR_UPSIDE_DOWN );


	return;
}




#define n_bmp_rgb_mac( r, g, b ) n_bmp_rgb( b, g, r )

#define n_bmp_argb_mac( a, r, g, b ) n_bmp_argb( a, b, g, r )

#define n_bmp_color_mac( c ) n_bmp_argb( n_bmp_a( c ), n_bmp_b( c ), n_bmp_g( c ), n_bmp_r( c ) )

#define n_mac_nscolor_argb( a, r, g, b ) [NSColor colorWithSRGBRed:(r)/255.0 green:(g)/255.0 blue:(b)/255.0 alpha:(a)/255.0]

#define n_mac_argb2nscolor( c ) n_mac_nscolor_argb( n_bmp_a( c ), n_bmp_r( c ), n_bmp_g( c ), n_bmp_b( c ) )

u32
n_mac_nscolor2argb( NSColor *nscolor )
{

	CIColor *cicolor = [[CIColor alloc] initWithColor:nscolor];

	int a = (int) ( cicolor.alpha * 255.0 );
	int r = (int) ( cicolor.red   * 255.0 );
	int g = (int) ( cicolor.green * 255.0 );
	int b = (int) ( cicolor.blue  * 255.0 );

//NSLog( @"%f %f %f %f", cicolor.alpha, cicolor.red, cicolor.green, cicolor.blue );


	return n_bmp_argb( a,r,g,b );
}




NSPoint
n_mac_image_position_flip( const n_bmp *bmp, NSPoint pt )
{

	pt.y = N_BMP_SY( bmp ) - 1 - pt.y;

	return pt;
}

// internal
NSBitmapImageRep*
n_mac_image_NSBitmapImageRep( const n_bmp *bmp )
{

	NSBitmapImageRep *n_rep = [
		[NSBitmapImageRep alloc]
		initWithBitmapDataPlanes : (void*) &N_BMP_PTR( bmp )
		pixelsWide               : N_BMP_SX( bmp )
		pixelsHigh               : N_BMP_SY( bmp )
		bitsPerSample            : 8
		samplesPerPixel          : 4
		hasAlpha                 : YES
		isPlanar                 : NO
		colorSpaceName           : NSCalibratedRGBColorSpace
		bytesPerRow              : (int) N_BMP_SX( bmp ) * 4
		bitsPerPixel             : 32
	];
//if ( n_rep == nil ) { NSLog( @"NSBitmapImageRep : nil" ); }


	return n_rep;
}

NSImage*
n_mac_image_nbmp2nsimage( const n_bmp *bmp )
{

	NSBitmapImageRep *n_rep = n_mac_image_NSBitmapImageRep( bmp );

	NSImage *n_nsimage = [NSImage.alloc initWithSize:n_rep.size];
	[n_nsimage addRepresentation:n_rep];

//if ( n_nsimage == nil ) { NSLog( @"NSImage : nil" ); }


	return n_nsimage;
}

#define N_MAC_IMAGE_SAVE_PNG ( 1 )
#define N_MAC_IMAGE_SAVE_JPG ( 2 )

n_posix_bool
n_mac_image_save( const n_bmp *bmp, n_posix_char *path, int mode )
{

	NSBitmapImageRep *n_rep = n_mac_image_NSBitmapImageRep( bmp );


	BOOL ret = NO;

	if ( mode == N_MAC_IMAGE_SAVE_PNG )
	{
		NSDictionary *property = [[NSDictionary alloc] init];

		NSData *data;
		data = [n_rep representationUsingType:NSBitmapImageFileTypePNG properties:property];
		ret = [data writeToFile:n_mac_str2nsstring( path ) atomically: NO];
	} else
	if ( mode == N_MAC_IMAGE_SAVE_JPG )
	{
		NSDictionary *property = [[NSDictionary alloc] init];

		NSData *data;
		data = [n_rep representationUsingType:NSBitmapImageFileTypeJPEG properties:property];
		ret = [data writeToFile:n_mac_str2nsstring( path ) atomically: NO];
	}


	return ( ret == NO );
}
/*
static CGFloat n_mac_image_nsimage2nbmp_scale_factor = 1.0;

void
n_mac_image_nsimage2nbmp( NSImage *image, n_bmp *bmp )
{

	// [x] : unknown formats will return

	NSData *data = [image TIFFRepresentation];

	n_type_gfx sx = (n_type_gfx) image.size.width  * n_mac_image_nsimage2nbmp_scale_factor;
	n_type_gfx sy = (n_type_gfx) image.size.height * n_mac_image_nsimage2nbmp_scale_factor;

	// [x] : ARC does not working at this section
	free( N_BMP_PTR( bmp ) ); N_BMP_PTR( bmp ) = NULL;

	n_bmp_new( bmp, sx, sy );

	n_memory_copy( [data bytes], N_BMP_PTR( bmp ), N_BMP_SIZE( bmp ) );

	double ratio = 1.0 / n_mac_image_nsimage2nbmp_scale_factor;
	n_bmp_resampler( bmp, ratio, ratio );


	// [!] : do when needed manually
	//n_bmp_mac( bmp );


	return;
}
*/

void
n_mac_image_nbmp_direct_draw( const n_bmp *bmp, NSRect *rect, n_posix_bool flip )
{

//static u32 tick_prv = 0;

/*
	// [!] : slowest

	NSDrawBitmap
	(
		NSMakeRect( 0,0, N_BMP_SX( bmp ),N_BMP_SY( bmp ) ),
		N_BMP_SX( bmp ),
		N_BMP_SY( bmp ),
		8,
		4,
		0,
		(int) N_BMP_SX( bmp ) * 4,
		NO,
		YES,
		NSCalibratedRGBColorSpace,
		(void*) &N_BMP_PTR( bmp )
	);
*/

	NSImage *img = n_mac_image_nbmp2nsimage( bmp );


	// [!] : slower than CGContextDrawImage()

	//[img drawInRect:*rect];


	// [!] : fastest

	NSGraphicsContext *context = [NSGraphicsContext currentContext];
	CGImageRef         ref     = [img CGImageForProposedRect:rect context:context hints:nil];
	CGContextRef       cg_ctx  = [context CGContext];

	if ( flip )
	{
		CGContextTranslateCTM( cg_ctx, 0, img.size.height );
		CGContextScaleCTM( cg_ctx, 1.0, -1.0 );
	}

	CGContextDrawImage( cg_ctx, NSRectToCGRect( *rect ), ref );


//u32 tick_cur = n_posix_tickcount();

//NSLog( @"%d", (int) tick_cur - tick_prv );

//tick_prv = tick_cur;


	return;
}




CGSize
n_mac_image_text_pixelsize( NSString *text, NSFont *font )
{

	// [x] : buggy : this module will report insufficient width
	//
	//	make width larger than reported width

	CGSize size = CGSizeZero;

	CGRect frame = [text
		 boundingRectWithSize:CGSizeMake( CGFLOAT_MAX, CGFLOAT_MAX )
		 options:NSStringDrawingUsesLineFragmentOrigin
		 attributes:@{ NSFontAttributeName:font }
		 context:nil
	];

	size = CGSizeMake( frame.size.width, frame.size.height );


	return size;
}

void
n_mac_image_text_native
(
	NSImage  *image,
	NSString *text,
	NSFont   *font,
	NSColor  *color,
	CGFloat   ox,
	CGFloat   oy
)
{

	// [!] : this module is only working under drawRect


	CGFloat isx = image.size.width;
	CGFloat isy = image.size.height;

	CGSize size = n_mac_image_text_pixelsize( text, font );

	NSRect rect = NSMakeRect
	(
		( ( isx - size.width  ) / 2 ) + ox,
		( ( isy - size.height ) / 2 ) + oy,
		size.width,
		size.height
	);


	NSMutableDictionary *attr = [NSMutableDictionary dictionary];

	[attr setObject:font  forKey:NSFontAttributeName           ];
	[attr setObject:color forKey:NSForegroundColorAttributeName];


	[image lockFocus];

	[text drawInRect:rect withAttributes:attr];

	[image unlockFocus];


	return;
}

#define N_MAC_IMAGE_TEXT_NONE    ( 0 << 0 )
#define N_MAC_IMAGE_TEXT_CENTER  ( 1 << 0 )
#define N_MAC_IMAGE_TEXT_CONTOUR ( 1 << 1 )
#define N_MAC_IMAGE_TEXT_SINK    ( 1 << 2 )
#define N_MAC_IMAGE_TEXT_MAC     ( 1 << 3 )

void
n_mac_image_text_direct_draw
(
	NSImage  *image,
	NSString *text,
	NSFont   *font,
	u32       color_text,
	u32       color_effect,
	CGFloat   parameter_effect,
	CGFloat   ox,
	CGFloat   oy,
	int       mode
)
{

	// [!] : this module is only working under drawRect


	if ( mode & N_MAC_IMAGE_TEXT_CONTOUR )
	{

		NSColor *c = n_mac_argb2nscolor( color_effect );

		n_type_gfx prm = parameter_effect;

		n_type_gfx x = -prm;
		n_type_gfx y = -prm;
		n_posix_loop
		{

			n_mac_image_text_native( image, text, font, c, ox + x,oy + y );

			x++;
			if ( x >= ( prm + 1 ) )
			{
				x = -prm;
				y++;
				if ( y >= ( prm + 1 ) ) { break; }
			}
		}

	} else
	if ( mode & N_MAC_IMAGE_TEXT_SINK )
	{

		NSColor *tl = n_mac_nscolor_argb( 255,  1,  1,  1 );
		NSColor *dr = n_mac_nscolor_argb( 255,255,255,255 );

		n_mac_image_text_native( image, text, font, tl, ox + 1,oy - 1 );
		n_mac_image_text_native( image, text, font, dr, ox - 1,oy + 1 );

	}


	NSColor *c = n_mac_argb2nscolor( color_text );

	n_mac_image_text_native( image, text, font, c, ox,oy );


	return;
}




void
n_mac_image_rc_load_bmp( NSString *name, n_bmp *bmp )
{

	NSBundle *main = [NSBundle mainBundle];
	NSString *path = [main pathForResource:name ofType:@"bmp"];

	n_posix_char *str = n_mac_nsstring2str( path );

	n_posix_bool ret = n_bmp_load( bmp, str );
	if ( ret == n_posix_false )
	{
		// [!] : do when needed manually
		//n_bmp_mac( bmp );
	}

	n_string_free( str );


	return;
}




#endif // _H_NONNON_MAC_IMAGE


