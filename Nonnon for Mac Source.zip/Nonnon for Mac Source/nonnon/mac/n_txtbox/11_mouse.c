// CatPad
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Partial File




@implementation NonnonTxtbox (NonnonTxtboxMouse)


- (n_caret) NonnonTxtboxMouseCursorDetect
{

	NSPoint local_point = n_mac_cursor_position_get( self );

	n_focus = trunc( scroll + trunc( ( local_point.y - offset ) / font_size.height ) );
	if ( n_focus >= n_txt_data->sy ) { n_focus = n_txt_data->sy - 1; }
//NSLog( @"%f", n_focus );

	NSRect r = NSMakeRect( padding, offset, [self frame].size.width - ( offset * 2 ), font_size.height );

	n_caret caret = n_txtbox_caret_detect_pixel2caret
	(
		n_txt_data,
		n_focus,
		r,
		font,
		font_size,
		local_point
	);

//NSLog( @"%lld %lld", caret.cch.x, caret.cch.y );


	return caret;
}




- (BOOL) acceptsFirstMouse:(NSEvent *)event
{
	return self.n_direct_click_onoff;
}



- (void) mouseUp:(NSEvent*) theEvent
{
//NSLog( @"mouseUp" );

	thumb_is_captured = FALSE;


	if ( thumb_is_hovered ) { return; }
	if ( shaft_is_hovered ) { return; }

	if ( self.n_mode == N_MAC_TXTBOX_MODE_LISTBOX )
	{

		//

	} else {

		if ( self.n_mode == N_MAC_TXTBOX_MODE_FINDBOX )
		{
			if ( find_icon_is_pressed )
			{
				find_icon_is_pressed = FALSE;

				if ( n_mac_window_is_hovered_offset_by_rect( self, find_icon_rect ) )
				{
					[self.delegate NonnonTxtbox_delegate_F3:self];
				}
			} else
			if ( delete_circle_is_pressed )
			{
				delete_circle_is_pressed = FALSE;

				if ( n_mac_window_is_hovered_offset_by_rect( self, delete_circle_rect ) )
				{
					[self NonnonTxtboxSelectAll:FALSE];
					n_mac_txtbox_del( n_txt_data, &n_focus, &caret_fr, &caret_to );
				}
			}
		}

	}

	[delegate mouseUp:theEvent];

}

- (void) mouseDown:(NSEvent*) theEvent
{
//NSLog(@"mouseDown");

	pt               = [NSEvent mouseLocation];
	thumb_is_hovered = n_mac_window_is_hovered_offset_by_rect( self, scroller_rect_thumb );
	shaft_is_hovered = n_mac_window_is_hovered_offset_by_rect( self, scroller_rect_shaft );
//if ( thumb_is_hovered ) { NSLog( @"!" ); }

	NSPoint pt_cur   = n_mac_cursor_position_get( self );
	thumb_offset     = scroller_rect_thumb.origin.y - pt_cur.y;
//NSLog( @"%f : %f %f", thumb_offset, scroller_rect_thumb.origin.y, pt_cur.y );

	if ( thumb_is_hovered )
	{
		thumb_is_captured = TRUE;
	} else
	if ( shaft_is_hovered )
	{

		CGFloat sy               = [self frame].size.height;
		CGFloat csy              = sy - ( offset * 2 );
		CGFloat items_per_canvas = csy / font_size.height;

		if ( pt_cur.y < scroller_rect_thumb.origin.y )
		{
//NSLog( @"upper" );
			scroll -= items_per_canvas;
		} else {
//NSLog( @"lower" );
			scroll += items_per_canvas;
		}

		[self display];

	} else
	if ( self.n_mode == N_MAC_TXTBOX_MODE_LISTBOX )
	{

		NSPoint local_point = n_mac_cursor_position_get( self );

		n_focus = trunc( scroll + trunc( ( local_point.y - offset ) / font_size.height ) );
		if ( n_focus >= n_txt_data->sy ) { n_focus = n_txt_data->sy - 1; }
//NSLog( @"%f", n_focus );


		if ( self.n_listbox_edit_onoff )
		{
			if ( [theEvent clickCount] == 3 )
			{
				[self NonnonTxtboxTripleclickDetect];
			} else
			if ( [theEvent clickCount] == 2 )
			{
				[self NonnonTxtboxDoubleclickDetect];
			} else {
				caret_fr = caret_to = [self NonnonTxtboxMouseCursorDetect];
			}

			thumb_is_hovered = n_posix_false;

			[self display];
		} else {
			self.n_listbox_edit_onoff = FALSE;

			caret_fr = caret_to = [self NonnonTxtboxMouseCursorDetect];

			[self display];
		}

	} else {

		if ( [theEvent clickCount] == 3 )
		{
			[self NonnonTxtboxTripleclickDetect];
		} else
		if ( [theEvent clickCount] == 2 )
		{
			[self NonnonTxtboxDoubleclickDetect];
		} else
		if ( [theEvent clickCount] == 1 )
		{
			if ( self.n_mode == N_MAC_TXTBOX_MODE_FINDBOX )
			{
				if ( n_mac_window_is_hovered_offset_by_rect( self, find_icon_rect ) )
				{
					find_icon_is_pressed = TRUE;
				} else
				if ( n_mac_window_is_hovered_offset_by_rect( self, delete_circle_rect ) )
				{
					delete_circle_is_pressed = TRUE;
				} else {
					caret_fr = caret_to = [self NonnonTxtboxMouseCursorDetect];
				}
			} else {
				caret_fr = caret_to = [self NonnonTxtboxMouseCursorDetect];
			}
		}

		thumb_is_hovered = n_posix_false;

		caret_blink_force_onoff = TRUE;

		[self display];

	}

}

- (void) mouseDragged:(NSEvent*) theEvent
{
//NSLog( @"mouseDragged" );

	CGPoint pt_cur = [NSEvent mouseLocation];

	CGFloat dy = pt.y - pt_cur.y;
//NSLog( @"%f %f", dy, [theEvent deltaY] );

	pt = pt_cur;

//scroll -= dy / font_size.height;

	if ( thumb_is_captured )
	{
//NSLog( @"1" ); 
		CGFloat max_count  = (CGFloat) n_txt_data->sy;
		CGFloat correction = client_sy / ( max_count * font_size.height );

		scroll += dy / ( font_size.height * correction );

		[self display];

	} else
	if ( self.n_mode == N_MAC_TXTBOX_MODE_LISTBOX )
	{

		//

	} else {

		if ( thumb_is_hovered ) { return; }
		if ( shaft_is_hovered ) { return; }

		if ( find_icon_is_pressed ) { return; }


		caret_to = [self NonnonTxtboxMouseCursorDetect];
//n_caret_debug_cch( caret_fr, caret_to );

		if ( caret_fr.cch.x < caret_to.cch.x )
		{
			shift_selection_is_tail = TRUE;
		} else {
			shift_selection_is_tail = FALSE;
		}

		thumb_is_hovered = n_posix_false;


		// [x] : partially redraw : too much hard to implement

		//[self display];

		{
			CGFloat  x = 0;
			CGFloat  y = 0;//n_posix_min_n_type_real( caret_fr.pxl.y, caret_to.pxl.y );
			CGFloat sx = self.frame.size.width;
			CGFloat sy = self.frame.size.height;//n_posix_max_n_type_real( caret_fr.pxl.y, caret_to.pxl.y );

			[self displayRect:NSMakeRect( x,y,sx,sy )];
		}

	}

}




- (void)scrollWheel:(NSEvent *)theEvent
{
//NSLog( @"%lu : %0.2f %0.2f", [theEvent phase], [theEvent deltaY], [theEvent scrollingDeltaY] );

	//if ( thumb_is_hovered ) { return; }
	//if ( shaft_is_hovered ) { return; }


//NSLog( @"%f", [theEvent scrollingDeltaY] );
//return;

	const CGFloat boost = 2;

	CGFloat delta = [theEvent scrollingDeltaY] / font_size.height;
	if ( delta < 0 )
	{
		delta = delta * boost;
	} else {
		delta = delta * boost;
	}

	scroll -= delta;
//NSLog( @"%f", scroll );

	[self display];

}




- (void) rightMouseUp:(NSEvent*) theEvent
{
//NSLog( @"rightMouseUp" );

	[delegate_right rightMouseUp:theEvent];

}




- (void) otherMouseUp:(NSEvent*) theEvent
{
//NSLog( @"otherMouseUp : %ld", (long) [theEvent buttonNumber] );

	if ( [theEvent buttonNumber] == 2 )
	{

		// [!] : middle button

		[[NSCursor arrowCursor] set];

	}

}

- (void) otherMouseDown:(NSEvent*) theEvent
{
//NSLog( @"otherMouseDown : %ld", (long) [theEvent buttonNumber] );

	// [!] : Grab N Drag

	if ( [theEvent buttonNumber] == 2 )
	{

		// [!] : middle button

		pt             = [NSEvent mouseLocation];
		pt_grag_n_drag = [theEvent locationInWindow];

		[[NSCursor closedHandCursor] set];

	}

}

- (void) otherMouseDragged:(NSEvent*) theEvent
{
//NSLog( @"otherMouseDragged" );

	if ( [theEvent buttonNumber] == 2 )
	{

		// [!] : middle button

		CGPoint pt_cur = [NSEvent mouseLocation];

		CGFloat dy = pt.y - pt_cur.y;
//NSLog( @"%f %f", dy, [theEvent deltaY] );

		pt = pt_cur;


		const CGFloat axl = 2;

		scroll -= dy / font_size.height * axl;


		[self display];

	}

}


@end

