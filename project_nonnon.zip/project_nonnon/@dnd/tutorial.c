// Tutorial
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#include "../nonnon/project/define_unicode.c"




#include "../nonnon/win32/win.c"


#include "../nonnon/win32/ole/IDropSource.c"
#include "../nonnon/win32/ole/IShellFolder.c"


#include "../nonnon/project/macro.c"




LRESULT CALLBACK
WndProc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	switch( msg ) {


	case WM_CREATE :

		OleInitialize( NULL );


		n_win_init_literal( hwnd, "Tutorial", "MAIN_ICON", "" );


		n_win_style_new( hwnd, WS_OVERLAPPEDWINDOW );

		n_win_set( hwnd, NULL, 256,256, N_WIN_SET_CENTERING | N_WIN_SET_CLIPPING );


		ShowWindow( hwnd, SW_NORMAL );

	break;


	case WM_LBUTTONDOWN :
	{

		n_posix_char *str = L"Z:\\c\\@dnd\\neko.png\0\0";

		IDataObject *p_IDataObject = NULL;


		// [x] : into Exploer : crash

		n_IDataObject_dnd_init( &p_IDataObject, str, n_posix_strlen( str ) + 2 );

		static DWORD pdwEffect = DROPEFFECT_COPY;
		DoDragDrop( p_IDataObject, &n_IDropSource_instance, DROPEFFECT_COPY, &pdwEffect );
//n_posix_debug_literal( "%x", hret );

		n_IDataObject_dnd_exit( &p_IDataObject );

/*

		// [x] : not implementable
		//
		//	a : WM_LBUTTONDOWN only
		//	b : you cannot drop into "recycle bin"
		//	c : you cannot redraw while dragging
		//	d : not droppable into non-HWND area

		n_IShellFolder_path2object( str, &n_IDataObject_guid_IID_IDataObject, (void*) &p_IDataObject );

		static DWORD pdwEffect = DROPEFFECT_COPY;
		DoDragDrop( p_IDataObject, &n_IDropSource_instance, DROPEFFECT_COPY, &pdwEffect );

		p_IDataObject->lpVtbl->Release( p_IDataObject );
*/
	}
	break;


	case WM_CLOSE :

		ShowWindow( hwnd, SW_HIDE );

		OleUninitialize();

		DestroyWindow( hwnd );

	break;

	case WM_DESTROY :

		PostQuitMessage( 0 );

	break;


	} // switch


	return DefWindowProc( hwnd, msg, wparam, lparam );
}

int WINAPI
WinMain( HINSTANCE hinst, HINSTANCE prv_hinst, LPSTR cmd, int show )
{
	return n_win_main( NULL, WndProc );
}


