// Nonnon Win
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#include "../nonnon/neutral/filer.c"
#include "../nonnon/neutral/path.c"

#include "../nonnon/win32/win/commandline.c"




int
main( void )
{

	// Phase 1 : shared

	n_win_exedir2curdir();

	n_posix_char cmdline[ N_PATH_MAX ]; n_win_commandline( cmdline );
	n_posix_char    exec[ N_PATH_MAX ];


	// Phase 2 : set time stamp zero

	n_posix_char *timestamp = "Z:\\c\\@project\\timestamp.exe";

	n_posix_sprintf_literal( exec, "%s %s", timestamp, cmdline );
	n_win_execute( exec, SW_HIDE, n_posix_true );


	// Phase 3 : compress with UPX : currently off

	//n_posix_sprintf_literal( exec, "upx_pack.exe %s", cmdline );
	//n_win_execute( exec, SW_HIDE, n_posix_true );


	// Phase 4 : compress with ArcDrop

	n_posix_char *arcdrop = "Z:\\freewares\\nonnon_win_x64\\arcdrop.exe";

	n_posix_sprintf_literal( exec, "%s %s", arcdrop, cmdline );
	n_win_execute( exec, SW_HIDE, n_posix_true );


	return 0;
}

