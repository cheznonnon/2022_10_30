// Nonnon Win
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#include "../nonnon/neutral/filer.c"
#include "../nonnon/neutral/path.c"

#include "../nonnon/win32/win.c"




int WINAPI
WinMain( HINSTANCE hinst, HINSTANCE prv_hinst, LPSTR cmd, int show )
{

	n_win_cursor_add( NULL, IDC_WAIT );


	n_posix_char *app[] = {
		"ArcDrop",
		"GameConsole",
		"NonnonApps",
		NULL
	};

	n_posix_char *f = "C:\\VC++\\*\\x64\\Release\\*.exe";
	n_posix_char *t = "Z:\\nonnon\\cheznonnon\\nonnon_win\\software\\nonnon_win_x64";


	int i = 0;
	while( 1 )
	{

		n_posix_char str_f[ 1024 ]; n_posix_sprintf_literal( str_f, "%s", f );
		n_string_replace( str_f, str_f, "*", app[ i ] );

		n_posix_char str_t[ 1024 ]; n_posix_sprintf_literal( str_t, "%s\\%s.exe", t, app[ i ] );

		n_filer_merge( str_f, str_t );
//n_posix_debug_literal( "%s", str_f );

		i++;
		if ( app[ i ] == NULL ) { break; }
	}


	n_win_cursor_add( NULL, IDC_ARROW );


	return 0;
}

