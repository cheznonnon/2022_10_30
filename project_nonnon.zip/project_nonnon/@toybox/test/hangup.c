



#include "../../nonnon/win32/win.c"

#include "../../nonnon/project/macro.c"



#define n_win_closebutton_on(  hwnd ) n_win_closebutton_onoff( hwnd, n_true  )
#define n_win_closebutton_off( hwnd ) n_win_closebutton_onoff( hwnd, n_false )

void
n_win_closebutton_onoff( HWND hwnd, n_bool onoff )
{

	UINT mf;


	if ( onoff )
	{
		mf = MF_BYCOMMAND | MF_ENABLED;
	} else {
		mf = MF_BYCOMMAND | MF_DISABLED | MF_GRAYED;
	}

	EnableMenuItem( GetSystemMenu( hwnd, FALSE ), SC_CLOSE, mf );


	return;
}

void
n_win_busyloop( HWND hwnd )
{

	// [!] : call while busy-looping

	// [!] : WinXP or later : ghost window feature is buggy
	//
	//	XP    : a folder will be locked
	//	Vista : removable drive cannot be unplugged

/*
	const  DWORD msec  = 100;
	static DWORD timer = 0;


	if ( ( timer + msec ) < GetTickCount() )
	{
		timer = GetTickCount();
	} else {
		return;
	}
*/

	// [x] : WM_CLOSE will not be sent in some cases
	//
	//	a process will be zombied
	//
	//	system menu is sending WM_CLOSE


	MSG msg;


	if ( FALSE == n_win_message_peek( &msg ) ) { return; }


	if ( msg.message != WM_CLOSE )
	{
		TranslateMessage( &msg );
		DispatchMessage ( &msg );
	}


	return;
}

LRESULT CALLBACK
n_childwindow_wndproc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	switch( msg ) {


	case WM_CREATE :

		n_win_init( hwnd, "Child Window", "", "" );

		n_win_style_new( hwnd, WS_OVERLAPPEDWINDOW );


		n_win_move_simple( hwnd, 0,0,200,0, n_true );


		ShowWindow( hwnd, SW_NORMAL );

	break;


	case WM_CLOSE :

		ShowWindow( hwnd, SW_HIDE );

		DestroyWindow( hwnd );

	break;

	case WM_DESTROY :

		//PostQuitMessage( 0 );

	break;


	} // switch


	return DefWindowProc( hwnd, msg, wparam, lparam );
}

LRESULT CALLBACK
WndProc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	static n_bool onoff = n_false;


	switch( msg ) {


	case WM_CREATE :

		n_win_init( hwnd, "F1 to hang up", "", "" );

		n_win_style_new( hwnd, WS_OVERLAPPEDWINDOW );


		n_win_set( hwnd, NULL, 256,0, N_WIN_SET_CENTERING );


		ShowWindow( hwnd, SW_NORMAL );

	break;


	case WM_KEYDOWN :

		if ( wparam == VK_F1 )
		{

			// child window will also hang up

			static HWND h;

			n_win_gui( hwnd, N_WIN_GUI_WINDOW, n_childwindow_wndproc, &h );


			SetWindowText( hwnd, "F2 to exit" );
			n_win_closebutton_off( hwnd );

			onoff = n_true;

static int i = 0;
			while( 1 )
			{

n_win_hwndprintf_literal( hwnd, "%d", i ); i++;

				if ( n_win_is_input( VK_F2 ) ) { break; }

				n_win_busyloop( hwnd );

			}

			onoff = n_false;

//GetSystemMenu( hwnd, n_true );

			n_win_closebutton_on( hwnd );
			SetWindowText( hwnd, "F1 to hang up" );


			n_win_message_send( h, WM_CLOSE, 0, 0 );

		}

	break;


	case WM_QUERYENDSESSION :

		SetWindowText( hwnd, "You cannot logoff" );

		return FALSE;

	break;


	case WM_CLOSE :

		if ( onoff ) { return n_false; }
n_posix_debug_literal( "WM_CLOSE" );


		ShowWindow( hwnd, SW_HIDE );


		DestroyWindow( hwnd );

	break;

	case WM_DESTROY :

		PostQuitMessage( 0 );

	break;


	} // switch


	return DefWindowProc( hwnd, msg, wparam, lparam );
}

int WINAPI
WinMain( HINSTANCE hinst, HINSTANCE prv_hinst, LPSTR cmd, int show )
{

	// [!] : don't use n_win_main( NULL, WndProc );
	//
	//	because n_win_ghostwindow_disable() is implemented


	//n_win_ghostwindow_disable();


	HWND hwnd;

	n_win_gui( NULL, N_WIN_GUI_WINDOW, WndProc, &hwnd );

	return n_win_msgloop( hwnd ).wParam;
}

