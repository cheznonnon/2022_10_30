// Nonnon Drop2Playlist
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// [!] : this file is based on marie/jukebox.c




#include "../nonnon/project/define_unicode.c"




#include "../nonnon/neutral/dir.c"
#include "../nonnon/neutral/txt.c"


#include "../nonnon/win32/win.c"


#include "../nonnon/project/macro.c"





n_bool
n_drop2playlist_is_empty( n_dir *d )
{

	if ( d == NULL ) { return n_true; }


	n_type_int count = n_dir_all( d );

	if ( count == 0 ) { return n_true; }
	if ( ( count == 1 )&&( n_string_is_empty( n_dir_name( d, 0 ) ) ) ) { return n_true; }


	return n_false;
}

void
n_drop2playlist_shuffle( n_dir *d )
{

	if ( 1 >= n_dir_all( d ) ) { return; }


	n_random_shuffle();

	n_type_int i = 0;
	while( 1 )
	{

		n_type_int r = n_random_range_hq( n_dir_all( d ) );

		n_vector_swap( &d->path, i, r );
		n_vector_swap( &d->name, i, r );
		n_vector_swap( &d->low,  i, r );
		n_vector_swap( &d->ext,  i, r );

		i++;
		if ( i >= n_dir_all( d ) ) { break; }
	}


	return;
}

void
n_drop2playlist_m3u8_save( n_dir *d, const n_posix_char *path )
{

	n_txt txt; n_txt_zero( &txt ); n_txt_new( &txt );
	txt.unicode = N_TXT_UNICODE_UTF;


	n_type_int relpos = n_posix_strlen( path );
//n_posix_debug_literal( "%s", path ); return;


	n_type_int i = 0;
	while( 1 )
	{

		n_posix_char *str = n_string_path_make_new( n_dir_path( d, i ), n_dir_name( d, i ) );
//n_posix_debug_literal( "%d : %s", relpos, str );

		n_posix_sprintf_literal( str, "%s", &str[ relpos ] );
//n_posix_debug_literal( "%s", str );
		n_string_copy( &str[ 1 ], str );
//n_posix_debug_literal( "%s", str );

		n_txt_set( &txt, 0, str );

		n_string_path_free( str );

		i++;
		if ( i >= n_dir_all( d ) ) { break; }
	}


	n_posix_char *name = n_string_path_name_new( path );
	n_posix_char *make = n_string_path_make_new( path, name );
	n_posix_char *m3u8 = n_string_path_ext_mod_new( make, n_posix_literal( ".m3u8\0\0" ) );

	n_txt_save( &txt, m3u8 );

	n_string_path_free( name );
	n_string_path_free( make );
	n_string_path_free( m3u8 );


	n_txt_free( &txt );


	return;
}

n_bool
n_drop2playlist_save( n_posix_char *path )
{

	n_bool ret = n_true;


	if ( n_string_is_empty( path ) ) { return ret; }


	n_dir dir; n_dir *d = &dir; n_dir_zero( d );
	if ( n_dir_load_recursive( d, path ) ) { return ret; }


	n_type_int i = 0;
	while( 1 )
	{

		if (
			( n_string_is_same_literal( ".wav",  n_dir_ext( d, i ) ) )
			||
			( n_string_is_same_literal( ".mp3",  n_dir_ext( d, i ) ) )
			||
			( n_string_is_same_literal( ".wma",  n_dir_ext( d, i ) ) )
			||
			( n_string_is_same_literal( ".aac",  n_dir_ext( d, i ) ) )
			||
			( n_string_is_same_literal( ".flac", n_dir_ext( d, i ) ) )
		)
		{
//n_posix_debug_literal( "%s", n_dir_name( d, i ) );
			// [!] : do nothing
		} else {
			n_dir_del( d, i );
			i--;
		}

		i++;
		if ( i >= n_dir_all( d ) ) { break; }
	}


	if ( n_false == n_drop2playlist_is_empty( d ) )
	{

		n_drop2playlist_shuffle( d );


		n_posix_char *curdir = n_string_path_folder_current_new();
		n_string_path_folder_change( path );

		n_drop2playlist_m3u8_save( d, path );

		n_string_path_folder_change( curdir );
		n_string_path_free( curdir );

//n_vector_save_literal( &d->name, "name.txt", N_STRING_CRLF );

		ret = n_false;

	}


	n_dir_free( d );


	return ret;
}

int WINAPI
WinMain( HINSTANCE hinst, HINSTANCE prv_hinst, LPSTR cmd, int show )
{

	n_win_exedir2curdir();


	n_posix_char *cmdline = n_win_commandline_new();

	if ( n_false == n_drop2playlist_save( cmdline ) )
	{
		n_project_dialog_info( NULL, n_posix_literal( "Done!" ) );
	}

	n_string_path_free( cmdline );


	return 0;
}

