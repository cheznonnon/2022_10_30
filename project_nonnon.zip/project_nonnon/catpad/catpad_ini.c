// CatPad
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Partial File




// internal
void
n_catpad_ini_read( HWND hwnd )
{

	n_posix_char hex[ N_CATPAD_INI_CCH ];


	n_ini ini; n_ini_zero( &ini );
	n_ini_load( &ini, n_project_ini_name );

	n_catpad_nwin.posx                       = n_ini_value_int_literal( &ini, N_CATPAD_APPNAME, "posx",   -1 );
	n_catpad_nwin.posy                       = n_ini_value_int_literal( &ini, N_CATPAD_APPNAME, "posy",   -1 );
	n_catpad_nwin.rcsx                       = n_ini_value_int_literal( &ini, N_CATPAD_APPNAME, "rcsx",   -1 );
	n_catpad_nwin.rcsy                       = n_ini_value_int_literal( &ini, N_CATPAD_APPNAME, "rcsy",   -1 );
	n_catpad_nwin.state                      = n_ini_value_int_literal( &ini, N_CATPAD_APPNAME, "max",     0 );
	n_catpad_txtbox_search.input_resizer_max = n_ini_value_int_literal( &ini, N_CATPAD_APPNAME, "find_sx", 0 );
	n_catpad_txtbox_onoff_default            = n_ini_value_int_literal( &ini, N_CATPAD_APPNAME, "txtbox",  1 );

	n_ini_value_str_literal( &ini, N_CATPAD_APPNAME, "lf",   "",          hex , N_CATPAD_INI_CCH );
	n_ini_value_str_literal( &ini, N_CATPAD_APPNAME, "find", "", n_catpad_find, N_CATPAD_INI_CCH );
	n_ini_value_str_literal( &ini, N_CATPAD_APPNAME, "tab",  "", n_catpad_tab , N_CATPAD_INI_CCH );
	n_ini_value_str_literal( &ini, N_CATPAD_APPNAME, "eol",  "", n_catpad_eol , N_CATPAD_INI_CCH );

	n_ini_free( &ini );


	n_catpad_nwin_ini = n_catpad_nwin;


//n_posix_debug( hex );
	if ( n_string_is_empty( hex ) )
	{
		n_catpad_hfont = n_win_font_name2hfont( n_posix_literal( "FixedSys" ), n_font_size_default( hwnd ) );
	} else {
		n_catpad_hfont = n_font_hexdump2hfont( hex );
	}


	return;
}

// internal
void
n_catpad_ini_write( void )
{

	n_posix_char str_hex[ 1024 ]; n_font_hfont2hexdump( n_catpad_hfont, str_hex );
	n_posix_char str_fnd[ 1024 ]; n_string_copy( n_catpad_find, str_fnd ); n_ini_value_escape( str_fnd );
	n_posix_char str_tab[ 1024 ]; n_string_copy( n_catpad_tab , str_tab ); n_ini_value_escape( str_tab );
	n_posix_char str_eol[ 1024 ]; n_string_copy( n_catpad_eol , str_eol ); n_ini_value_escape( str_eol );

	n_type_gfx   fnd_sx = n_catpad_txtbox_search.input_resizer_max;


	n_ini ini;n_ini_zero( &ini );
	n_ini_load( &ini, n_project_ini_name );


	n_ini_section_add_literal( &ini, N_CATPAD_APPNAME );

	n_ini_key_add_int_literal( &ini, N_CATPAD_APPNAME, "posx   ", n_catpad_nwin_ini.posx  );
	n_ini_key_add_int_literal( &ini, N_CATPAD_APPNAME, "posy   ", n_catpad_nwin_ini.posy  );
	n_ini_key_add_int_literal( &ini, N_CATPAD_APPNAME, "rcsx   ", n_catpad_nwin_ini.rcsx  );
	n_ini_key_add_int_literal( &ini, N_CATPAD_APPNAME, "rcsy   ", n_catpad_nwin_ini.rcsy  );
	n_ini_key_add_int_literal( &ini, N_CATPAD_APPNAME, "max    ", n_catpad_nwin_ini.state );
	n_ini_key_add_int_literal( &ini, N_CATPAD_APPNAME, "find_sx", fnd_sx                  );
	n_ini_key_add_str_literal( &ini, N_CATPAD_APPNAME, "lf     ", str_hex                 );
	n_ini_key_add_str_literal( &ini, N_CATPAD_APPNAME, "find   ", str_fnd                 );

	// [!] : allow user's setting
	{
		n_bool onoff = n_ini_value_int_literal( &ini, N_CATPAD_APPNAME, "txtbox", 1 );
		n_ini_key_add_int_literal( &ini, N_CATPAD_APPNAME, "txtbox ", onoff );
	}

	n_ini_key_add_str_literal( &ini, N_CATPAD_APPNAME, "tab    ", str_tab                 );
	n_ini_key_add_str_literal( &ini, N_CATPAD_APPNAME, "eol    ", str_eol                 );


	n_ini_save( &ini, n_project_ini_name );
	n_ini_free( &ini );


	n_explorer_refresh( n_false );


	return;
}

