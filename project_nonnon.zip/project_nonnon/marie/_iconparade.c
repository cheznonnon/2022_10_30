// Marie
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#include "../nonnon/win32/gdi.c"




// internal
void
n_marie_iconparade_empty( n_bmp *bmp, n_type_gfx sx, n_type_gfx sy )
{

	n_gdi gdi; n_gdi_zero( &gdi );


	gdi.sx            = sx;
	gdi.sy            = sy;
	gdi.scale         = N_GDI_SCALE_AUTO;
	gdi.style         = N_GDI_DEFAULT;

	gdi.base_color_bg = n_bmp_white;
	gdi.base_color_fg = n_bmp_white;
	gdi.base_style    = N_GDI_BASE_SOLID;

	gdi.frame_style   = N_GDI_FRAME_SIMPLE;


	n_gdi_bmp( &gdi, bmp );


	return;
}

// internal
void
n_marie_iconparade_icon( n_bmp *bmp, n_posix_char *icon, n_type_gfx index, n_bool is_resource )
{

	n_gdi gdi; n_gdi_zero( &gdi );


	gdi.sx            = 0;
	gdi.sy            = 0;
	gdi.scale         = N_GDI_SCALE_AUTO;
	gdi.style         = N_GDI_DEFAULT;

	gdi.base_color_bg = n_bmp_white;
	gdi.base_color_fg = n_bmp_white;
	gdi.base_style    = N_GDI_BASE_SOLID;

	gdi.frame_style   = N_GDI_FRAME_SIMPLE;

	gdi.icon          = icon;
	gdi.icon_index    = index;
	gdi.icon_style    = N_GDI_ICON_DEFAULT;

	if ( is_resource ) { gdi.icon_style = N_GDI_ICON_RESOURCE; }


	n_gdi_bmp( &gdi, bmp );


	return;
}

// internal
void
n_marie_iconparade_number( n_bmp *bmp, n_type_int n, n_type_gfx sx, n_type_gfx sy )
{

	n_gdi gdi; n_gdi_zero( &gdi );


	gdi.sx              = sx;
	gdi.sy              = sy;
	gdi.scale           = N_GDI_SCALE_AUTO;
	gdi.style           = N_GDI_DEFAULT;

	gdi.base_color_bg   = n_bmp_white;
	gdi.base_color_fg   = n_bmp_white;
	gdi.base_style      = N_GDI_BASE_SOLID;

	gdi.frame_style     = N_GDI_FRAME_SIMPLE;


	n_posix_char str[ N_STRING_INT2STR_CCH_MAX ]; n_string_int2str( str, n );

	gdi.text            = str;
	gdi.text_font       = n_project_stdfont();
	gdi.text_size       = n_posix_min_n_type_gfx( sx, sy ) / 2;
	gdi.text_color_main = n_bmp_rgb(  10,150,200 );
	gdi.text_style      = N_GDI_TEXT_BOLD | N_GDI_TEXT_SMOOTH;


	n_gdi_bmp( &gdi, bmp );


	return;
}

n_bool
n_marie_iconparade_load( n_bmp *bmp, n_posix_char *cmdline, n_bool is_resource )
{

	// Phase 1 : is loadable

	UINT count = n_win_icon_maxcount( cmdline );
	if ( count <= 0 ) { return n_true; }


	// Phase 2 : calculate unit size

	n_bmp icon; n_bmp_zero( &icon );

	n_marie_iconparade_icon( &icon, cmdline, 0, is_resource );

	n_type_gfx icon_sx = N_BMP_SX( &icon );
	n_type_gfx icon_sy = N_BMP_SY( &icon );

	n_bmp_free( &icon );


	// [Mechanism]
	//
	//	|  | 0 | 1 | 2 |
	//	|10|   |   |   |
	//	|20|   |   |   |
	//	|30|   |   |   |

	n_type_gfx sx = icon_sx * ( 10 );
	n_type_gfx sy = icon_sy * ( ( count / 10 ) + ( 0 != ( count % 10 ) ) );

	sx += icon_sx;
	sy += icon_sy;


	// Phase 3 : draw

	n_bmp_new_fast( bmp, sx,sy );


	n_type_gfx x = 0;
	n_type_gfx y = 0;
	n_type_gfx i = 0;
	n_posix_loop
	{

		if ( ( y == 0 )&&( x == 0 ) )
		{
			n_marie_iconparade_empty( &icon, icon_sx, icon_sy );
		} else
		if ( y == 0 )
		{
			n_marie_iconparade_number( &icon, ( x / icon_sx ) - 1, icon_sx, icon_sy );
		} else
		if ( x == 0 )
		{
			n_marie_iconparade_number( &icon, ( ( y / icon_sy ) - 1 ) * 10, icon_sx, icon_sy );
		} else
		if ( i < (n_type_int) count )
		{
			n_marie_iconparade_icon( &icon, cmdline, i, is_resource ); i++;
		} else {
			n_marie_iconparade_empty( &icon, icon_sx, icon_sy );
		}

		n_bmp_fastcopy( &icon, bmp, 0,0,N_BMP_SX( &icon ),N_BMP_SY( &icon ), x,y );


		x += icon_sx;
		if ( x >= sx )
		{

			x = 0;

			y += icon_sy;
			if ( y >= sy ) { break; }
		}


	}


	n_bmp_free( &icon );


	return n_false;
}

