// Marie
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Partial File




typedef struct {

	n_type_real percent;
	n_type_gfx  unit;
	n_type_gfx  band_x, band_y, band_sx, band_sy;
	n_type_gfx  play_x, play_y, play_sx, play_sy;
	n_type_gfx  stop_x, stop_y, stop_sx, stop_sy;
	n_type_gfx  seek_x, seek_y, seek_sx, seek_sy;

} n_vfw_ui;




#define n_vfw_ui_zero( vfw_ui ) n_memory_zero( vfw_ui, sizeof( n_vfw_ui ) )

void
n_vfw_ui_metric( n_vfw *vfw, n_vfw_ui *vfw_ui )
{

	n_type_gfx m; n_win_stdsize( vfw->hwnd, &vfw_ui->unit, NULL, &m );
	n_type_gfx u  = vfw_ui->unit - ( m * 2 );

	n_type_gfx sx;
	if ( n_vfw_is_audio( vfw ) ) { sx = vfw_ui->unit * 12; } else { sx = vfw->csx; }


	vfw_ui->band_x  = 0;
	vfw_ui->band_y  = vfw->csy;
	vfw_ui->band_sx = sx;
	vfw_ui->band_sy = vfw_ui->unit;

	vfw_ui->stop_x  = m + vfw_ui->band_x + ( vfw_ui->unit * 0 );
	vfw_ui->stop_y  = ( vfw_ui->band_sy - vfw_ui->unit ) / 2;
	vfw_ui->stop_sx = u;
	vfw_ui->stop_sy = u;

	vfw_ui->play_x  = m + vfw_ui->band_x + ( vfw_ui->unit * 1 );
	vfw_ui->play_y  = ( vfw_ui->band_sy - vfw_ui->unit ) / 2;
	vfw_ui->play_sx = u;
	vfw_ui->play_sy = u;

	n_type_gfx seek_sy = ( u / 3 ); seek_sy += ( 0 == ( seek_sy % 2 ) );

	vfw_ui->seek_x  = m + vfw_ui->band_x + ( vfw_ui->unit * 2 );
	vfw_ui->seek_y  = ( ( vfw_ui->band_sy - seek_sy ) / 2 );
	vfw_ui->seek_sx = ( vfw_ui->band_sx - ( vfw_ui->unit * 2 ) ) - ( m * 2 );
	vfw_ui->seek_sy = seek_sy;

	vfw_ui->seek_x  += m;
	vfw_ui->seek_sx -= m * 2;


	return;
}

n_bool
n_vfw_ui_play_is_hovered( n_vfw *vfw, n_vfw_ui *vfw_ui )
{

	HWND       hwnd = GetParent( vfw->hwnd );
	n_type_gfx    x = vfw_ui->play_x;
	n_type_gfx    y = vfw_ui->play_y;
	n_type_gfx   sx = vfw_ui->play_sx;
	n_type_gfx   sy = vfw_ui->play_sy;

	if ( n_false == n_vfw_is_audio( vfw ) ) { y += vfw->csy; }

	return n_win_is_hovered_offset( hwnd, x,y,sx,sy );
}

n_bool
n_vfw_ui_stop_is_hovered( n_vfw *vfw, n_vfw_ui *vfw_ui )
{

	HWND       hwnd = GetParent( vfw->hwnd );
	n_type_gfx    x = vfw_ui->stop_x;
	n_type_gfx    y = vfw_ui->stop_y;
	n_type_gfx   sx = vfw_ui->stop_sx;
	n_type_gfx   sy = vfw_ui->stop_sy;

	if ( n_false == n_vfw_is_audio( vfw ) ) { y += vfw->csy; }

	return n_win_is_hovered_offset( hwnd, x,y,sx,sy );
}

n_bool
n_vfw_ui_seek_is_hovered( n_vfw *vfw, n_vfw_ui *vfw_ui )
{

	HWND       hwnd = GetParent( vfw->hwnd );
	n_type_gfx    x = vfw_ui->seek_x;
	n_type_gfx    y = vfw_ui->seek_y;
	n_type_gfx   sx = vfw_ui->seek_sx;
	n_type_gfx   sy = vfw_ui->seek_sy;

	if ( n_false == n_vfw_is_audio( vfw ) ) { y += vfw->csy; }

	return n_win_is_hovered_offset( hwnd, x,y,sx,sy );
}

n_type_gfx
n_vfw_ui_seek_position( n_vfw *vfw, n_vfw_ui *vfw_ui )
{

	n_type_gfx m; n_win_stdsize( vfw->hwnd, NULL, NULL, &m );
	n_type_gfx x; n_win_cursor_position_relative( vfw->hwnd, &x, NULL );

//n_win_hwndprintf_literal( GetParent( vfw->hwnd ), "%d", x - vfw->seek_x );

	return x - vfw_ui->seek_x + m;
}

void
n_vfw_ui_make( n_vfw *vfw, n_vfw_ui *vfw_ui, n_bmp *bmp )
{

	n_bmp_new_fast( bmp, vfw_ui->band_sx, vfw_ui->band_sy );
	n_bmp_flush( bmp, n_bmp_black_invisible );


	return;
}

#define N_MARIE_VFW_UI_PLAY  1
#define N_MARIE_VFW_UI_PAUSE 2
#define N_MARIE_VFW_UI_STOP  3

void
n_vfw_ui_button_make( n_vfw *vfw, n_vfw_ui *vfw_ui, n_bmp *bmp, n_type_real ratio, int type )
{

	// [!] : use n_bmp_rasterizer()


	const u32 color = n_bmp_white;


	n_type_gfx sx = (n_type_gfx) ( (n_type_real) vfw_ui->unit * ratio );
	n_type_gfx sy = (n_type_gfx) ( (n_type_real) vfw_ui->unit * ratio );

	// [Patch] : beautiful at odd number

	sx += ( 0 != ( sx % 2 ) );
	sy += ( 0 != ( sy % 2 ) );


	n_type_gfx  x = ( vfw_ui->unit - sx ) / 2;
	n_type_gfx  y = ( vfw_ui->unit - sy ) / 2;


	n_bmp_new( bmp, vfw_ui->unit, vfw_ui->unit );

	if ( type == N_MARIE_VFW_UI_PLAY )
	{

		n_type_gfx u  = sx / 3 * 2;

		n_type_gfx fx = x + ( ( sx - u ) / 2 );
		n_type_gfx fy = y;
		n_type_gfx tx = fx + ( u );
		n_type_gfx ty = fy + ( sy );
		n_type_gfx hy = fy + ( sy / 2 );

		n_bmp_line( bmp, fx,fy, tx,hy, color );
		n_bmp_line( bmp, fx,ty, tx,hy, color );
		n_bmp_line( bmp, fx,fy, fx,ty, color );

		n_bmp_fill( bmp, fx + 1, hy, color );

	} else
	if ( type == N_MARIE_VFW_UI_PAUSE )
	{

		n_type_gfx u = sx / 3;

		n_bmp_box( bmp, x + ( u * 0 ), y, u, sy, color );
		n_bmp_box( bmp, x + ( u * 2 ), y, u, sy, color );

	} else
	if ( type == N_MARIE_VFW_UI_STOP )
	{

		n_bmp_box( bmp, x, y, sx, sy, color );

	}// else


	return;
}

void
n_vfw_ui_button_draw( n_vfw *vfw, n_vfw_ui *vfw_ui, n_bmp *bmp, int type, n_type_gfx x, n_type_gfx y, u32 bg, u32 mg, u32 fg )
{

	// Erase

	n_bmp_box( bmp, x,y,vfw_ui->unit,vfw_ui->unit, bg );


	// Resource

	n_bmp b; n_bmp_zero( &b );

	n_vfw_ui_button_make( vfw, vfw_ui, &b, 0.333, type );


	// Fog Shadow

	n_bmp_transparent_onoff( &b, n_false );

	n_bmp_rasterizer( &b, bmp, x - 1, y - 1, mg, 0 );
	n_bmp_rasterizer( &b, bmp, x + 0, y - 1, mg, 0 );
	n_bmp_rasterizer( &b, bmp, x + 1, y - 1, mg, 0 );
	n_bmp_rasterizer( &b, bmp, x - 1, y - 0, mg, 0 );

	n_bmp_rasterizer( &b, bmp, x + 1, y + 0, mg, 0 );
	n_bmp_rasterizer( &b, bmp, x - 1, y + 1, mg, 0 );
	n_bmp_rasterizer( &b, bmp, x + 0, y + 1, mg, 0 );
	n_bmp_rasterizer( &b, bmp, x + 1, y + 1, mg, 0 );

	n_bmp_antialias( bmp, x,y,vfw_ui->unit,vfw_ui->unit, 1.0 );


	// Main

	n_bmp_rasterizer( &b, bmp, x, y, fg, 0 );


	// Cleanup

	n_bmp_free( &b );


	return;
}

#define n_vfw_ui_draw( vfw, vfw_ui, bmp ) n_vfw_ui_draw_all( vfw, vfw_ui, bmp, n_false )

n_bool
n_vfw_ui_draw_all( n_vfw *vfw, n_vfw_ui *vfw_ui, n_bmp *bmp, n_bool is_forced )
{

	// [x] : Win95 hasn't WebDings
	// [x] : Marlett hasn't [||] like font

	const u32 color_bg      = n_bmp_black_invisible;
	const u32 color_fg      = n_bmp_white;
	const u32 color_fog_fg = n_win_dwm_windowcolor();
	const u32 color_fog_bg = n_bmp_blend_pixel( n_bmp_black, color_fog_fg, 0.5 );


	n_bool ret = n_false;


	// [!] : playback status is changed

	static int status_prv = 0;
	       int status_cur = N_MARIE_VFW_UI_PLAY;

	if ( ( n_vfw_is_stopped( vfw ) )||( n_vfw_is_paused( vfw ) ) )
	{
		status_cur = N_MARIE_VFW_UI_PLAY;
	} else
	if ( n_vfw_is_playing( vfw ) )
	{
		status_cur = N_MARIE_VFW_UI_PAUSE;
	}// else


	// Buttons

	{

		static n_bool prv = n_false;
		       n_bool cur = n_vfw_ui_stop_is_hovered( vfw, vfw_ui );

		if ( ( status_prv != status_cur )||( is_forced ) ) { prv = -1; }

		if ( prv != cur )
		{

			prv = cur;


			n_type_gfx x = vfw_ui->stop_x;
			n_type_gfx y = vfw_ui->stop_y;

			u32 mg = color_fog_bg;
			if ( cur ) { mg = color_fog_fg; }

			n_vfw_ui_button_draw( vfw, vfw_ui, bmp, N_MARIE_VFW_UI_STOP, x,y, color_bg, mg, color_fg );

			ret = n_true;

		}

	}

	{

		static n_bool prv = n_false;
		       n_bool cur = n_vfw_ui_play_is_hovered( vfw, vfw_ui );

		if ( ( status_prv != status_cur )||( is_forced ) ) { prv = -1; }

		if ( prv != cur )
		{

			prv = cur;


			n_type_gfx x = vfw_ui->play_x;
			n_type_gfx y = vfw_ui->play_y;

			u32 mg = color_fog_bg;
			if ( cur ) { mg = color_fog_fg; }

			n_vfw_ui_button_draw( vfw, vfw_ui, bmp, status_cur, x,y, color_bg, mg, color_fg );

			ret = n_true;

		}

	}


	// Progressbar

	n_type_real percent = n_vfw_percent( vfw );


	static n_type_real smooth = 0;
/*
	static n_type_real differ = 0;

	if ( n_vfw_is_playing( vfw ) )
	{

		static n_type_real tick_prv = -1;
		if ( tick_prv == -1 ) { tick_prv = n_posix_tickcount(); }

		n_type_real tick_cur = n_posix_tickcount();

		if ( vfw_ui->percent == percent )
		{
			smooth += ( tick_cur - tick_prv ) * 0.01;
			smooth  = n_posix_min_n_type_real( differ, smooth );
			is_forced = n_true;
		} else {
			smooth = 0;
			differ = percent - vfw_ui->percent;
		}

		tick_prv = tick_cur;

//n_win_hwndprintf_literal( GetParent( vfw->hwnd ), "%f", smooth );
//n_win_hwndprintf_literal( GetParent( vfw->hwnd ), "%f", vfw_ui->percent + smooth );

	} else {

		smooth = differ = 0;

	}
*/

	if (
		( is_forced )
		||
		( vfw_ui->percent != percent )
		||
		(
			( n_game_progressbar_animation != N_GAME_PROGRESSBAR_ANIMATION_OFF )
			&&
			( n_vfw_is_playing( vfw ) )
		)
	)
	{

		n_type_real pc = percent + smooth;

		vfw_ui->percent = percent;

		n_type_gfx x  = vfw_ui->seek_x;
		n_type_gfx y  = vfw_ui->seek_y;
		n_type_gfx sx = vfw_ui->seek_sx;
		n_type_gfx sy = vfw_ui->seek_sy;

		n_bmp_box( bmp, x,y,sx,sy, color_bg );

		n_game_progressbar_round_div = 4;

		x  += 1;
		y  += 1;
		sx -= 2;
		sy -= 2;

		n_game_progressbar_horz( bmp, x,y,sx,sy, color_fog_bg, color_fog_bg, pc, sy );
		n_bmp_antialias( bmp, x,y,sx,sy, 1.0 );

		n_game_progressbar_horz( bmp, x,y,sx,sy, color_fog_fg, color_fog_bg, pc, sy );

		ret = n_true;

	}


	status_prv = status_cur;


	return ret;
}

void
n_vfw_ui_reset( n_vfw *vfw, n_vfw_ui *vfw_ui, n_bmp *bmp )
{

	n_vfw_ui_metric( vfw, vfw_ui );


	if ( n_project_dwm_is_on() )
	{

		HWND hwnd = GetParent( vfw->hwnd );

		if ( n_false == n_vfw_is_audio( vfw ) )
		{
			n_win_dwm_transparent_on_partial( hwnd, 0,0,0,vfw_ui->band_sy );
		} else {
			n_win_dwm_transparent_on( hwnd );
		}

	}


	n_vfw_ui_make( vfw, vfw_ui, bmp );
	n_vfw_ui_draw_all( vfw, vfw_ui, bmp, n_true );


	return;
}


