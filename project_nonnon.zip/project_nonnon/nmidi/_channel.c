// nmidi
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Partial File




#define N_CHANNEL_MAX ( N_MIDI_CHANNEL_MAX - 1 )




typedef struct {

	// internal

	int    sound;
	int    panpot;

	n_bmp *bmp;
	int    count;

	// [!] : temporary use

	int    note;
	int    volume;

} n_channel;




#define n_channel_zero( p ) n_memory_zero( p, sizeof( n_channel ) )

void
n_channel_free( n_channel *p )
{

	int i = 0;
	n_posix_loop
	{

		if ( i >= p->count ) { break; }

		n_bmp_free( &p->bmp[ i ] );

		i++;

	}

	n_memory_free( p->bmp );


	n_channel_zero( p );


	return;
}

void
n_channel_new( n_channel *p, int sound, int panpot, int note_count )
{

	n_channel_free( p );


	p->sound  = sound;
	p->panpot = panpot;
	p->count  = note_count;
	p->bmp    = n_memory_new( p->count * sizeof( n_bmp ) );

	n_memory_zero( p->bmp, p->count * sizeof( n_bmp ) );


	return;
}

void
n_channel_bulk_free( n_channel *p )
{

	int i = 0;
	n_posix_loop
	{

		n_channel_free( &p[ i ] );

		i++;
		if ( i >= N_CHANNEL_MAX ) { break; }
	}


	return;
}

n_bool
n_channel_bulk_new( n_channel *p, const n_bmp *data )
{

	int i = 0;
	n_posix_loop
	{

		n_channel_new( &p[ i ], 0, N_MIDI_PANPOT_CENTER, N_BMP_SX( data ) );

		i++;
		if ( i >= N_CHANNEL_MAX ) { break; }
	}


	return n_false;
}

n_bool
n_channel_bulk_load( n_channel *p, const n_bmp *data )
{

	int i = 0;
	n_posix_loop
	{

		int channel, sound, panpot;
		n_midi_bmp_channel_get( data, i, &channel, &sound, &panpot );
//n_posix_debug_literal( "Ch.#%d : %d", i, panpot );

		n_channel_new( &p[ i ], sound, panpot, N_BMP_SX( data ) );

		i++;
		if ( i >= N_CHANNEL_MAX ) { break; }
	}


	return n_false;
}

void
n_channel_reload( n_channel *p, int count )
{

	if ( p->count == count )
	{

		// [!] : nothing to do

	} else
	if ( p->count > count )
	{

		// [!] : shrink

		int i = count;
		n_posix_loop
		{

			if ( i >= p->count ) { break; }

			n_bmp_free( &p->bmp[ i ] );

			i++;

		}

		p->count = count;
		p->bmp   = n_memory_resize( p->bmp, p->count * sizeof( n_bmp ) );

	} else
	if ( p->count < count )
	{

		// [!] : enlarge

		p->bmp = n_memory_resize( p->bmp, count * sizeof( n_bmp ) );

		int i = p->count;
		n_posix_loop
		{

			if ( i >= count ) { break; }

			n_bmp_zero( &p->bmp[ i ] );

			i++;

		}

		p->count = count;

	}


	return;
}

n_bool
n_channel_bulk_reload( n_channel *p, const n_bmp *data )
{

	int i = 0;
	n_posix_loop
	{

		n_channel_reload( &p[ i ], N_BMP_SX( data ) );

		i++;
		if ( i >= N_CHANNEL_MAX ) { break; }
	}


	return n_false;
}

