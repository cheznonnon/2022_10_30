// nmidi
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#ifndef NONNON_APPS

#include "../nonnon/project/define_unicode.c"

#endif // #ifndef NONNON_APPS




//#define N_MEMORY_DEBUG




#include "../nonnon/game/timegettime.c"

#include "../nonnon/neutral/midi.c"

#include "../nonnon/win32/ole/IDropTarget.c"
#include "../nonnon/win32/explorer.c"
#include "../nonnon/win32/gdi.c"
#include "../nonnon/win32/win.c"
#include "../nonnon/win32/win_button.c"
#include "../nonnon/win32/win_combobox.c"
#include "../nonnon/win32/win_groupbox.c"
#include "../nonnon/win32/win_progressbar.c"
#include "../nonnon/win32/win_scroller.c"
#include "../nonnon/win32/win_separator.c"

#include "../nonnon/game/hmidiout.c"
#include "../nonnon/game/progressbar.c"


#include "../nonnon/project/macro.c"




// [!] : Components : independent

#include "./__midi_bmp.c"
#include "./__midi_random.c"
#include "./__midi_string.c"




// [!] : Shared

#define N_NMIDI_EXT_BMP n_posix_literal( ".bmp\0\0" )
#define N_NMIDI_EXT_MID n_posix_literal( ".mid\0\0" )
#define N_NMIDI_EXT_TXT n_posix_literal( ".txt\0\0" )


#define H_BAND       n_nmidi_hgui[ 0 ]
#define H_STA_CANVAS n_nmidi_hgui[ 1 ]
#define GUI_MAX                    2

#define H_BTN_RANDOM n_nmidi_hbtn[ 0 ]
#define H_BTN_SAVE   n_nmidi_hbtn[ 1 ]
#define H_BTN_CONFIG n_nmidi_hbtn[ 2 ]
#define H_BTN_PLUS   n_nmidi_hbtn[ 3 ]
#define H_BTN_MINUS  n_nmidi_hbtn[ 4 ]
#define BTN_MAX                    5


static HWND         n_nmidi_hgui[ GUI_MAX ];
static n_win_button n_nmidi_hbtn[ BTN_MAX ];


void
n_nmidi_bulk_enablewindow( n_bool onoff )
{

	int i = 0;
	n_posix_loop
	{

		EnableWindow( n_nmidi_hgui[ i ], onoff );

		i++;
		if ( i >= GUI_MAX ) { break; }
	}

	i = 0;
	n_posix_loop
	{

		n_win_button_grayed_onoff( &n_nmidi_hbtn[ i ], ( onoff == n_posix_false ) );

		i++;
		if ( i >= BTN_MAX ) { break; }
	}


	return;
}




// Components

#ifndef NONNON_APPS

#define N_APPS_ICON_OFFSET_NMIDI ( 0 )

#endif // #ifndef NONNON_APPS


#define N_NMIDI_UNIT_QUARTER   ( N_MIDI_TIMEBASE )
#define N_NMIDI_UNIT_BAR       ( N_NMIDI_UNIT_QUARTER * 4 )

#define n_nmidi_beat2unit( n ) ( N_NMIDI_UNIT_BAR / n )
#define n_nmidi_unit2beat( n ) ( N_NMIDI_UNIT_BAR / n )


#define N_NMIDI_COLOR_TRANS  n_bmp_white_invisible
#define N_NMIDI_COLOR_FG     n_bmp_rgb(   0,200,255 )
#define N_NMIDI_COLOR_NOTE   n_bmp_rgb( 111,111,111 )
#define N_NMIDI_COLOR_LINE   n_bmp_rgb( 222,222,222 )
#define N_NMIDI_COLOR_BORDER n_bmp_rgb( 111,111,111 )

static u32 N_NMIDI_COLOR_BG      = n_bmp_rgb( 255,255,255 );
static u32 N_NMIDI_COLOR_SELECT  = n_bmp_rgb( 255,255,255 );
static u32 N_NMIDI_COLOR_HEADER  = n_bmp_rgb(   0,150,200 );
static u32 N_NMIDI_COLOR_CONTOUR = n_bmp_rgb( 255,255,255 );


#include "./nmidi_canvas.c"

#include "./nmidi_config.c"
#include "./nmidi_config_note.c"


static n_nmidi_config      n_midi_config;
static n_nmidi_config_note n_midi_config_note;




void
n_midi_draw_frame( n_bmp *bmp, n_type_gfx x, n_type_gfx y, n_type_gfx sx, n_type_gfx sy, u32 fg, u32 bg )
{

	if ( n_bmp_error( bmp ) ) { return; }


	n_type_gfx fx  = x;
	n_type_gfx fy  = y;
	n_type_gfx tx  = x + sx - 1;
	n_type_gfx ty  = y + sy - 1;


	// Top
	n_bmp_line_dot( bmp, fx,fy,tx,fy, fg, 1 );
	n_bmp_line_dot( bmp, fx,fy,tx,fy, bg, 2 );

	// Bottom
	n_bmp_line_dot( bmp, fx,ty,tx,ty, fg, 1 );
	n_bmp_line_dot( bmp, fx,ty,tx,ty, bg, 2 );


	fy++;
	ty--;

	// Left
	n_bmp_line_dot( bmp, fx,fy,fx,ty, fg, 1 );
	n_bmp_line_dot( bmp, fx,fy,fx,ty, bg, 2 );

	// Right
	n_bmp_line_dot( bmp, tx,fy,tx,ty, fg, 1 );
	n_bmp_line_dot( bmp, tx,fy,tx,ty, bg, 2 );


	return;
}

// internal
void
n_nmidi_title( HWND hwnd, const n_posix_char *name )
{

	n_posix_char *s = n_string_carboncopy( name );
	n_string_replace( s, s, N_STRING_BSLASH, N_STRING_SLASH );

	n_win_hwndprintf_literal( hwnd, "%s - nmidi", s );

	n_memory_free( s );


	return;
}

n_posix_char*
n_nmidi_commandline( void )
{

	// [Neded] : n_string_path_free()


	n_posix_char *str = n_win_commandline_new();

#ifdef NONNON_APPS

		// [Needed] : for Nonnon Apps

		n_string_commandline_option( N_APPS_OPTION_NMIDI, str );

#endif // #ifdef NONNON_APPS

	if ( n_string_commandline_option_literal( "-log", str ) ) { canvas.logging_onoff = n_true; }


	return str;
}

n_bool
n_nmidi_newfile_txt( void )
{

	n_bool ret = n_false;


	n_posix_char *str = n_nmidi_commandline();

	if ( n_string_path_ext_is_same( N_NMIDI_EXT_TXT, str ) )
	{

		n_midi_encode( str, canvas.logging_onoff );

		n_explorer_refresh( n_false );

		ret = n_true;

	}

	n_string_path_free( str );


	return ret;
}

n_bool
n_nmidi_newfile( HWND hwnd, const n_posix_char *name )
{

	n_posix_char *str;

	if ( n_string_is_empty( name ) )
	{
		str = n_nmidi_commandline();
	} else {
		str = n_string_path_carboncopy( name );
	}


	if ( n_string_path_ext_is_same( N_NMIDI_EXT_BMP, str ) )
	{

		n_nmidi_canvas_init( &canvas, H_STA_CANVAS, str );
		n_string_path_free( str );

		n_nmidi_title( hwnd, canvas.path );

		n_nmidi_canvas_refresh( &canvas );

	} else
	if ( n_string_path_ext_is_same( N_NMIDI_EXT_MID, str ) )
	{

		n_posix_char *exe = n_string_path_cat( n_posix_literal( "nonnonapps.exe -marie" ), N_STRING_SPACE, str, NULL );

		n_win_exedir2curdir();
		n_win_exec( exe, SW_NORMAL );

		n_string_path_free( exe );
		n_string_path_free( str );

		return n_true;

	} else
	if ( n_string_path_ext_is_same( N_NMIDI_EXT_TXT, str ) )
	{

		n_midi_encode( str, canvas.logging_onoff );
		n_string_path_free( str );

		n_explorer_refresh( n_false );

		return n_true;

	} else {

		n_nmidi_canvas_init( &canvas, H_STA_CANVAS, str );
		n_string_path_free( str );

		n_nmidi_title( hwnd, canvas.path );

		n_nmidi_canvas_refresh( &canvas );

	}


	return n_false;
}

void
n_nmidi_resize( HWND hwnd )
{

	const n_bool redraw = n_true;


	n_type_gfx ctl,ico,m;
	n_win_stdsize( hwnd, &ctl, &ico, &m );

	n_type_gfx gap = H_BTN_RANDOM.maclike_offset / 2;


	static n_bool is_first = n_true;

	n_type_gfx nws = N_WIN_SET_DEFAULT;
	n_type_gfx csx = -1;
	n_type_gfx csy = -1;

	if ( is_first )
	{
//n_posix_debug_literal( "1" );

		is_first = n_false;

		nws = N_WIN_SET_CENTERING;

		n_win_desktop_size( &csx, &csy );

		n_type_gfx min_sx = canvas.header_sx * 2;
		n_type_gfx min_sy = ( canvas.stdsize_ico + ( canvas.stdsize_m * 2 ) ) + canvas.header_sy + canvas.stdsize_ctl;
		n_type_gfx max_sx = (n_type_gfx) ( (n_type_real) csx * 0.8 );
		n_type_gfx max_sy = (n_type_gfx) ( (n_type_real) csy * 0.4 );

		csx = n_posix_minmax( min_sx, max_sx, canvas.header_sx * 5 );
		csy = n_posix_minmax( min_sy, max_sy,           max_sy     );

		csx += m;
		csy += m;

	} else {
//n_posix_debug_literal( "2" );

		nws = n_project_n_win_set();

	}

	n_win w;
	n_win_set( hwnd, &w, csx, csy, nws );
	csx = w.csx - m;
	csy = w.csy - m;

	n_win_move_simple( H_BAND, 0,0, w.csx,ico+gap, redraw );

	n_type_gfx ssx = csx;
	n_type_gfx ssy = csy - ( ico * 1 ) - gap;
	n_type_gfx sy  = ico + gap;

	n_type_gfx ox = ico * 0;

	n_win_button_move_toolband( &H_BTN_RANDOM, ox, ico * 0, ico,ico, redraw ); ox += ico + gap;
	n_win_button_move_toolband( &H_BTN_SAVE  , ox, ico * 0, ico,ico, redraw ); ox += ico + gap;
	n_win_button_move_toolband( &H_BTN_CONFIG, ox, ico * 0, ico,ico, redraw ); ox += ico + gap;
	n_win_button_move_toolband( &H_BTN_PLUS  , ox, ico * 0, ico,ico, redraw ); ox += ico + gap;
	n_win_button_move_toolband( &H_BTN_MINUS , ox, ico * 0, ico,ico, redraw ); ox += ico + gap;
	n_win_move_simple         (  H_STA_CANVAS,  0,      sy, ssx,ssy, redraw );

	n_nmidi_canvas_refresh( &canvas );


	return;
}

void
n_nmidi_proc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	switch( msg ) {


	case WM_MOUSEMOVE :

		if (      n_midi_config.onoff ) { break; }
		if ( n_midi_config_note.onoff ) { break; }

		n_nmidi_canvas_collision( &canvas );

	break;


	case WM_MOUSEWHEEL :

		if (      n_midi_config.onoff ) { break; }
		if ( n_midi_config_note.onoff ) { break; }

		if ( n_nmidi_canvas_collision( &canvas ) )
		{

			int        n  = n_win_scrollbar_wheeldelta( wparam, 1, n_false ) * -1;
			n_type_gfx ch = canvas.hover_y;
			n_type_gfx i  = canvas.hover_x;

			if ( i == 0 )
			{

				int sound, panpot;
				n_midi_bmp_channel_get( &canvas.data, ch, NULL, &sound, &panpot );

				sound += n;

				n_nmidi_canvas_channel_set( &canvas, ch, sound, panpot );

			} else {

				int note, volume;
				n_midi_bmp_note_get( &canvas.data, ch, i, &note, &volume );

				if ( n_win_is_input( VK_RBUTTON ) )
				{
					volume += n;
				} else {
					note   += n;
				}

				n_nmidi_canvas_note_set( &canvas, ch, i, note, volume );

			}

		} 

	break;

	case WM_LBUTTONUP :

		if (      n_midi_config.onoff ) { break; }
		if ( n_midi_config_note.onoff ) { break; }

		if ( n_nmidi_canvas_collision( &canvas ) )
		{
			n_nmidi_config_note_show( &n_midi_config_note );
		} else
		if ( n_nmidi_canvas_collision_scroll( &canvas ) )
		{
			//
		}

	break;

	case WM_RBUTTONUP :

		if (      n_midi_config.onoff ) { break; }
		if ( n_midi_config_note.onoff ) { break; }

		if ( n_nmidi_canvas_collision( &canvas ) )
		{

			n_type_gfx ch = canvas.hover_y;
			n_type_gfx i  = canvas.hover_x;

			int channel, sound, panpot, note, volume;

			n_midi_bmp_channel_get( &canvas.data, ch, &channel, &sound, &panpot );
			n_midi_bmp_note_get( &canvas.data, ch, i, &note, &volume );


			n_hmidiout_all( channel, sound, panpot, note, volume );
			n_posix_sleep( 500 );
			n_hmidiout_all( channel, sound, panpot, note,      0 );

		}

	break;


	case WM_KEYDOWN :

		if (      n_midi_config.onoff ) { break; }
		if ( n_midi_config_note.onoff ) { break; }

		if ( n_win_is_input( VK_LEFT ) )
		{
			n_nmidi_canvas_scroll_set( &canvas, -1 );
		} else
		if ( n_win_is_input( VK_RIGHT ) )
		{
			n_nmidi_canvas_scroll_set( &canvas, +1 );
		} else
		if ( n_nmidi_canvas_collision( &canvas ) )
		{

			if ( n_win_is_input( 'C' ) )
			{
				n_nmidi_canvas_clipboard_get( &canvas );
			} else
			if ( n_win_is_input( 'V' ) )
			{
				n_nmidi_canvas_clipboard_set( &canvas );
			}

//n_win_hwndprintf_literal( hwnd, "Clipboard : %x", canvas.clipboard );

		}

	break;


	} // switch


	return;
}

#ifndef _WIN64
static WNDPROC n_nmidi_band_pfunc = NULL;
#endif // #ifndef _WIN64

LRESULT CALLBACK
#ifdef _WIN64
n_nmidi_band_subclass( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam, UINT_PTR uIdSubclass, DWORD_PTR dwRefData )
#else  // #ifdef _WIN64
n_nmidi_band_subclass( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
#endif // #ifdef _WIN64
{

	switch( msg ) {


	case WM_COMMAND :
	{

		HWND h = (HWND) lparam;


		if ( h == H_BTN_RANDOM.hwnd )
		{

			n_win_exedir2curdir();
			n_midi_random();

			n_explorer_refresh( n_false );

		} else
		if ( h == H_BTN_SAVE.hwnd )
		{

			n_nmidi_canvas_save( &canvas );

		} else
		if ( h == H_BTN_CONFIG.hwnd )
		{

			n_nmidi_config_show( &n_midi_config, GetParent( hwnd ), n_nmidi_hgui, GUI_MAX );

		} else
		if ( h == H_BTN_PLUS.hwnd )
		{

			n_midi_bmp_resize( &canvas.data, +1 );
			n_channel_bulk_reload( canvas.channel, &canvas.data );
			n_nmidi_canvas_scroll_calculate( &canvas );

			n_nmidi_canvas_refresh( &canvas );

		} else
		if ( h == H_BTN_MINUS.hwnd )
		{

			n_midi_bmp_resize( &canvas.data, -1 );
			n_channel_bulk_reload( canvas.channel, &canvas.data );
			n_nmidi_canvas_scroll_calculate( &canvas );

			n_nmidi_canvas_refresh( &canvas );

		}// else

	}
	break;


	} // switch


	n_win_button_proc( hwnd, msg, wparam, lparam, &H_BTN_RANDOM );
	n_win_button_proc( hwnd, msg, wparam, lparam, &H_BTN_SAVE   );
	n_win_button_proc( hwnd, msg, wparam, lparam, &H_BTN_CONFIG );
	n_win_button_proc( hwnd, msg, wparam, lparam, &H_BTN_PLUS   );
	n_win_button_proc( hwnd, msg, wparam, lparam, &H_BTN_MINUS  );


#ifdef _WIN64
	return DefSubclassProc( hwnd, msg, wparam, lparam );
#else  // #ifdef _WIN64
	return CallWindowProc( n_nmidi_band_pfunc, hwnd, msg, wparam, lparam );
#endif // #ifdef _WIN64
}

void
n_nmidi_icon_add( void )
{

	n_win_icon_init_callback = n_project_system_icon_color;

	H_BTN_RANDOM.hicon = n_win_icon_init( NULL, N_APPS_ICON_OFFSET_NMIDI + 0, N_WIN_ICON_INIT_OPTION_RESOURCE );
	H_BTN_SAVE  .hicon = n_win_icon_init( NULL, N_APPS_ICON_OFFSET_NMIDI + 1, N_WIN_ICON_INIT_OPTION_RESOURCE );
	H_BTN_CONFIG.hicon = n_win_icon_init( NULL, N_APPS_ICON_OFFSET_NMIDI + 2, N_WIN_ICON_INIT_OPTION_RESOURCE );
	H_BTN_PLUS  .hicon = n_win_icon_init( NULL, N_APPS_ICON_OFFSET_NMIDI + 3, N_WIN_ICON_INIT_OPTION_RESOURCE );
	H_BTN_MINUS .hicon = n_win_icon_init( NULL, N_APPS_ICON_OFFSET_NMIDI + 4, N_WIN_ICON_INIT_OPTION_RESOURCE );


	return;
}

void
n_nmidi_darkmode( void )
{

	n_project_darkmode();

	if ( n_win_darkmode_onoff )
	{
		N_NMIDI_COLOR_BG      = n_win_darkmode_bg_argb;
		N_NMIDI_COLOR_SELECT  = n_win_darkmode_bg_argb;
		N_NMIDI_COLOR_HEADER  = n_bmp_rgb(   0,200,255 );
		N_NMIDI_COLOR_CONTOUR = n_bmp_rgb( 222,222,222 );
	} else {
		N_NMIDI_COLOR_BG      = n_bmp_rgb( 255,255,255 );
		N_NMIDI_COLOR_SELECT  = n_bmp_rgb( 255,255,255 );
		N_NMIDI_COLOR_HEADER  = n_bmp_rgb(   0,100,150 );
		N_NMIDI_COLOR_CONTOUR = n_bmp_rgb( 255,255,255 );
	}


	return;
}

void
n_nmidi_on_settingchange( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	static UINT timer_id = 0;


	switch( msg ) {


	case WM_SETTINGCHANGE :

		// [!] : XP or later : this message is sent many times

		// [!] : Win8.1 : SPI_SETNONCLIENTMETRICS will never come

		if ( timer_id == 0 ) { timer_id = n_win_timer_id_get(); }

		n_win_timer_init( hwnd, timer_id, n_project_settingchange_interval() );

	break;


	case WM_TIMER :

		// [!] : Win95 needs to check WPARAM is ID or not

		if ( wparam == 0 ) { break; }

		if ( wparam != timer_id ) { break; }


		n_win_timer_exit( hwnd, timer_id );


		n_nmidi_darkmode();

		n_win_init_background( hwnd );
		n_win_refresh( hwnd, n_true );

		n_win_refresh( H_BAND, n_true );

		n_nmidi_icon_add();

		n_win_button_on_settingchange( &H_BTN_RANDOM );
		n_win_button_on_settingchange( &H_BTN_SAVE   );
		n_win_button_on_settingchange( &H_BTN_CONFIG );
		n_win_button_on_settingchange( &H_BTN_PLUS   );
		n_win_button_on_settingchange( &H_BTN_MINUS  );

		n_nmidi_resize( hwnd );

	break;


	} // switch


}

LRESULT CALLBACK
n_nmidi_wndproc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	n_nmidi_on_settingchange( hwnd, msg, wparam, lparam );


	switch( msg ) {


	case WM_CREATE :


		// Global

		n_win_exedir2curdir();

		if ( n_nmidi_newfile_txt() ) { return -1; }

		n_game_timegettime_init();

#ifdef _H_NONNON_WIN32_OLE_IDROPTARGET
		n_IDropTarget_init( hwnd );
#endif // _H_NONNON_WIN32_OLE_IDROPTARGET

		n_bmp_safemode = n_false;

		n_win_ime_disable( hwnd );


		n_nmidi_darkmode();


		n_nmidi_canvas_zero( &canvas );


		n_win_button_zero( &H_BTN_RANDOM );
		n_win_button_zero( &H_BTN_SAVE   );
		n_win_button_zero( &H_BTN_CONFIG );
		n_win_button_zero( &H_BTN_PLUS   );
		n_win_button_zero( &H_BTN_MINUS  );


		// Window

		n_win_init_literal( hwnd, "", "NMIDI_0_MAIN", "" );

		n_nmidi_config_note_init( &n_midi_config_note, hwnd );

		n_win_gui_literal(   hwnd,  CANVAS, "", &H_BAND       );
		n_win_gui_literal(   hwnd,  CANVAS, "", &H_STA_CANVAS );

		n_win_button_init_dwm( &H_BTN_RANDOM, H_BAND, N_STRING_EMPTY, PBS_NORMAL );
		n_win_button_init_dwm( &H_BTN_SAVE  , H_BAND, N_STRING_EMPTY, PBS_NORMAL );
		n_win_button_init_dwm( &H_BTN_CONFIG, H_BAND, N_STRING_EMPTY, PBS_NORMAL );
		n_win_button_init_dwm( &H_BTN_PLUS  , H_BAND, N_STRING_EMPTY, PBS_NORMAL );
		n_win_button_init_dwm( &H_BTN_MINUS , H_BAND, N_STRING_EMPTY, PBS_NORMAL );

		n_project_toolband_dwm_onoff_margin = H_BTN_RANDOM.maclike_offset;

		n_nmidi_icon_add();


		// Style

		n_project_window_resizable( hwnd );

		//n_win_style_add( H_STA_CANVAS, WS_BORDER );
		//n_win_exstyle_add( H_STA_CANVAS, WS_EX_CLIENTEDGE );

#ifdef _WIN64
		SetWindowSubclass( H_BAND, n_nmidi_band_subclass , 0, 0 );
#else  // #ifdef _WIN64
		n_nmidi_band_pfunc = n_win_gui_subclass_set( H_BAND, n_nmidi_band_subclass );
#endif // #ifdef _WIN64


		// Init

		n_nmidi_newfile( hwnd, NULL );


		// [x] : Vista or later : this takes 600msec for vain

		n_hmidiout_init();


		// Display

		n_nmidi_resize( hwnd );

		ShowWindowAsync( hwnd, SW_NORMAL );

	break;

	case WM_DROPFILES :
	{

		if (      n_midi_config.onoff ) { break; }
		if ( n_midi_config_note.onoff ) { break; }

		n_posix_char *str = n_win_dropfiles_multiple_new( hwnd, wparam );

		n_nmidi_newfile( hwnd, str );

		n_string_path_free( str );
	}
	break;


	case WM_SIZE :

		n_nmidi_resize( hwnd );

	break;


	case WM_DRAWITEM :
	{
//u32 tick = n_posix_tickcount();

		if ( n_midi_config.onoff ) { break; }


		DRAWITEMSTRUCT *di = (void*) lparam;
		if ( di == NULL ) { break; }
		if ( H_STA_CANVAS != di->hwndItem ) { break; }


		n_win_rect_expand_size( &di->rcItem, NULL, NULL, &canvas.sx, &canvas.sy );

		canvas.sx = n_posix_max_n_type_gfx( 1, canvas.sx );
		canvas.sy = n_posix_max_n_type_gfx( 1, canvas.sy );

		n_bmp_new_fast( &canvas.canvas, canvas.sx, canvas.sy );

		n_bmp_flush( &canvas.canvas, N_NMIDI_COLOR_BG );

		if (
			( n_win_darkmode_onoff )
			||
			( n_false == n_win_dwm_is_on() )
			||
			( n_sysinfo_version_10_or_later() )
		)
		{
			canvas.border = (n_type_gfx) trunc( n_win_scale( H_STA_CANVAS ) );
			n_midi_draw_frame( &canvas.canvas, 0,0,canvas.sx,canvas.sy, N_NMIDI_COLOR_BORDER, N_NMIDI_COLOR_BORDER );
		}

		static n_bool is_first = n_true;
		if ( is_first )
		{
			is_first = n_false;
			n_gdi_bitmap_draw( H_STA_CANVAS, &canvas.canvas, 0,0,canvas.sx,canvas.sy, 0,0 );
		}

		n_nmidi_canvas_draw_header( &canvas );
		n_nmidi_canvas_draw_note  ( &canvas );
		n_nmidi_canvas_draw_scroll( &canvas );

		if ( n_false == IsWindowEnabled( H_STA_CANVAS ) )
		{
			if ( n_win_darkmode_onoff )
			{
				n_bmp_flush_mixer( &canvas.canvas, n_bmp_white, 0.2 );
			} else {
				n_bmp_flush_mixer( &canvas.canvas, n_bmp_black, 0.2 );
			}
		}

		n_gdi_bitmap_draw( H_STA_CANVAS, &canvas.canvas, 0,0,canvas.sx,canvas.sy, 0,0 );


//n_win_hwndprintf_literal( hwnd, "%d", (int) n_posix_tickcount() - tick );
	}
	break;


	case WM_CLOSE :

		ShowWindow( hwnd, SW_HIDE );


		n_nmidi_config_note_exit( &n_midi_config_note );


		n_nmidi_canvas_exit( &canvas );


		// [!] : Win10 : a temporary setting
		//
		//	build 10162 : fixed

		//if ( n_false == n_sysinfo_version_10_or_later() )
		{
			n_hmidiout_exit();
		}


		n_game_timegettime_exit();


		n_win_button_exit( &H_BTN_RANDOM );
		n_win_button_exit( &H_BTN_SAVE   );
		n_win_button_exit( &H_BTN_CONFIG );
		n_win_button_exit( &H_BTN_PLUS   );
		n_win_button_exit( &H_BTN_MINUS  );


#ifdef _H_NONNON_WIN32_OLE_IDROPTARGET
		n_IDropTarget_exit( hwnd );
#endif // _H_NONNON_WIN32_OLE_IDROPTARGET

		DestroyWindow( hwnd );

	break;

	case WM_DESTROY :

		PostQuitMessage( 0 );

	break;


	case WM_MOUSEMOVE :

		n_win_on_mousemove( hwnd );

	break;

	case WM_MOUSEHOVER :
//n_win_hwndprintf_literal( hwnd, " WM_MOUSEHOVER " );

	break;

	case WM_MOUSELEAVE :
//n_win_hwndprintf_literal( hwnd, " WM_MOUSELEAVE " );

		canvas.hover_x = canvas.hover_y = N_MIDI_HOVER_NEUTRAL;
		n_nmidi_canvas_refresh( &canvas );

	break;


	} // switch


	{
		LRESULT ret = n_win_darkmode_proc( hwnd, msg, wparam, lparam );
		if ( ret != 0 ) { return ret; }
	}


	n_win_cornercolor_proc( hwnd, msg, wparam, lparam );


	n_project_toolband_proc( hwnd, msg, wparam, lparam, H_BAND, n_true );


	n_nmidi_config_proc( hwnd, msg, wparam, lparam, &n_midi_config, n_nmidi_hgui, GUI_MAX );

	n_nmidi_config_note_proc( hwnd, msg, wparam, lparam, &n_midi_config_note );

	n_nmidi_proc( hwnd, msg, wparam, lparam );


	n_win_simplemenu_proc( hwnd, msg, &wparam, &lparam, NULL );


	{
		LRESULT ret = 0;
		if ( n_win_fake_win7_proc( hwnd, msg, wparam, lparam, &ret ) )
		{
			return ret;
		}
	}


	return DefWindowProc( hwnd, msg, wparam, lparam );
}

#ifndef NONNON_APPS

int WINAPI
WinMain( HINSTANCE hinst, HINSTANCE prv_hinst, LPSTR cmd, int show )
{
	return n_win_main( NULL, n_nmidi_wndproc );
}

#endif // #ifndef NONNON_APPS




#undef H_BAND
#undef H_STA_CANVAS
#undef GUI_MAX

#undef H_BTN_RANDOM
#undef H_BTN_SAVE
#undef H_BTN_CONFIG
#undef H_BTN_PLUS
#undef H_BTN_MINUS
#undef BTN_MAX


