// Nonnon Paint
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




// the base layer

#include "../nonnon/win32/win.c"
#include "../nonnon/win32/win_button.c"
#include "../nonnon/win32/win_colorpicker.c"
#include "../nonnon/win32/win_scrollbar.c"
#include "../nonnon/win32/win_scroller.c"

#include "../nonnon/project/macro.c"




// rc.h

#define H_BTN_00_00  N_PAINT_TOOL_H_BTN_00_00
#define H_BTN_01_00  N_PAINT_TOOL_H_BTN_01_00
#define H_BTN_02_00  N_PAINT_TOOL_H_BTN_02_00
#define H_BTN_03_00  N_PAINT_TOOL_H_BTN_03_00
#define H_BTN_04_00  N_PAINT_TOOL_H_BTN_04_00

#define H_BTN_00_01  N_PAINT_TOOL_H_BTN_00_01
#define H_BTN_01_01  N_PAINT_TOOL_H_BTN_01_01
#define H_BTN_02_01  N_PAINT_TOOL_H_BTN_02_01
#define H_BTN_03_01  N_PAINT_TOOL_H_BTN_03_01
#define H_BTN_04_01  N_PAINT_TOOL_H_BTN_04_01

#define H_BTN_00_02  N_PAINT_TOOL_H_BTN_00_02
#define H_BTN_01_02  N_PAINT_TOOL_H_BTN_01_02
#define H_BTN_02_02  N_PAINT_TOOL_H_BTN_02_02
#define H_BTN_03_02  N_PAINT_TOOL_H_BTN_03_02
#define H_BTN_04_02  N_PAINT_TOOL_H_BTN_04_02


#define H_SCR_SIZE   N_PAINT_TOOL_H_SCR_SIZE
#define H_SCR_MIX    N_PAINT_TOOL_H_SCR_MIX
#define H_SCR_BOOST  N_PAINT_TOOL_H_SCR_BOOST
#define H_SCR_AIR    N_PAINT_TOOL_H_SCR_AIR
#define H_SCR_ZOOM   N_PAINT_TOOL_H_SCR_ZOOM




// internal
void
n_paint_tool_filter( int mode )
{

	n_project_pleasewait_on( hwnd_tool );

	n_paint_grabber_filter( mode );

	n_paint_title();

	n_project_pleasewait_off( hwnd_tool );


	return;
}




void
n_paint_tool_scrollbar_updown( n_win_scroller *p, int delta )
{

	n_win_simplemenu_hide( &n_paint_simplemenu );

	n_win_scrollbar_scroll_unit( &p->scrollbar, p->scrollbar.unit_step * delta, N_WIN_SCROLLBAR_SCROLL_AUTO );
	n_win_scrollbar_draw_always( &p->scrollbar, n_true );

	return;
}




#define N_PAINY_TOOL_CLIPBOARD_IN  ( 0 )
#define N_PAINY_TOOL_CLIPBOARD_OUT ( 1 )

static int n_paint_tool_clipboard = N_PAINY_TOOL_CLIPBOARD_IN;

void
n_paint_tool_clipboard_switch( int delta )
{

	if ( delta == 0 ) { return; }


	if ( n_paint_tool_clipboard == N_PAINY_TOOL_CLIPBOARD_IN )
	{
		n_paint_tool_clipboard = N_PAINY_TOOL_CLIPBOARD_OUT;
		H_BTN_02_00.hicon = n_win_icon_init( NULL, N_APPS_ICON_OFFSET_NONNON_PAINT + 3, N_WIN_ICON_INIT_OPTION_RESOURCE );
	} else {
		n_paint_tool_clipboard = N_PAINY_TOOL_CLIPBOARD_IN;
		H_BTN_02_00.hicon = n_win_icon_init( NULL, N_APPS_ICON_OFFSET_NONNON_PAINT + 2, N_WIN_ICON_INIT_OPTION_RESOURCE );
	}

	n_win_refresh( H_BTN_02_00.hwnd, n_posix_false );


	return;
}

#ifndef _WIN64
static WNDPROC n_paint_tool_clipboard_pfunc;
#endif // #ifndef _WIN64

LRESULT CALLBACK
#ifdef _WIN64
n_paint_tool_clipboard_subclass( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam, UINT_PTR uIdSubclass, DWORD_PTR dwRefData )
#else  // #ifdef _WIN64
n_paint_tool_clipboard_subclass( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
#endif // #ifdef _WIN64
{

	switch( msg ) {


	case WM_RBUTTONDOWN   :
	case WM_RBUTTONDBLCLK :

		n_paint_tool_clipboard_switch( 1 );

	break;


	} // switch()


#ifdef _WIN64
	return DefSubclassProc( hwnd, msg, wparam, lparam );
#else  // #ifdef _WIN64
	return CallWindowProc( n_paint_tool_clipboard_pfunc, hwnd, msg, wparam, lparam );
#endif // #ifdef _WIN64
}




void
n_paint_tool_saveicon_refresh( n_bool refresh_onoff )
{

	if ( n_paint_format_is_bmp( n_paint_bmpname ) )
	{
		H_BTN_04_00.hicon = n_win_icon_init( NULL, N_APPS_ICON_OFFSET_NONNON_PAINT +  5, N_WIN_ICON_INIT_OPTION_RESOURCE );
		n_paint_format = N_PAINT_FORMAT_BMP;
	} else
	if ( n_paint_format_is_ico( n_paint_bmpname ) )
	{
		H_BTN_04_00.hicon = n_win_icon_init( NULL, N_APPS_ICON_OFFSET_NONNON_PAINT +  6, N_WIN_ICON_INIT_OPTION_RESOURCE );
		n_paint_format = N_PAINT_FORMAT_ICO;
	} else
	if ( n_paint_format_is_cur( n_paint_bmpname ) )
	{
		H_BTN_04_00.hicon = n_win_icon_init( NULL, N_APPS_ICON_OFFSET_NONNON_PAINT +  7, N_WIN_ICON_INIT_OPTION_RESOURCE );
		n_paint_format = N_PAINT_FORMAT_CUR;
	} else
	if ( n_paint_format_is_jpg( n_paint_bmpname ) )
	{
		H_BTN_04_00.hicon = n_win_icon_init( NULL, N_APPS_ICON_OFFSET_NONNON_PAINT +  8, N_WIN_ICON_INIT_OPTION_RESOURCE );
		n_paint_format = N_PAINT_FORMAT_JPG;
	} else
	if ( n_paint_format_is_png( n_paint_bmpname ) )
	{
		H_BTN_04_00.hicon = n_win_icon_init( NULL, N_APPS_ICON_OFFSET_NONNON_PAINT +  9, N_WIN_ICON_INIT_OPTION_RESOURCE );
		n_paint_format = N_PAINT_FORMAT_PNG;
	} else
	if ( n_paint_format_is_lyr( n_paint_bmpname ) )
	{
		H_BTN_04_00.hicon = n_win_icon_init( NULL, N_APPS_ICON_OFFSET_NONNON_PAINT + 10, N_WIN_ICON_INIT_OPTION_RESOURCE );
		n_paint_format = N_PAINT_FORMAT_LYR;
	}

	n_win_refresh( H_BTN_04_00.hwnd, n_posix_false );


	//if ( refresh_onoff ) { n_paint_refresh_client(); }


	return;
}

void
n_paint_tool_saveicon_switch( int delta )
{

	if ( delta == 0 ) { return; }

	if ( delta >= 1 )
	{
		if ( n_paint_format_is_bmp( n_paint_bmpname ) ) { n_string_path_ext_mod( N_PAINT_EXT_ICO, n_paint_bmpname ); } else
		if ( n_paint_format_is_ico( n_paint_bmpname ) ) { n_string_path_ext_mod( N_PAINT_EXT_CUR, n_paint_bmpname ); } else
		if ( n_paint_format_is_cur( n_paint_bmpname ) ) { n_string_path_ext_mod( N_PAINT_EXT_JPG, n_paint_bmpname ); } else
		if ( n_paint_format_is_jpg( n_paint_bmpname ) ) { n_string_path_ext_mod( N_PAINT_EXT_PNG, n_paint_bmpname ); } else
		if ( n_paint_format_is_png( n_paint_bmpname ) ) { n_string_path_ext_mod( N_PAINT_EXT_LYR, n_paint_bmpname ); } else
		if ( n_paint_format_is_lyr( n_paint_bmpname ) ) { n_string_path_ext_mod( N_PAINT_EXT_BMP, n_paint_bmpname ); }
	} else {
		if ( n_paint_format_is_bmp( n_paint_bmpname ) ) { n_string_path_ext_mod( N_PAINT_EXT_LYR, n_paint_bmpname ); } else
		if ( n_paint_format_is_ico( n_paint_bmpname ) ) { n_string_path_ext_mod( N_PAINT_EXT_BMP, n_paint_bmpname ); } else
		if ( n_paint_format_is_cur( n_paint_bmpname ) ) { n_string_path_ext_mod( N_PAINT_EXT_ICO, n_paint_bmpname ); } else
		if ( n_paint_format_is_jpg( n_paint_bmpname ) ) { n_string_path_ext_mod( N_PAINT_EXT_CUR, n_paint_bmpname ); } else
		if ( n_paint_format_is_png( n_paint_bmpname ) ) { n_string_path_ext_mod( N_PAINT_EXT_JPG, n_paint_bmpname ); } else
		if ( n_paint_format_is_lyr( n_paint_bmpname ) ) { n_string_path_ext_mod( N_PAINT_EXT_PNG, n_paint_bmpname ); }
	}

	n_paint_tool_saveicon_refresh( n_true );

	n_paint_title();


	return;
}

#ifndef _WIN64
static WNDPROC n_paint_tool_savebutton_pfunc;
#endif // #ifndef _WIN64

LRESULT CALLBACK
#ifdef _WIN64
n_paint_tool_savebutton_subclass( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam, UINT_PTR uIdSubclass, DWORD_PTR dwRefData )
#else  // #ifdef _WIN64
n_paint_tool_savebutton_subclass( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
#endif // #ifdef _WIN64
{

	switch( msg ) {


	case WM_RBUTTONDOWN   :
	case WM_RBUTTONDBLCLK :

		n_paint_tool_saveicon_switch( 1 );

	break;


	} // switch()


#ifdef _WIN64
	return DefSubclassProc( hwnd, msg, wparam, lparam );
#else  // #ifdef _WIN64
	return CallWindowProc( n_paint_tool_savebutton_pfunc, hwnd, msg, wparam, lparam );
#endif // #ifdef _WIN64
}




void
n_paint_tool_exit( void )
{

	n_win_scroller_exit( H_SCR_SIZE  );
	n_win_scroller_exit( H_SCR_MIX   );
	n_win_scroller_exit( H_SCR_BOOST );
	n_win_scroller_exit( H_SCR_AIR   );
	n_win_scroller_exit( H_SCR_ZOOM  );

	n_win_button_exit( &H_BTN_00_00 );
	n_win_button_exit( &H_BTN_01_00 );
	n_win_button_exit( &H_BTN_02_00 );
	n_win_button_exit( &H_BTN_03_00 );
	n_win_button_exit( &H_BTN_04_00 );

	n_win_button_exit( &H_BTN_00_01 );
	n_win_button_exit( &H_BTN_01_01 );
	n_win_button_exit( &H_BTN_02_01 );
	n_win_button_exit( &H_BTN_03_01 );
	n_win_button_exit( &H_BTN_04_01 );

	n_win_button_exit( &H_BTN_00_02 );
	n_win_button_exit( &H_BTN_01_02 );
	n_win_button_exit( &H_BTN_02_02 );
	n_win_button_exit( &H_BTN_03_02 );
	n_win_button_exit( &H_BTN_04_02 );

	n_win_colorpicker_exit( &cp );


#ifdef _WIN64
		RemoveWindowSubclass( H_BTN_02_00.hwnd, n_paint_tool_clipboard_subclass , 0 );
		RemoveWindowSubclass( H_BTN_04_00.hwnd, n_paint_tool_savebutton_subclass, 0 );
#else  // #ifdef _WIN64
		n_win_gui_subclass_set( H_BTN_02_00.hwnd, n_paint_tool_clipboard_pfunc  );
		n_win_gui_subclass_set( H_BTN_04_00.hwnd, n_paint_tool_savebutton_pfunc );
#endif // #ifdef _WIN64


	return;
}

// internal
void
n_paint_tool_iconbutton_toolswitch( int line )
{

	static int prev = -1;

	if ( line == -1 )
	{
		if ( prev == 1 ) { line = 2; } else { line = 1; }
	}

	if ( line == 1 )
	{

		ShowWindow( H_BTN_00_02.hwnd, SW_HIDE );
		ShowWindow( H_BTN_01_02.hwnd, SW_HIDE );
		ShowWindow( H_BTN_02_02.hwnd, SW_HIDE );
		ShowWindow( H_BTN_03_02.hwnd, SW_HIDE );
		ShowWindow( H_BTN_04_02.hwnd, SW_HIDE );

		ShowWindow( H_BTN_00_01.hwnd, SW_NORMAL );
		ShowWindow( H_BTN_01_01.hwnd, SW_NORMAL );
		ShowWindow( H_BTN_02_01.hwnd, SW_NORMAL );
		ShowWindow( H_BTN_03_01.hwnd, SW_HIDE   );
		ShowWindow( H_BTN_04_01.hwnd, SW_NORMAL );

	} else
	if ( line == 2 )
	{

		ShowWindow( H_BTN_00_01.hwnd, SW_HIDE );
		ShowWindow( H_BTN_01_01.hwnd, SW_HIDE );
		ShowWindow( H_BTN_02_01.hwnd, SW_HIDE );
		ShowWindow( H_BTN_03_01.hwnd, SW_HIDE );
		ShowWindow( H_BTN_04_01.hwnd, SW_HIDE );

		ShowWindow( H_BTN_00_02.hwnd, SW_NORMAL );
		ShowWindow( H_BTN_01_02.hwnd, SW_NORMAL );
		ShowWindow( H_BTN_02_02.hwnd, SW_NORMAL );
		ShowWindow( H_BTN_03_02.hwnd, SW_NORMAL );
		ShowWindow( H_BTN_04_02.hwnd, SW_NORMAL );

	}

	prev = line;


	return;
}

// internal
void
n_paint_tool_iconbutton_grabber_onoff( n_bool onoff )
{

	if ( onoff )
	{

		n_paint_tool_grabber_onoff( n_true );


		nwscr_enable( H_SCR_SIZE , n_false );
		nwscr_enable( H_SCR_MIX  , n_false );
		nwscr_enable( H_SCR_BOOST, n_false );
		nwscr_enable( H_SCR_AIR  , n_false );
		nwclr_enable( &cp        , n_false );

		//H_BTN_02_00.active_onoff = n_false; // Clipboard
		H_BTN_04_00.active_onoff = n_false; // Save
		H_BTN_04_01.active_onoff = n_false; // Color History

	} else {

		if ( N_PAINT_GRABBER_IS_NEUTRAL() )
		{
			n_paint_tool_grabber_onoff      ( n_false );
			//n_paint_tool_grabber_trans_onoff( n_false );
		}


		nwscr_enable( H_SCR_SIZE , n_true );
		nwscr_enable( H_SCR_MIX  , n_true );
		nwscr_enable( H_SCR_BOOST, n_true );
		nwscr_enable( H_SCR_AIR  , n_true );
		nwclr_enable( &cp        , n_true );

		//H_BTN_02_00.active_onoff = ( n_posix_false != N_PAINT_GRABBER_IS_NEUTRAL() ); // Clipboard
		H_BTN_04_00.active_onoff = ( n_posix_false != N_PAINT_GRABBER_IS_NEUTRAL() ); // Save
		H_BTN_04_01.active_onoff = n_true; // Color History

		H_BTN_02_01.hicon = n_win_icon_init( NULL, N_APPS_ICON_OFFSET_NONNON_PAINT + 13, N_WIN_ICON_INIT_OPTION_RESOURCE );

	}


	n_win_button_sync( &H_BTN_02_00 );
	n_win_button_sync( &H_BTN_04_00 );
	n_win_button_sync( &H_BTN_04_01 );


	return;
}

// internal
void
n_paint_tool_iconbutton_pentype( int type )
{

	// [!] : reset

	H_BTN_00_01.select_onoff = n_posix_false;
	H_BTN_01_01.select_onoff = n_posix_false;
	H_BTN_02_01.select_onoff = n_posix_false;
	//H_BTN_03_01.select_onoff = n_posix_false;
	//H_BTN_04_01.select_onoff = n_posix_false;


	if ( type == N_PAINT_TOOL_TYPE_PEN  )
	{

		if ( tooltype == N_PAINT_TOOL_TYPE_GRAB )
		{
			n_paint_tool_iconbutton_grabber_onoff( n_false );
		}

		H_BTN_00_01.select_onoff = n_posix_true;

		n_win_cursor_add_literal( hwnd_main, "NONNON_PAINT_PEN" );

	} else
	if ( type == N_PAINT_TOOL_TYPE_FILL )
	{

		if ( tooltype == N_PAINT_TOOL_TYPE_GRAB )
		{
			n_paint_tool_iconbutton_grabber_onoff( n_false );
		}

		H_BTN_01_01.select_onoff = n_posix_true;

		n_win_cursor_add_literal( hwnd_main, "NONNON_PAINT_FILL" );

	} else
	if ( type == N_PAINT_TOOL_TYPE_GRAB )
	{

		if ( tooltype != N_PAINT_TOOL_TYPE_GRAB )
		{
			n_paint_tool_iconbutton_grabber_onoff( n_true );
		}

		H_BTN_02_01.select_onoff = n_posix_true;

		n_project_system_icon_color_special_onoff = n_true;
		H_BTN_02_01.hicon = n_win_icon_init( NULL, N_APPS_ICON_OFFSET_NONNON_PAINT + 14, N_WIN_ICON_INIT_OPTION_RESOURCE );
		n_project_system_icon_color_special_onoff = n_false;

		n_paint_grabber_status();

		n_paint_layer_grabber_check_enable( n_true );

		n_win_cursor_add( hwnd_main, IDC_ARROW );

	}// else


	n_win_button_sync( &H_BTN_00_01 );
	n_win_button_sync( &H_BTN_01_01 );
	n_win_button_sync( &H_BTN_02_01 );


//n_win_hwndprintf_literal( hwnd_main, "%d %d %d", H_BTN_00_01.select_onoff, H_BTN_01_01.select_onoff, H_BTN_02_01.select_onoff );


	tooltype = type;


	return;
}

// internal
void
n_paint_tool_resize( int nwinset )
{

	const n_bool redraw = n_false;


	n_type_gfx ctl,ico,m; n_win_stdsize( hwnd_tool, &ctl, &ico, &m );


	n_type_gfx gap = m * 2;
	n_type_gfx pad = m;
	n_type_gfx csx = ( ico * 5 ) +               ( gap * 4 );
	n_type_gfx csy = ( ctl * 9 ) + ( ico * 2 ) + ( gap * 2 );

	if ( nwin_tool.posx == -1 ) { nwin_tool.posx = (n_type_gfx) ( (n_type_real) n_paint_desktop_sx * 0.1 ); }
	if ( nwin_tool.posy == -1 ) { nwin_tool.posy = (n_type_gfx) ( (n_type_real) n_paint_desktop_sy * 0.1 ); }

#ifdef _MSC_VER

	//

#else  // #ifdef _MSC_VER

	// [!] : MinGW version only

	if ( n_win_dwm_is_on() )
	{
		static n_bool init_onoff = n_false;
		if ( init_onoff == n_false )
		{
			init_onoff = n_true;

			nwin_tool.posx += 5;
			nwin_tool.posy += 5;
		}
	}

#endif // #ifdef _MSC_VER

	n_win_set( hwnd_tool, &nwin_tool, csx + m + ( pad * 2 ), csy + m + ( pad * 2 ), nwinset );


	// [!] : scrollers

	n_type_gfx x = pad;
	n_type_gfx y = pad;

	n_win_scroller_move( H_SCR_SIZE , x, y, csx,ctl, redraw ); y += ctl;
	n_win_scroller_move( H_SCR_MIX  , x, y, csx,ctl, redraw ); y += ctl;
	n_win_scroller_move( H_SCR_BOOST, x, y, csx,ctl, redraw ); y += ctl;
	n_win_scroller_move( H_SCR_AIR  , x, y, csx,ctl, redraw ); y += ctl;
	n_win_scroller_move( H_SCR_ZOOM , x, y, csx,ctl, redraw ); y += ctl;


	// [!] : color picker

	n_type_gfx cp_sy = ( ctl * 4 );

	n_win_colorpicker_move( &cp,  x, y, csx,cp_sy, n_false ); y += cp_sy;


	// [!] : icon buttons

	y = pad + ( ctl * 9 ) + ( gap * 1 );

	n_win_button_move( &H_BTN_00_00, x+(ico*0)+(gap*0),        y, ico,ico, redraw );
	// Reserved
	n_win_button_move( &H_BTN_02_00, x+(ico*2)+(gap*2),        y, ico,ico, redraw );
	n_win_button_move( &H_BTN_03_00, x+(ico*3)+(gap*3),        y, ico,ico, redraw );
	n_win_button_move( &H_BTN_04_00, x+(ico*4)+(gap*4),        y, ico,ico, redraw );

	y = pad + ( ctl * 9 ) + ( gap * 2 );

	n_win_button_move( &H_BTN_00_01, x+(ico*0)+(gap*0),(ico*1)+y, ico,ico, redraw );
	n_win_button_move( &H_BTN_01_01, x+(ico*1)+(gap*1),(ico*1)+y, ico,ico, redraw );
	n_win_button_move( &H_BTN_02_01, x+(ico*2)+(gap*2),(ico*1)+y, ico,ico, redraw );
	n_win_button_move( &H_BTN_03_01, x+(ico*3)+(gap*3),(ico*1)+y, ico,ico, redraw );
	n_win_button_move( &H_BTN_04_01, x+(ico*4)+(gap*4),(ico*1)+y, ico,ico, redraw );

	n_win_button_move( &H_BTN_00_02, x+(ico*0)+(gap*0),(ico*1)+y, ico,ico, redraw );
	n_win_button_move( &H_BTN_01_02, x+(ico*1)+(gap*1),(ico*1)+y, ico,ico, redraw );
	n_win_button_move( &H_BTN_02_02, x+(ico*2)+(gap*2),(ico*1)+y, ico,ico, redraw );
	n_win_button_move( &H_BTN_03_02, x+(ico*3)+(gap*3),(ico*1)+y, ico,ico, redraw );
	n_win_button_move( &H_BTN_04_02, x+(ico*4)+(gap*4),(ico*1)+y, ico,ico, redraw );


	return;
}

void
n_paint_tool_icon_add( void )
{

	H_BTN_00_00.hicon = n_win_icon_init( NULL, N_APPS_ICON_OFFSET_NONNON_PAINT +  1, N_WIN_ICON_INIT_OPTION_RESOURCE );
	//H_BTN_01_00.hicon = n_win_icon_init( NULL, N_APPS_ICON_OFFSET_NONNON_PAINT +  0, N_WIN_ICON_INIT_OPTION_RESOURCE );
	H_BTN_02_00.hicon = n_win_icon_init( NULL, N_APPS_ICON_OFFSET_NONNON_PAINT +  2, N_WIN_ICON_INIT_OPTION_RESOURCE );
	H_BTN_03_00.hicon = n_win_icon_init( NULL, N_APPS_ICON_OFFSET_NONNON_PAINT +  4, N_WIN_ICON_INIT_OPTION_RESOURCE );
	//H_BTN_04_00.hicon = n_win_icon_init( NULL, N_APPS_ICON_OFFSET_NONNON_PAINT +  0, N_WIN_ICON_INIT_OPTION_RESOURCE );

	H_BTN_00_01.hicon = n_win_icon_init( NULL, N_APPS_ICON_OFFSET_NONNON_PAINT + 11, N_WIN_ICON_INIT_OPTION_RESOURCE );
	H_BTN_01_01.hicon = n_win_icon_init( NULL, N_APPS_ICON_OFFSET_NONNON_PAINT + 12, N_WIN_ICON_INIT_OPTION_RESOURCE );
	H_BTN_02_01.hicon = n_win_icon_init( NULL, N_APPS_ICON_OFFSET_NONNON_PAINT + 13, N_WIN_ICON_INIT_OPTION_RESOURCE );
	//H_BTN_03_01.hicon = n_win_icon_init( NULL, N_APPS_ICON_OFFSET_NONNON_PAINT +  0, N_WIN_ICON_INIT_OPTION_RESOURCE );
	H_BTN_04_01.hicon = n_win_icon_init( NULL, N_APPS_ICON_OFFSET_NONNON_PAINT + 15, N_WIN_ICON_INIT_OPTION_RESOURCE );

	H_BTN_00_02.hicon = n_win_icon_init( NULL, N_APPS_ICON_OFFSET_NONNON_PAINT + 16, N_WIN_ICON_INIT_OPTION_RESOURCE );
	H_BTN_01_02.hicon = n_win_icon_init( NULL, N_APPS_ICON_OFFSET_NONNON_PAINT + 17, N_WIN_ICON_INIT_OPTION_RESOURCE );
	H_BTN_02_02.hicon = n_win_icon_init( NULL, N_APPS_ICON_OFFSET_NONNON_PAINT + 18, N_WIN_ICON_INIT_OPTION_RESOURCE );
	H_BTN_03_02.hicon = n_win_icon_init( NULL, N_APPS_ICON_OFFSET_NONNON_PAINT + 19, N_WIN_ICON_INIT_OPTION_RESOURCE );
	H_BTN_04_02.hicon = n_win_icon_init( NULL, N_APPS_ICON_OFFSET_NONNON_PAINT + 20, N_WIN_ICON_INIT_OPTION_RESOURCE );


	return;
}

void
n_paint_tool_on_settingchange( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	static UINT timer_id = 0;


	switch( msg ) {


	case WM_SETTINGCHANGE :

		// [!] : XP or later : this message is sent many times

		// [!] : Win8.1 : SPI_SETNONCLIENTMETRICS will never come

		if ( timer_id == 0 ) { timer_id = n_win_timer_id_get(); }

		n_win_timer_init( hwnd, timer_id, n_project_settingchange_interval() );

	break;


	case WM_TIMER :

		// [!] : Win95 needs to check WPARAM is ID or not

		if ( wparam == 0 ) { break; }

		if ( wparam != timer_id ) { break; }


		n_win_timer_exit( hwnd, timer_id );


		n_project_darkmode();

		n_win_init_background( hwnd );
		n_win_refresh( hwnd, n_true );

		n_paint_tool_icon_add();

		n_win_button_on_settingchange( &H_BTN_00_00 );
		n_win_button_on_settingchange( &H_BTN_01_00 );
		n_win_button_on_settingchange( &H_BTN_02_00 );
		n_win_button_on_settingchange( &H_BTN_03_00 );
		n_win_button_on_settingchange( &H_BTN_04_00 );

		n_win_button_on_settingchange( &H_BTN_00_01 );
		n_win_button_on_settingchange( &H_BTN_01_01 );
		n_win_button_on_settingchange( &H_BTN_02_01 );
		n_win_button_on_settingchange( &H_BTN_03_01 );
		n_win_button_on_settingchange( &H_BTN_04_01 );

		n_win_button_on_settingchange( &H_BTN_00_02 );
		n_win_button_on_settingchange( &H_BTN_01_02 );
		n_win_button_on_settingchange( &H_BTN_02_02 );
		n_win_button_on_settingchange( &H_BTN_03_02 );
		n_win_button_on_settingchange( &H_BTN_04_02 );

		n_paint_tool_resize( N_WIN_SET_DEFAULT );

		n_win_scroller_on_settingchange( H_SCR_SIZE  );
		n_win_scroller_on_settingchange( H_SCR_MIX   );
		n_win_scroller_on_settingchange( H_SCR_BOOST );
		n_win_scroller_on_settingchange( H_SCR_AIR   );
		n_win_scroller_on_settingchange( H_SCR_ZOOM  );

		n_win_colorpicker_on_settingchange( &cp );

	break;


	} // switch


}

LRESULT CALLBACK
n_paint_tool_wndproc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	static n_bool scr_init_onoff = n_true;


	n_paint_xmouse( hwnd, msg );


	n_paint_tool_on_settingchange( hwnd, msg, wparam, lparam );


	switch( msg ) {


	case WM_CREATE :


		// Global

		n_project_darkmode();

		n_win_ime_disable( hwnd );

		n_win_scroller_zero( H_SCR_SIZE  );
		n_win_scroller_zero( H_SCR_MIX   );
		n_win_scroller_zero( H_SCR_BOOST );
		n_win_scroller_zero( H_SCR_AIR   );
		n_win_scroller_zero( H_SCR_ZOOM  );

		n_win_button_zero( &H_BTN_00_00 );
		n_win_button_zero( &H_BTN_01_00 );
		n_win_button_zero( &H_BTN_02_00 );
		n_win_button_zero( &H_BTN_03_00 );
		n_win_button_zero( &H_BTN_04_00 );

		n_win_button_zero( &H_BTN_00_01 );
		n_win_button_zero( &H_BTN_01_01 );
		n_win_button_zero( &H_BTN_02_01 );
		n_win_button_zero( &H_BTN_03_01 );
		n_win_button_zero( &H_BTN_04_01 );

		n_win_button_zero( &H_BTN_00_02 );
		n_win_button_zero( &H_BTN_01_02 );
		n_win_button_zero( &H_BTN_02_02 );
		n_win_button_zero( &H_BTN_03_02 );
		n_win_button_zero( &H_BTN_04_02 );


		// [Needed]
		//
		//	don't rely on n_win_gui()/CreateWindow()'s return value

		hwnd_tool = hwnd;
		tooltype  = N_PAINT_TOOL_TYPE_PEN;


		// Window

		n_win_init_literal( hwnd, N_PAINT_APPNAME, "", "" );


		n_win_scroller_init_literal( H_SCR_SIZE , hwnd, "Size"  );
		n_win_scroller_init_literal( H_SCR_MIX  , hwnd, "Mix"   );
		n_win_scroller_init_literal( H_SCR_BOOST, hwnd, "Boost" );
		n_win_scroller_init_literal( H_SCR_AIR  , hwnd, "Air"   );
		n_win_scroller_init_literal( H_SCR_ZOOM , hwnd, "Zoom"  );

		n_win_colorpicker_init( &cp, hwnd );

		n_win_button_init( &H_BTN_00_00, hwnd, N_STRING_EMPTY, PBS_NORMAL );
		n_win_button_init( &H_BTN_01_00, hwnd, N_STRING_EMPTY, PBS_NORMAL );
		n_win_button_init( &H_BTN_02_00, hwnd, N_STRING_EMPTY, PBS_NORMAL );
		n_win_button_init( &H_BTN_03_00, hwnd, N_STRING_EMPTY, PBS_NORMAL );
		n_win_button_init( &H_BTN_04_00, hwnd, N_STRING_EMPTY, PBS_NORMAL );

		n_win_button_init( &H_BTN_00_01, hwnd, N_STRING_EMPTY, PBS_PRESSED );
		n_win_button_init( &H_BTN_01_01, hwnd, N_STRING_EMPTY, PBS_NORMAL );
		n_win_button_init( &H_BTN_02_01, hwnd, N_STRING_EMPTY, PBS_NORMAL );
		n_win_button_init( &H_BTN_03_01, hwnd, N_STRING_EMPTY, PBS_NORMAL );
		n_win_button_init( &H_BTN_04_01, hwnd, N_STRING_EMPTY, PBS_NORMAL );

		n_win_button_init( &H_BTN_00_02, hwnd, N_STRING_EMPTY, PBS_NORMAL );
		n_win_button_init( &H_BTN_01_02, hwnd, N_STRING_EMPTY, PBS_NORMAL );
		n_win_button_init( &H_BTN_02_02, hwnd, N_STRING_EMPTY, PBS_NORMAL );
		n_win_button_init( &H_BTN_03_02, hwnd, N_STRING_EMPTY, PBS_NORMAL );
		n_win_button_init( &H_BTN_04_02, hwnd, N_STRING_EMPTY, PBS_NORMAL );


		n_paint_tool_icon_add();


		// Style

		n_win_style_new( hwnd, WS_POPUP | WS_CAPTION );

#ifdef _WIN64
		SetWindowSubclass( H_BTN_02_00.hwnd, n_paint_tool_clipboard_subclass, 0, 0 );
#else  // #ifdef _WIN64
		n_paint_tool_clipboard_pfunc = n_win_gui_subclass_set( H_BTN_02_00.hwnd, n_paint_tool_clipboard_subclass );
#endif // #ifdef _WIN64

#ifdef _WIN64
		SetWindowSubclass( H_BTN_04_00.hwnd, n_paint_tool_savebutton_subclass, 0, 0 );
#else  // #ifdef _WIN64
		n_paint_tool_savebutton_pfunc = n_win_gui_subclass_set( H_BTN_04_00.hwnd, n_paint_tool_savebutton_subclass );
#endif // #ifdef _WIN64


		// [!] : unused

		ShowWindow( H_BTN_01_00.hwnd, SW_HIDE );
		ShowWindow( H_BTN_03_01.hwnd, SW_HIDE );


		// Size

		// [Needed] : before n_paint_tool_resize()

//n_win_scrollbar_debug_instance = &H_SCR_SIZE->scrollbar;

		n_win_scroller_scroll_parameter( H_SCR_SIZE , 1,  5,               50, pensize, n_true );
		n_win_scroller_scroll_parameter( H_SCR_BOOST, 1, 10,              100, boost  , n_true );
		n_win_scroller_scroll_parameter( H_SCR_MIX  , 1, 10,              100, mix    , n_true );
		n_win_scroller_scroll_parameter( H_SCR_AIR  , 1, 10,              255, air    , n_true );
		n_win_scroller_scroll_parameter( H_SCR_ZOOM , 1, 10, N_PAINT_ZOOM_MAX, zoom   , n_true );

		n_win_colorpicker_refresh( &cp, cp.a, cp.r, cp.g, cp.b );

		scr_init_onoff = n_false;


		n_paint_tool_resize( N_WIN_SET_NEEDPOS | N_WIN_SET_INNERPOS );


		// Init

		n_paint_tool_iconbutton_toolswitch( 1 );

		n_paint_tool_iconbutton_pentype( tooltype );


		// Display

		ShowWindowAsync( hwnd, SW_HIDE );

	break;


	case WM_NCLBUTTONDOWN :
	case WM_LBUTTONDOWN   :

		SetFocus( hwnd );

	break;


	case WM_COMMAND :
	{

		HWND h = (HWND) lparam;


		if ( h == H_BTN_00_00.hwnd )
		{
			n_paint_tool_iconbutton_toolswitch( -1 );
		} else
		if ( h == H_BTN_01_00.hwnd )
		{
			//
		} else
		if ( h == H_BTN_02_00.hwnd )
		{

			if ( n_paint_tool_clipboard == N_PAINY_TOOL_CLIPBOARD_IN )
			{
				n_paint_grabber_clipboard();
			} else {
				if ( n_paint_layer_onoff )
				{
					n_type_int y = n_paint_layer_txtbox.select_cch_y;

					if ( N_PAINT_GRABBER_IS_DRAG_OK() )
					{
						n_clipboard_nbmp_set( &n_paint_layer_data[ y ].bmp_grab );
					} else {
						n_clipboard_nbmp_set( &n_paint_layer_data[ y ].bmp_data );
					}
				} else {
					if ( N_PAINT_GRABBER_IS_DRAG_OK() )
					{
						n_clipboard_nbmp_set( n_paint_bmp_grab );
					} else {
						n_clipboard_nbmp_set( n_paint_bmp_data );
					}
				}
			}

		} else
		if ( h == H_BTN_03_00.hwnd )
		{
			n_win_gui( hwnd_main, WINDOW, n_paint_resizer_wndproc, &n_paint_hpopup );
		} else
		if ( h == H_BTN_04_00.hwnd )
		{
			n_paint_formatter_mode = N_PAINT_FORMATTER_MODE_NORMAL;
			n_paint_formatter_name = n_paint_bmpname;

			n_win_gui( hwnd_main, WINDOW, n_paint_formatter_wndproc, &n_paint_hpopup );
		} else

		if ( h == H_BTN_00_01.hwnd )
		{
			n_paint_tool_iconbutton_pentype( N_PAINT_TOOL_TYPE_PEN );
		} else
		if ( h == H_BTN_01_01.hwnd )
		{
			n_paint_tool_iconbutton_pentype( N_PAINT_TOOL_TYPE_FILL );
		} else
		if ( h == H_BTN_02_01.hwnd )
		{
			if ( tooltype == N_PAINT_TOOL_TYPE_GRAB ) { n_paint_grabber_reset(); }
			n_paint_tool_iconbutton_pentype( N_PAINT_TOOL_TYPE_GRAB );
		} else
		if ( h == H_BTN_03_01.hwnd )
		{
			//
		} else
		if ( h == H_BTN_04_01.hwnd )
		{
			n_win_gui( hwnd_main, WINDOW, n_paint_colorhistory_wndproc, &n_paint_hpopup );
		} else

		if ( h == H_BTN_00_02.hwnd )
		{
			n_paint_tool_filter( N_PAINT_FILTER_SCALE_LIL );
		} else
		if ( h == H_BTN_01_02.hwnd )
		{
			n_paint_tool_filter( N_PAINT_FILTER_SCALE_BIG );
		} else
		if ( h == H_BTN_02_02.hwnd )
		{
			n_paint_tool_filter( N_PAINT_FILTER_MIRROR );
		} else
		if ( h == H_BTN_03_02.hwnd )
		{
			n_paint_tool_filter( N_PAINT_FILTER_ROTATE_L );
		} else
		if ( h == H_BTN_04_02.hwnd )
		{
			n_paint_tool_filter( N_PAINT_FILTER_ROTATE_R );
		} else

		if ( h == n_win_scroller_scroll_hwnd( H_SCR_SIZE ) )
		{

			if ( scr_init_onoff == n_false ) { pensize = (n_type_gfx) wparam; }

			n_win_hwndprintf_literal( H_SCR_SIZE->value, "%3d", n_paint_pensize() );

		} else

		if ( h == n_win_scroller_scroll_hwnd( H_SCR_MIX ) )
		{

			if ( scr_init_onoff == n_false ) { mix = (n_type_gfx) wparam; }

			n_win_hwndprintf_literal( H_SCR_MIX->value, "%3d", mix );

		} else

		if ( h == n_win_scroller_scroll_hwnd( H_SCR_BOOST ) )
		{

			if ( scr_init_onoff == n_false ) { boost = (n_type_gfx) wparam; }

			n_win_hwndprintf_literal( H_SCR_BOOST->value, "%3d", boost );

		} else

		if ( h == n_win_scroller_scroll_hwnd( H_SCR_AIR ) )
		{

			if ( scr_init_onoff == n_false ) { air = (n_type_gfx) wparam; }

			n_win_hwndprintf_literal( H_SCR_AIR->value, "%3d", air );

		} else

		if ( h == n_win_scroller_scroll_hwnd( H_SCR_ZOOM ) )
		{
//n_posix_debug_literal( " %d %d ", wparam, zoom );

			if ( scr_init_onoff != n_false )
			{
				if ( n_paint_is_zoom_in( zoom ) )
				{
					n_win_hwndprintf_literal( H_SCR_ZOOM->value,  "%3d", n_paint_zoom_get( zoom ) );
				} else {
					n_win_hwndprintf_literal( H_SCR_ZOOM->value, "1/%d", n_paint_zoom_get( zoom ) );
				}

				break;
			}


			static n_type_gfx prev = N_PAINT_ZOOM_ZERO + 1;

			zoom = n_paint_zoom_clamp( zoom, (n_type_gfx) wparam );
			H_SCR_ZOOM->scrollbar.unit_pos = zoom;

			if ( n_paint_is_zoom_in( zoom ) )
			{
				n_win_hwndprintf_literal( H_SCR_ZOOM->value,  "%3d", n_paint_zoom_get( zoom ) );
			} else {
				n_win_hwndprintf_literal( H_SCR_ZOOM->value, "1/%d", n_paint_zoom_get( zoom ) );
			}


			// [!] : restore scroll position

			n_type_gfx ox = nwin_main.csx / 2;
			n_type_gfx oy = nwin_main.csy / 2;

			if ( hwnd_main == n_win_cursor2hwnd() )
			{
				n_win_cursor_position_relative( hwnd_main, &ox, &oy );
			}

			nwin_main.scrollx += ox;
			nwin_main.scrolly += oy;

			if ( ( n_paint_is_zoom_in( zoom ) )&&( n_paint_is_zoom_in( prev ) ) )
			{
				nwin_main.scrollx /= n_paint_zoom_get( prev );
				nwin_main.scrolly /= n_paint_zoom_get( prev );
			} else {
				nwin_main.scrollx *= n_paint_zoom_get( prev );
				nwin_main.scrolly *= n_paint_zoom_get( prev );
			}

			nwin_main.scrollx += nwin_main.scrollx % 2;
			nwin_main.scrolly += nwin_main.scrolly % 2;

			if ( ( n_paint_is_zoom_in( zoom ) )&&( n_paint_is_zoom_in( prev ) ) )
			{
				nwin_main.scrollx *= n_paint_zoom_get( zoom );
				nwin_main.scrolly *= n_paint_zoom_get( zoom );
			} else {
				nwin_main.scrollx /= n_paint_zoom_get( zoom );
				nwin_main.scrolly /= n_paint_zoom_get( zoom );
			}

			nwin_main.scrollx -= ox;
			nwin_main.scrolly -= oy;

			n_paint_hscr.unit_pos = nwin_main.scrollx;
			n_paint_vscr.unit_pos = nwin_main.scrolly;


			prev = zoom;


			n_paint_refresh_all_id( N_PAINT_REFRESH_ID_ZOOM );

			//n_paint_refresh_combine = N_PAINT_REFRESH_WINDOW;
			//n_win_refresh( hwnd_main, n_false );

		}

	}
	break;


	case WM_SETFOCUS :

		n_paint_status();

	break;


	case WM_MOUSEWHEEL :

		if ( H_BTN_02_00.hwnd == n_win_cursor2hwnd() )
		{

			int delta = n_win_scrollbar_wheeldelta( wparam, 1, n_false );
//n_win_hwndprintf_literal( hwnd_tool, " %d ", delta );

			n_paint_tool_clipboard_switch( delta );

		} else
		if ( H_BTN_04_00.hwnd == n_win_cursor2hwnd() )
		{

			int delta = n_win_scrollbar_wheeldelta( wparam, 1, n_false );
//n_win_hwndprintf_literal( hwnd_tool, " %d ", delta );

			n_paint_tool_saveicon_switch( delta );

		}

	break;


	case WM_CLOSE :

		// [!] : for Alt + F4

		return 0;

	break;


	} // switch()


	{
		LRESULT ret = n_win_darkmode_proc( hwnd, msg, wparam, lparam );
		if ( ret ) { return ret; }
	}


	if ( scr_init_onoff == n_false )
	{
		n_win_scroller_proc( hwnd, msg, wparam, lparam, H_SCR_SIZE  );
		n_win_scroller_proc( hwnd, msg, wparam, lparam, H_SCR_MIX   );
		n_win_scroller_proc( hwnd, msg, wparam, lparam, H_SCR_BOOST );
		n_win_scroller_proc( hwnd, msg, wparam, lparam, H_SCR_AIR   );
		n_win_scroller_proc( hwnd, msg, wparam, lparam, H_SCR_ZOOM  );

		nwclr_proc( hwnd, msg, wparam, lparam, &cp );
	}

	n_win_button_proc( hwnd, msg, wparam, lparam, &H_BTN_00_00 );
	n_win_button_proc( hwnd, msg, wparam, lparam, &H_BTN_01_00 );
	n_win_button_proc( hwnd, msg, wparam, lparam, &H_BTN_02_00 );
	n_win_button_proc( hwnd, msg, wparam, lparam, &H_BTN_03_00 );
	n_win_button_proc( hwnd, msg, wparam, lparam, &H_BTN_04_00 );

	n_win_button_proc( hwnd, msg, wparam, lparam, &H_BTN_00_01 );
	n_win_button_proc( hwnd, msg, wparam, lparam, &H_BTN_01_01 );
	n_win_button_proc( hwnd, msg, wparam, lparam, &H_BTN_02_01 );
	n_win_button_proc( hwnd, msg, wparam, lparam, &H_BTN_03_01 );
	n_win_button_proc( hwnd, msg, wparam, lparam, &H_BTN_04_01 );

	n_win_button_proc( hwnd, msg, wparam, lparam, &H_BTN_00_02 );
	n_win_button_proc( hwnd, msg, wparam, lparam, &H_BTN_01_02 );
	n_win_button_proc( hwnd, msg, wparam, lparam, &H_BTN_02_02 );
	n_win_button_proc( hwnd, msg, wparam, lparam, &H_BTN_03_02 );
	n_win_button_proc( hwnd, msg, wparam, lparam, &H_BTN_04_02 );


	n_paint_tool_grabber_proc( hwnd, msg, wparam, lparam );


	n_win_simplemenu_proc( hwnd, msg, &wparam, &lparam, NULL );


	n_paint_thumbnail_proc( hwnd, msg, wparam, lparam );


	return DefWindowProc( hwnd, msg, wparam, lparam );
}

void
n_paint_tool_input_proc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	switch( msg ) {


	case WM_MOUSEWHEEL :
	{
//n_posix_debug_literal( "" );
		int delta = n_win_scrollbar_wheeldelta( wparam, 1 ,n_false );
		n_paint_tool_scrollbar_updown( H_SCR_ZOOM, delta * -1 );

	}
	break;


	case WM_KEYDOWN :

		if ( n_paint_resizer_backup_onoff ) { break; }

		if ( n_false == IsWindowEnabled( hwnd ) ) { break; }

		if ( n_win_simplemenu_target != NULL ) { break; }

/*
		if ( wparam == VK_ESCAPE )
		{
			n_win_hwndprintf_literal( hwnd_main, "%d %d", tooltype, grabber );
		}
*/

		if ( wparam == VK_F2 )
		{

			EnableWindow( hwnd_tool, n_posix_false );

			if ( n_project_dialog_yesno( hwnd_main, n_posix_literal( "Fork?" ) ) )
			{
				n_posix_char *dir = n_string_path_upperfolder_new( n_paint_bmpname );
				n_posix_char *ext = n_string_path_ext_get_new( n_paint_bmpname );
				n_posix_char *nam = n_string_path_tmpname_new( ext );

				n_memory_free( n_paint_bmpname );
				n_paint_bmpname = n_string_path_make_new( dir, nam );

				if ( n_paint_layer_onoff )
				{
					n_memory_free( n_paint_layer_name_main );
					n_paint_layer_name_main = n_string_path_carboncopy( n_paint_bmpname );
					if ( n_paint_format_is_lyr( n_paint_layer_name_main ) ) { n_string_path_ext_del( n_paint_layer_name_main ); }

					n_type_int i = 0;
					n_posix_loop
					{

						n_paint_layer_is_mod[ i ] = n_true;

						i++;
						if ( i >= n_paint_layer_count ) { break; }
					}
				}

				n_memory_free( dir );
				n_memory_free( ext );
				n_memory_free( nam );

				n_paint_title();

//n_posix_debug_literal( "%s", n_paint_bmpname );
			}

			EnableWindow( hwnd_tool, n_posix_true );

			break;
		} else
		if ( wparam == VK_F5 )
		{
			if ( n_project_dialog_yesno( hwnd_main, n_posix_literal( "Reset Cache?" ) ) )
			{
				n_paint_cache_zero( &n_paint_bmp_scrl );
				n_paint_cache_zero( &n_paint_bmp_wgrb );

				n_paint_refresh_client_id( N_PAINT_REFRESH_ID_LAYER );
			}

			break;
		} else
		if ( wparam == VK_F11 )
		{
			n_type_int i = 0;
			n_posix_loop
			{
				n_paint_layer_is_mod[ i ] = n_true;

				i++;
				if ( i >= n_paint_layer_count ) { break; }
			}

			n_project_dialog_info( hwnd_main, n_posix_literal( "now you can save" ) );

			break;
		} else
		if ( wparam == VK_F12 )
		{
			n_paint_printer( hwnd_main );

			break;
		} else
		if ( wparam == VK_F1 )
		{
/*
			n_type_int y = n_paint_layer_txtbox.select_cch_y;

			n_posix_debug_literal
			(
				"Visible\t%d \n"
				"Percent\t%d \n"
				"Blend  \t%f \n"
				"Blur   \t%d \n",
				n_paint_layer_data[ y ].visible,
				n_paint_layer_data[ y ].percent,
				n_paint_layer_data[ y ].blend,
				n_paint_layer_data[ y ].blur
			);

			break;
*/
		}


		if ( n_win_is_hovered( hwnd_layr ) )
		{

			if ( n_win_is_input( VK_SHIFT ) )
			{

				//

			} else
			if ( n_win_is_input( VK_CONTROL ) )
			{

				if ( n_win_is_input( VK_UP ) )
				{
					n_type_int y = n_paint_layer_txtbox.select_cch_y;
					n_paint_layer_swap_up( y );
				} else
				if ( n_win_is_input( VK_DOWN ) )
				{
					n_type_int y = n_paint_layer_txtbox.select_cch_y;
					n_paint_layer_swap_down( y );
				}// else

			} else {

				if ( n_win_is_input( VK_UP ) )
				{
					n_type_int y = n_paint_layer_txtbox.select_cch_y;
					n_paint_layer_selection_move_up( y );
				} else
				if ( n_win_is_input( VK_DOWN ) )
				{
					n_type_int y = n_paint_layer_txtbox.select_cch_y;
					n_paint_layer_selection_move_down( y );
				} else
				if ( n_win_is_input( VK_RETURN ) )
				{
					n_paint_layer_rename_target = n_paint_layer_txtbox.select_cch_y;
					n_paint_layer_rename_go();
				}// else

			}

			break;
		}


		if ( n_win_is_input( VK_CONTROL ) )
		{

			if ( wparam == 'A' )
			{

				if ( tooltype == N_PAINT_TOOL_TYPE_GRAB )
				{
					if ( N_PAINT_GRABBER_IS_NEUTRAL() )
					{
						n_paint_grabber_select_all();
					}
				}

			} else
			if ( wparam == 'C' )
			{

				if ( tooltype == N_PAINT_TOOL_TYPE_GRAB )
				{
					if ( N_PAINT_GRABBER_IS_DRAG_OK() )
					{
						n_paint_grabber_copy();
					}
				}

			} else
			if ( wparam == 'V' )
			{

				if ( tooltype == N_PAINT_TOOL_TYPE_GRAB )
				{
					if ( N_PAINT_GRABBER_IS_DRAG_OK() )
					{
						n_paint_grabber_paste();
					}
				}

			} //else


			break;
		}


		if ( n_win_is_input( VK_SHIFT ) )
		{

			if ( tooltype == N_PAINT_TOOL_TYPE_PEN )
			{
				n_paint_pen_key2cursor();
			}

			break;
		}


		// [!] : alt key

		if ( n_win_is_input( VK_MENU ) )
		{

			break;
		}


		if ( N_PAINT_GRABBER_IS_DRAG_OK() )
		{

			if ( wparam == VK_INSERT )
			{

				n_paint_grabber_paste();

			} else
			if ( ( wparam == VK_UP )||( wparam == VK_DOWN )||( wparam == VK_LEFT )||( wparam == VK_RIGHT ) )
			{

				if ( tooltype == N_PAINT_TOOL_TYPE_GRAB )
				{

					const n_type_gfx step = 1;

					n_type_gfx x,y; n_paint_grabber_system_get( &x,&y, NULL,NULL, NULL,NULL );

					if ( n_win_is_input( VK_UP    ) ) { y -= step; }
					if ( n_win_is_input( VK_DOWN  ) ) { y += step; }
					if ( n_win_is_input( VK_LEFT  ) ) { x -= step; }
					if ( n_win_is_input( VK_RIGHT ) ) { x += step; }

					n_paint_grabber_system_set( &x,&y, NULL,NULL, NULL,NULL );
					n_paint_grabber_status();

					n_paint_grabber_resync_auto();

				}

			}

		} else
		if ( ( N_PAINT_GRABBER_IS_STRETCH_PROPORTIONAL() )||( N_PAINT_GRABBER_IS_STRETCH_TRANSFORM() ) )
		{

			if ( ( wparam == VK_UP )||( wparam == VK_DOWN )||( wparam == VK_LEFT )||( wparam == VK_RIGHT ) )
			{

				if ( hwnd_main != n_win_cursor2hwnd() ) { break; }


				const n_type_gfx step = 1;

				POINT p; GetCursorPos( &p );

				if ( n_win_is_input( VK_UP    ) ) { p.y -= step; }
				if ( n_win_is_input( VK_DOWN  ) ) { p.y += step; }
				if ( n_win_is_input( VK_LEFT  ) ) { p.x -= step; }
				if ( n_win_is_input( VK_RIGHT ) ) { p.x += step; }

				SetCursorPos( p.x, p.y );

			}

		}


		if ( tooltype != N_PAINT_TOOL_TYPE_GRAB )
		{

			const n_type_gfx step = 1;

			n_type_gfx delta_x = 0;
			n_type_gfx delta_y = 0;

			if ( n_win_is_input( VK_UP    ) ) { delta_y += step; }
			if ( n_win_is_input( VK_DOWN  ) ) { delta_y -= step; }
			if ( n_win_is_input( VK_LEFT  ) ) { delta_x += step; }
			if ( n_win_is_input( VK_RIGHT ) ) { delta_x -= step; }

			//if ( delta_x != 0 ) { n_win_scroll_position_updown( hwnd_main, SB_HORZ, delta_x ); }
			//if ( delta_y != 0 ) { n_win_scroll_position_updown( hwnd_main, SB_VERT, delta_y ); }

		}


		// [!] : don't use wparam : combinaiton with scrolling

		//if ( wparam == VK_RETURN )
		if ( n_win_is_input( VK_RETURN ) )
		{

			// [!] : useless
			//mouse_event( MOUSEEVENTF_LEFTDOWN, 0,0, 0, 0 );
			//mouse_event( MOUSEEVENTF_LEFTUP,   0,0, 0, 0 );

			if ( tooltype == N_PAINT_TOOL_TYPE_GRAB )
			{
				//
			} else {
				n_paint_pen_on_lbuttondown( hwnd_main );
				//n_win_message_send( hwnd_main, WM_LBUTTONDOWN, 0,0 );
			}

		}


		if ( wparam == VK_DELETE ) { wparam = N_PAINT_KEY_6; }


		if ( wparam == N_PAINT_KEY_A ) { n_win_message_send( hwnd_tool, WM_COMMAND, 0, H_BTN_00_00.hwnd ); }
		if ( wparam == N_PAINT_KEY_B ) { n_win_message_send( hwnd_tool, WM_COMMAND, 0, H_BTN_01_00.hwnd ); }
		if ( wparam == N_PAINT_KEY_C ) { n_win_message_send( hwnd_tool, WM_COMMAND, 0, H_BTN_02_00.hwnd ); }
		if ( wparam == N_PAINT_KEY_D ) { n_win_message_send( hwnd_tool, WM_COMMAND, 0, H_BTN_03_00.hwnd ); }
		if ( wparam == N_PAINT_KEY_E ) { n_win_message_send( hwnd_tool, WM_COMMAND, 0, H_BTN_04_00.hwnd ); }

		if ( wparam == 'F' )
		{
			n_paint_tool_iconbutton_pentype( N_PAINT_TOOL_TYPE_PEN );
		}
		if ( wparam == 'G' )
		{
			n_paint_tool_iconbutton_pentype( N_PAINT_TOOL_TYPE_FILL );
		}
		if ( wparam == 'H' )
		{
			if ( tooltype == N_PAINT_TOOL_TYPE_GRAB ) { n_paint_grabber_reset(); }
			n_paint_tool_iconbutton_pentype( N_PAINT_TOOL_TYPE_GRAB );
		}
		if ( wparam == 'I' )
		{
			//
		}
		if ( wparam == N_PAINT_KEY_J )
		{
			n_win_gui( hwnd_main, WINDOW, n_paint_colorhistory_wndproc, &n_paint_hpopup );
		}

		if ( wparam == 'K' ) { n_paint_tool_filter( N_PAINT_FILTER_SCALE_LIL ); }
		if ( wparam == 'L' ) { n_paint_tool_filter( N_PAINT_FILTER_SCALE_BIG ); }
		if ( wparam == 'M' ) { n_paint_tool_filter( N_PAINT_FILTER_MIRROR    ); }
		if ( wparam == 'N' ) { n_paint_tool_filter( N_PAINT_FILTER_ROTATE_L  ); }
		if ( wparam == 'O' ) { n_paint_tool_filter( N_PAINT_FILTER_ROTATE_R  ); }

		if ( wparam == 'P' ) { n_paint_tool_scrollbar_updown( H_SCR_SIZE , -1 ); }
		if ( wparam == 'Q' ) { n_paint_tool_scrollbar_updown( H_SCR_SIZE ,  1 ); }
		if ( wparam == 'R' ) { n_paint_tool_scrollbar_updown( H_SCR_MIX  , -1 ); }
		if ( wparam == 'S' ) { n_paint_tool_scrollbar_updown( H_SCR_MIX  ,  1 ); }
		if ( wparam == 'T' ) { n_paint_tool_scrollbar_updown( H_SCR_BOOST, -1 ); }

		if ( wparam == 'U' ) { n_paint_tool_scrollbar_updown( H_SCR_BOOST,  1 ); }
		if ( wparam == 'V' ) { n_paint_tool_scrollbar_updown( H_SCR_AIR  , -1 ); }
		if ( wparam == 'W' ) { n_paint_tool_scrollbar_updown( H_SCR_AIR  ,  1 ); }
		if ( wparam == 'X' ) { n_paint_tool_scrollbar_updown( H_SCR_ZOOM , -1 ); }
		if ( wparam == 'Y' ) { n_paint_tool_scrollbar_updown( H_SCR_ZOOM ,  1 ); }

		if ( wparam == 'Z' )
		{
			if ( n_win_is_hovered( hwnd_main ) )
			{
				if ( n_paint_hamburger_is_hovered == n_false )
				{
					n_win_cursor_add_literal( NULL, "NONNON_PAINT_ERASER" );
					n_win_cursor_add_literal( hwnd, "NONNON_PAINT_ERASER" );
				}

				nwclr_enable( &cp, n_false );

				n_paint_quick_eraser = n_true;
			}
		}

		if ( wparam == N_PAINT_KEY_1 ) { n_paint_menu_main( N_PAINT_MENU_PREVIEW   , n_true ); }
		if ( wparam == N_PAINT_KEY_2 ) { n_paint_menu_main( N_PAINT_MENU_GRID      , n_true ); }
		if ( wparam == N_PAINT_KEY_3 ) { n_paint_menu_main( N_PAINT_MENU_PIXELGRID , n_true ); }
		if ( wparam == N_PAINT_KEY_4 ) { n_paint_menu_main( N_PAINT_MENU_THUMBNAIL , n_true ); }
		if ( wparam == N_PAINT_KEY_5 ) { n_paint_menu_main( N_PAINT_MENU_GRAYCANVAS, n_true ); }
		if ( wparam == N_PAINT_KEY_6 ) { n_paint_menu_main( N_PAINT_MENU_CLR_CANVAS, n_true ); }
		if ( wparam == N_PAINT_KEY_7 ) { n_paint_menu_main( N_PAINT_MENU_ALPHA     , n_true ); }
		if ( wparam == N_PAINT_KEY_8 ) { n_paint_menu_main( N_PAINT_MENU_REPLACER  , n_true ); }
		if ( wparam == N_PAINT_KEY_9 ) { n_paint_menu_main( N_PAINT_MENU_INI2GDI   , n_true ); }
		if ( wparam == N_PAINT_KEY_0 ) { n_paint_menu_main( N_PAINT_MENU_PROPERTY  , n_true ); }

	break;

	case WM_KEYUP :
//n_win_hwndprintf_literal( hwnd_main, "%d", wparam );

		if ( wparam == 'Z' )
		{
			n_paint_pen_cursor_default(      NULL );
			n_paint_pen_cursor_default( hwnd_main );

			nwclr_enable( &cp, n_true );

			n_paint_quick_eraser = n_false;
		}

		if ( wparam == VK_RETURN )
		{

			if ( tooltype == N_PAINT_TOOL_TYPE_GRAB )
			{
				//
			} else {
				n_paint_pen_on_lbuttonup( hwnd_main );
				//n_win_message_send( hwnd_main, WM_LBUTTONUP, 0,0 );
			}

		}

	break;


	} // switch


	return;
}


#undef H_BTN_00_00
#undef H_BTN_01_00
#undef H_BTN_02_00
#undef H_BTN_03_00
#undef H_BTN_04_00

#undef H_BTN_00_01
#undef H_BTN_01_01
#undef H_BTN_02_01
#undef H_BTN_03_01
#undef H_BTN_04_01

#undef H_BTN_00_02
#undef H_BTN_01_02
#undef H_BTN_02_02
#undef H_BTN_03_02
#undef H_BTN_04_02


#undef H_SCR_SIZE
#undef H_SCR_MIX
#undef H_SCR_BOOST
#undef H_SCR_AIR
#undef H_SCR_ZOOM

