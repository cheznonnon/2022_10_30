// Nonnon Win32 System Information
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#ifndef _H_NONNON_WIN32_SYSINFO_DEBUG
#define _H_NONNON_WIN32_SYSINFO_DEBUG




#include "../win/cursor.c"




#define N_SYSINFO_CCH ( 1024 )




n_posix_bool
n_sysinfo_window( HWND hwnd, n_posix_char *ret, n_posix_bool always_on )
{

	// [!] : Win95 : don't use WINDOWPLACEMENT : return invalid values always

	static n_posix_char str_prv[ N_SYSINFO_CCH ];
	static n_posix_char str_cur[ N_SYSINFO_CCH ];


	static n_posix_bool is_first = n_posix_true;

	if ( is_first )
	{

		is_first = n_posix_false;

		n_string_zero( str_prv, N_SYSINFO_CCH );
		n_string_zero( str_cur, N_SYSINFO_CCH );

	}


	HWND h = n_win_cursor2hwnd();
	RECT rect_w; GetWindowRect( h, &rect_w );
	RECT rect_c; GetClientRect( h, &rect_c );

	n_posix_sprintf
	(
		str_cur,
#ifdef UNICODE
		L"GetWindowRect   %ld %ld %ld %ld \r\n"
		L"Size            %ld %ld \r\n"
		L"GetClientRect   %ld %ld %ld %ld \r\n"
		L"\r\n"
		L"IsWindow        %d \r\n"
		L"IsWindowEnabled %d \r\n"
		L"IsWindowUnicode %d \r\n"
		L"IsWindowVisible %d \r\n"
		L"IsIconic        %d \r\n"
		L"IsZoomed        %d \r\n",
#else  // #ifdef UNICODE
		 "GetWindowRect   %ld %ld %ld %ld \r\n"
		 "Size            %ld %ld \r\n"
		 "GetClientRect   %ld %ld %ld %ld \r\n"
		 "\r\n"
		 "IsWindow        %d \r\n"
		 "IsWindowEnabled %d \r\n"
		 "IsWindowUnicode %d \r\n"
		 "IsWindowVisible %d \r\n"
		 "IsIconic        %d \r\n"
		 "IsZoomed        %d \r\n",
#endif // #ifdef UNICODE

		rect_w.left, rect_w.top, rect_w.right, rect_w.bottom,
		rect_w.right  - rect_w.left,
		rect_w.bottom - rect_w.top,
		rect_c.left, rect_c.top, rect_c.right, rect_c.bottom,
		IsWindow( h ),
		IsWindowEnabled( h ),
		IsWindowUnicode( h ),
		IsWindowVisible( h ),
		IsIconic( h ),
		IsZoomed( h )
	);


	if ( always_on == n_posix_false )
	{
		if ( n_string_is_same( str_prv, str_cur ) ) { return n_posix_false; }
	}

	n_string_copy( str_cur, ret     );
	n_string_copy( str_cur, str_prv );


	return n_posix_true;
}

n_posix_bool
n_sysinfo_class( HWND hwnd, n_posix_char *ret, n_posix_bool always_on )
{

	static n_posix_char str_prv[ N_SYSINFO_CCH ];
	static n_posix_char str_cur[ N_SYSINFO_CCH ];

	static n_posix_bool is_first = n_posix_true;

	if ( is_first )
	{

		is_first = n_posix_false;

		n_string_zero( str_prv, N_SYSINFO_CCH );
		n_string_zero( str_cur, N_SYSINFO_CCH );

	}


	n_posix_char str_class[ N_SYSINFO_CCH ];
	n_posix_char      text[ N_SYSINFO_CCH ];

	HWND         h;
	DWORD      pid;
	n_type_int   i;


	h = n_win_cursor2hwnd();


	GetWindowThreadProcessId( h, &pid );
	i = n_posix_sprintf_literal( str_cur, "ProcessID : %lu \r\n", pid );

	n_posix_loop
	{

		GetClassName( h, str_class, N_SYSINFO_CCH );

		if ( n_posix_false == n_string_is_same_literal( "Edit", str_class ) )
		{
			n_win_text_get( h, text, N_SYSINFO_CCH );
		} else {
			n_string_copy_literal( "", text );
		}

		i += n_posix_sprintf
		(
			&str_cur[ i ],
#ifdef UNICODE
			L"    \"%s\" \r\n"
			L"    0x%08lx : EX 0x%08lx : %s \r\n",
#else  // #ifdef UNICODE
			 "    \"%s\" \r\n"
			 "    0x%08lx : EX 0x%08lx : %s \r\n",
#endif // #ifdef UNICODE
			text,
			(DWORD) GetWindowLong( h, GWL_STYLE   ),
			(DWORD) GetWindowLong( h, GWL_EXSTYLE ),
			str_class
		);

		i += n_posix_sprintf_literal( &str_cur[ i ], "%s", N_STRING_CRLF );


		h = GetParent( h );
		if ( h == NULL ) { break; }

		i += n_posix_sprintf_literal( &str_cur[ i ], "Parent%s", N_STRING_CRLF );

	}


	if ( always_on == n_posix_false )
	{
		if ( n_string_is_same( str_prv, str_cur ) ) { return n_posix_false; }
	}

	n_string_copy( str_cur, ret     );
	n_string_copy( str_cur, str_prv );


	return n_posix_true;
}

void
n_sysinfo_message( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	n_win_hwndprintf
	(
		hwnd,

#ifdef UNICODE
		L"Message        \t\t %d    \r\n"
		L"Message(hex)   \t\t %04x  \r\n"
		L"LOWORD(wParam) \t\t %d    \r\n"
		L"HIWORD(wParam) \t\t %d    \r\n"
		L"LOWORD(lParam) \t\t %d    \r\n"
		L"HIWORD(lParam) \t\t %d    \r\n"
		L"wParam         \t\t %d    \r\n"
		L"wParam(hex)    \t\t %04x  \r\n"
		L"lParam         \t\t %lu   \r\n"
		L"lParam(hex)    \t\t %08lx \r\n",
#else  // #ifdef UNICODE
		 "Message        \t\t %d    \r\n"
		 "Message(hex)   \t\t %04x  \r\n"
		 "LOWORD(wParam) \t\t %d    \r\n"
		 "HIWORD(wParam) \t\t %d    \r\n"
		 "LOWORD(lParam) \t\t %d    \r\n"
		 "HIWORD(lParam) \t\t %d    \r\n"
		 "wParam         \t\t %d    \r\n"
		 "wParam(hex)    \t\t %04x  \r\n"
		 "lParam         \t\t %lu   \r\n"
		 "lParam(hex)    \t\t %08lx \r\n",
#endif // #ifdef UNICODE

		msg, msg,
		LOWORD( wparam ), HIWORD( wparam ),
		LOWORD( lparam ), HIWORD( lparam ),
		(UINT ) wparam,  (UINT )  wparam,
		(DWORD) lparam,  (DWORD)  lparam
	);


	return;
}


#endif // _H_NONNON_WIN32_SYSINFO_DEBUG

