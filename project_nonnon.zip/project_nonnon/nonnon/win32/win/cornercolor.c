// Nonnon Win32
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#ifndef _H_NONNON_WIN32_WIN_CORNERCOLOR
#define _H_NONNON_WIN32_WIN_CORNERCOLOR




#include "./darkmode.c"
#include "./dwm.c"
#include "./property.c"




static u32 n_win_cornercolor = n_bmp_black;

u32
n_win_cornercolor_get( HWND hgui )
{

	u32 ret;

	if ( n_win_property_get_literal( hgui, "Toolband" ) )
	{
		ret = n_win_cornercolor;
	} else {
		ret = n_win_darkmode_systemcolor_colorref2argb_ui( COLOR_BTNFACE );
	}

//ret = n_win_darkmode_systemcolor_colorref2argb_ui( COLOR_BTNFACE );
	return ret;
}




void
n_win_cornercolor_init( void )
{

	if ( n_win_darkmode_onoff )
	{
		n_win_cornercolor = n_win_darkmode_systemcolor_colorref2argb_ui( COLOR_BTNFACE );
	} else
	if ( n_sysinfo_version_10_or_later() )
	{
		if ( n_win_dwm_is_accent_color_used() )
		{
			n_win_cornercolor = n_win_dwm_windowcolor();
		} else {
			n_win_cornercolor = n_bmp_white;
		}
	} else
	if ( n_sysinfo_version_8_or_later() )
	{
		// [x] : I cannot support this
		n_win_cornercolor = n_win_darkmode_systemcolor_colorref2argb_ui( COLOR_BTNFACE );
	} else
	if ( n_sysinfo_version_vista_or_later() )
	{
		if ( n_win_dwm_aeroglass_is_on() )
		{
			n_win_cornercolor = 0;
		} else {
			n_win_cornercolor = n_win_darkmode_systemcolor_colorref2argb_ui( COLOR_GRADIENTINACTIVECAPTION );
		}
	} else {
		n_win_cornercolor = n_win_darkmode_systemcolor_colorref2argb_ui( COLOR_BTNFACE );
	}

	return;
}




BOOL CALLBACK
n_win_cornercolor_EnumChildProc( HWND hwnd, LPARAM lparam )
{

	n_win_refresh( hwnd, n_posix_false );

	return TRUE;
}

void
n_win_cornercolor_proc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	switch( msg ) {


	case WM_ACTIVATE :

		if ( wparam == WA_INACTIVE )
		{

			if ( n_win_darkmode_onoff )
			{
				n_win_cornercolor = n_win_darkmode_systemcolor_colorref2argb_ui( COLOR_BTNFACE );
			} else
			if ( n_sysinfo_version_10_or_later() )
			{
				n_win_cornercolor = n_bmp_white;
			} else
			if ( n_sysinfo_version_8_or_later() )
			{
				// [x] : I cannot support this
				n_win_cornercolor = n_win_darkmode_systemcolor_colorref2argb_ui( COLOR_BTNFACE );
			} else
			if ( n_sysinfo_version_vista_or_later() )
			{
				if ( n_win_dwm_aeroglass_is_on() )
				{
					n_win_cornercolor = 0;
				} else {
					n_win_cornercolor = n_win_darkmode_systemcolor_colorref2argb_ui( COLOR_GRADIENTINACTIVECAPTION );
				}
//n_win_cornercolor = n_bmp_rgb( 0,255,0 );
			} else {
				n_win_cornercolor = n_win_darkmode_systemcolor_colorref2argb_ui( COLOR_BTNFACE );
			}

		} else {

			if ( n_win_darkmode_onoff )
			{
				n_win_cornercolor = n_win_darkmode_systemcolor_colorref2argb_ui( COLOR_BTNFACE );
			} else
			if ( n_sysinfo_version_10_or_later() )
			{
				if ( n_win_dwm_is_accent_color_used() )
				{
					n_win_cornercolor = n_win_dwm_windowcolor();
				} else {
					n_win_cornercolor = n_bmp_white;
				}
			} else
			if ( n_sysinfo_version_8_or_later() )
			{
				n_win_cornercolor = n_win_darkmode_systemcolor_colorref2argb_ui( COLOR_BTNFACE );
			} else
			if ( n_sysinfo_version_vista_or_later() )
			{
				if ( n_win_dwm_aeroglass_is_on() )
				{
					n_win_cornercolor = 0;
				} else {
					n_win_cornercolor = n_win_darkmode_systemcolor_colorref2argb_ui( COLOR_GRADIENTACTIVECAPTION );
				}
			} else {
				n_win_cornercolor = n_win_darkmode_systemcolor_colorref2argb_ui( COLOR_BTNFACE );
			}

		}

		{
			static n_posix_bool is_first = n_posix_true;

			if ( is_first ) { is_first = n_posix_false; break; }

			EnumChildWindows( hwnd, n_win_cornercolor_EnumChildProc, (LPARAM) 0 );
		}

	break;


	} // switch


	return;
}




#endif // _H_NONNON_WIN32_WIN_CORNERCOLOR

