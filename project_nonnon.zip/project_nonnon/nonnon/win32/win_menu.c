// Nonnon Spider
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// [Limitation] : customized system menu
//
//	WS_OVERLAPPEDWINDOW only supported


// [Limitation] : submenu support
//
//	you cannot use ID number zero
//	+ see sample code below


// [!] : checkbox / radiobutton like behavior
//
//	you need to implement n_win_menu_checkbox(), _radiobutton() manually
//
//	[ when "redraw" is n_posix_false ]
//	you need to implement n_win_menu_system_modify(), _popup_modify() manually
//	+ use when menu is flickering




#ifndef _H_NONNON_WIN32_WIN_MENU
#define _H_NONNON_WIN32_WIN_MENU




#include "../neutral/string.c"


#include "./win/_debug.c"
#include "./win/message.c"




#define N_WIN_MENU_NONE  0
#define N_WIN_MENU_RADIO 1
#define N_WIN_MENU_CHECK 2




typedef struct {

	int           style;
	n_posix_bool  onoff;
	n_posix_bool  gray;
	n_posix_char *string;

	// .style
	//
	//	N_WIN_MENU_NONE  : none         : "  Menu Item"
	//	N_WIN_MENU_RADIO : radio button : "o Menu Item"
	//	N_WIN_MENU_CHECK : checkbox     : "v Menu Item"

	// .onoff
	//
	//	n_posix_false : unchecked
	//	n_posix_true  :   checked

	// .gray
	//
	//	n_posix_false :  enable
	//	n_posix_true  : disable

	// .string
	//
	//	"---" : will be separator
	//	NULL  : means end of array


	int           id_offset;
	HMENU         hmenu_sub;

	// .id_offset
	//
	//	needed for submenu detection

	// .hmenu_sub
	//
	//	submenu handle if needed


	HMENU         hmenu_prev;

	// .hmenu_prev
	//
	//	internal
	//	for multiple instance when popup

} n_win_menu;




static n_posix_bool n_win_menu_stop_onoff = n_posix_false;




HMENU
n_win_menu_popup_hmenu_init( void )
{
	return CreatePopupMenu();
}

void
n_win_menu_popup_hmenu_exit( HMENU hmenu )
{

	DestroyMenu( hmenu );

	return;
}

void
n_win_menu_popup_show( HMENU hmenu, HWND hwnd )
{

	POINT p; GetCursorPos( &p );
	TrackPopupMenu( hmenu, 0, p.x,p.y, 0, hwnd, NULL );

	return;
}

void
n_win_menu_system_show( HMENU hmenu, HWND hwnd )
{

	// [!] : when you modify the system menu : don't use zero as menu ID

	POINT p; GetCursorPos( &p );
	int index = TrackPopupMenu( hmenu, TPM_RETURNCMD, p.x,p.y, 0, hwnd, NULL );
//n_win_hwndprintf_literal( n_win_hwnd_toplevel( hwnd ), " %d %d ", (int) GetLastError(), index );

	if ( index > 0 )
	{
		n_win_message_send( hwnd, WM_SYSCOMMAND, index, 0 );
	}


	return;
}

#define n_win_menu_popup_init(   a,b,c,d ) n_win_menu_popup_set( a,b,c,d, n_posix_true  )
#define n_win_menu_popup_modify( a,b,c,d ) n_win_menu_popup_set( a,b,c,d, n_posix_false )

#define n_win_menu_system_init(   a,b,c ) n_win_menu_system_set( a,b,c, n_posix_true  )
#define n_win_menu_system_modify( a,b,c ) n_win_menu_system_set( a,b,c, n_posix_false )

#define n_win_menu_system_set( a,b,c,d ) n_win_menu_popup_set( NULL, a,b,c,d )

// internal
void
n_win_menu_popup_set
(
               HMENU hmenu,
	        HWND hwnd,
	  n_win_menu menu[],
	         int offset,
	n_posix_bool init
)
{

	if ( hmenu == NULL )
	{
		hmenu = GetSystemMenu( hwnd, n_posix_false );
	}


	// [x] : Win9x : new structure will be handled as invalid

	typedef struct {

		UINT    cbSize;
		UINT    fMask;
		UINT    fType;
		UINT    fState;
		UINT    wID;
		HMENU   hSubMenu;
		HBITMAP hbmpChecked;
		HBITMAP hbmpUnchecked;
		DWORD   dwItemData;
		LPVOID  dwTypeData;
		UINT    cch;

	} n_MENUITEMINFO_old;

	MENUITEMINFO mii; ZeroMemory( &mii, sizeof( MENUITEMINFO ) );

	mii.cbSize = sizeof( n_MENUITEMINFO_old );
	mii.fMask  = MIIM_ID | MIIM_TYPE | MIIM_STATE;


	int i = 0;
	n_posix_loop
	{

		mii.wID = i + menu[ i ].id_offset;


		if ( menu[ i ].style == N_WIN_MENU_NONE )
		{

			mii.fType  = 0;
			mii.fState = MF_UNCHECKED;

		} else {

			if ( menu[ i ].style == N_WIN_MENU_RADIO )
			{
				mii.fType = MFT_RADIOCHECK;
			} else
			if ( menu[ i ].style == N_WIN_MENU_CHECK )
			{
				mii.fType = 0;
			}


			if ( menu[ i ].onoff )
			{
				mii.fState = MF_CHECKED;
			} else {
				mii.fState = MF_UNCHECKED;
			}

		}


		if ( n_string_is_same_literal( "---", menu[ i ].string ) )
		{
			mii.dwTypeData = (void*) NULL;
		} else {
			mii.dwTypeData = (void*) menu[ i ].string;
		}


		if ( menu[ i ].gray )
		{
			mii.fState |= MFS_GRAYED;
		}


		if ( menu[ i ].hmenu_sub != NULL )
		{
			mii.fMask    |=  MIIM_SUBMENU;
			mii.hSubMenu  =  menu[ i ].hmenu_sub;
		} else {
			mii.fMask    &= ~MIIM_SUBMENU;
			mii.hSubMenu  =  NULL;
		}


		if ( init )
		{
			InsertMenuItem ( hmenu, offset + i, n_posix_true, &mii );
		} else {
			SetMenuItemInfo( hmenu, offset + i, n_posix_true, &mii );
		}


		i++;
		if ( menu[ i ].string == NULL ) { break; }
	}

/*
	// [x] : not working
	{

		MENUINFO mi; n_memory_zero( &mi, sizeof( MENUINFO ) );

		mi.cbSize  = sizeof( MENUINFO );
		mi.fMask   = 16;//MIM_STYLE;
		mi.dwStyle = 0x08000000;//MNS_NOTIFYBYPOS;

		SetMenuInfo( hmenu, &mi );

	}
*/

	DrawMenuBar( hwnd );


	return;
}

#define n_win_menu_is_on( menu, i ) ( menu[ i ].onoff )

#define n_win_menu_on(  menu, i ) menu[ i ].onoff = n_posix_true
#define n_win_menu_off( menu, i ) menu[ i ].onoff = n_posix_false

void
n_win_menu_radiobutton( n_win_menu menu[], int check, int start, int end )
{

	if ( start < 0 ) { return; }
	if ( end   < 0 ) { return; }

	if ( start == end ) { return; }
	if ( start >= end ) { return; }


	int i = start;
	n_posix_loop
	{

		if ( i == check )
		{
			n_win_menu_on ( menu, i );
		} else {
			n_win_menu_off( menu, i );
		}

		i++;
		if ( i > end ) { break; }
	}


	return;
}

void
n_win_menu_checkbox( n_win_menu menu[], int index )
{

	if ( index < 0 ) { return; }

	if ( menu[ index ].style != N_WIN_MENU_CHECK ) { return; }

	if ( n_win_menu_is_on( menu, index ) )
	{
		n_win_menu_off( menu, index );
	} else {
		n_win_menu_on ( menu, index );
	}


	return;
}

void
n_win_menu_system_reset( HWND hwnd )
{

	GetSystemMenu( hwnd, n_posix_true );


	return;
}

int
n_win_menu_system_proc
(
	HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam,
	n_win_menu menu[],
	UINT       offset
)
{

	// [Limitation]
	//
	//	don't call twice or more

	// [!] : return value
	//
	//	-1   : not selected
	//	else : zero based index


	switch( msg ) {


	case WM_CREATE :

		n_win_menu_system_init( hwnd, menu, offset );

	break;


	case WM_SYSCOMMAND :
	{
/*
n_win_hwndprintf_literal
(
	n_win_hwnd_toplevel( hwnd ),
	"%d(%x) %d : %d %d",
	LOWORD( wparam ), LOWORD( wparam ), HIWORD( wparam ),
	LOWORD( lparam ), HIWORD( lparam )
);
*/

		int index = LOWORD( wparam );

		if ( index >= 0xf000 ) { break; }

		return index;

	}
	break;

/*
	// [x] : not work : see n_win_menu_popup_set()

	case 0x0126 :
	//case WM_MENUCOMMAND :
	{
n_posix_debug_literal( "%d %d", (int) wparam, (int) lparam );

		//HMENU menu = (HMENU) lparam;
		int   id   = wparam;


		return id;
	}
	break;
*/
/*
	// [x] : crash

	case WM_MENUSELECT :
	{
//n_posix_debug_literal( " %d %d %d ", LOWORD( wparam ), HIWORD( wparam ), (int) lparam );

		//HMENU menu = (HMENU) lparam;
		int   id   = LOWORD( wparam );

		return id;
	}
	break;
*/

	case WM_INITMENU :

//n_win_text_set_literal( "WM_INITMENU" );

	break;


	case WM_INITMENUPOPUP :
//n_win_hwndprintf_literal( hwnd, " HMENU %d : Offset %d : Is System %d ", (int) wparam, LOWORD( lparam ), HIWORD( lparam ) );

		// [!] : this HIWORD( lparam ) will be n_posix_true when system menu

		if ( n_posix_false == HIWORD( lparam ) ) { break; }

		if ( (HMENU) wparam == GetSystemMenu( hwnd, n_posix_false ) )
		{
			n_win_menu_system_modify( hwnd, menu, offset );
		}

	break;


	} // switch


	return -1;
}

int
n_win_menu_popup_proc
(
	HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam,
	HMENU      hmenu,
	n_win_menu menu[],
	UINT       offset
)
{

	// [Limitation]
	//
	//	don't call twice or more

	// [!] : return value
	//
	//	-1   : not selected
	//	else : zero based index


	static u32 timer_id = 0;


	switch( msg ) {


	case WM_TIMER :

		if ( wparam == 0 ) { break; }

		if ( timer_id == wparam )
		{
			n_win_menu_stop_onoff = n_posix_false;
			n_win_timer_exit( hwnd, timer_id );
		}

	break;


	case WM_CREATE :

		n_win_menu_popup_init( hmenu, hwnd, menu, offset );

	break;


	case WM_INITMENU :

//n_win_text_set_literal( "WM_INITMENU" );

	break;


	case WM_INITMENUPOPUP :

		// [!] : this HIWORD( lparam ) will be n_posix_true when system menu

		if ( n_posix_false != HIWORD( lparam ) ) { break; }

		if ( hmenu == (HMENU) wparam )
		{
			n_win_menu_stop_onoff = n_posix_true;

			n_win_menu_popup_modify( hmenu, hwnd, menu, offset );
			menu->hmenu_prev = (HMENU) wparam;
		}

	break;


	case WM_EXITMENULOOP :

		if ( timer_id == 0 ) { timer_id = n_win_timer_id_get(); }
		n_win_timer_init( hwnd, timer_id, 200 );

	break;


	case WM_COMMAND :
	{
//n_win_hwndprintf_literal( hwnd, "%d %d", HIWORD( wparam ), LOWORD( wparam ), lparam );

		if (         lparam   != 0 ) { break; }
		if ( HIWORD( wparam ) != 0 ) { break; }


		if ( menu->hmenu_prev != hmenu ) { break; }

		menu->hmenu_prev = NULL;

		int index = LOWORD( wparam );

		return index;

	}
	break;


	} // switch


	return -1;
}


#endif // _H_NONNON_WIN32_WIN_MENU


/*

// [!] : you can use "@toybox/drop2compile.bat" to compile this debug code


#include "win.c"

#include "../project/macro.c"




#define n_win_menu_test_system_id_offset_main (   0 )
#define n_win_menu_test_system_id_offset_sub  ( 100 )

void
n_win_menu_test_system( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	static n_win_menu menu[] = {

		{ N_WIN_MENU_NONE,  n_posix_false, n_posix_false, n_posix_literal( "---"      ), n_win_menu_test_system_id_offset_main },
		{ N_WIN_MENU_RADIO, n_posix_true , n_posix_false, n_posix_literal( "Radio #1" ), n_win_menu_test_system_id_offset_main },
		{ N_WIN_MENU_RADIO, n_posix_false, n_posix_false, n_posix_literal( "Radio #2" ), n_win_menu_test_system_id_offset_main },
		{ N_WIN_MENU_NONE,  n_posix_false, n_posix_false, n_posix_literal( "---"      ), n_win_menu_test_system_id_offset_main },
		{ N_WIN_MENU_NONE,  n_posix_false, n_posix_false, n_posix_literal( "Push"     ), n_win_menu_test_system_id_offset_main },
		{ N_WIN_MENU_CHECK, n_posix_true , n_posix_false, n_posix_literal( "Checkbox" ), n_win_menu_test_system_id_offset_main },
		{ N_WIN_MENU_NONE,  n_posix_false, n_posix_false, n_posix_literal( "---"      ), n_win_menu_test_system_id_offset_main },
		{ N_WIN_MENU_NONE,  n_posix_false, n_posix_true , n_posix_literal( "Grayed"   ), n_win_menu_test_system_id_offset_main },
		{ N_WIN_MENU_NONE,  n_posix_false, n_posix_false, n_posix_literal( "---"      ), n_win_menu_test_system_id_offset_main },
		{ N_WIN_MENU_NONE,  n_posix_false, n_posix_false, n_posix_literal( "Sub Menu" ), n_win_menu_test_system_id_offset_main },
		{ N_WIN_MENU_NONE,  n_posix_false, n_posix_false, NULL }

	};


	// [x] : gcc : bug : you cannot use "const" variable as static variable initializer

	//const int n_win_menu_test_system_id_offset_sub = 100;

	static n_win_menu menu_sub[] = {

		{ N_WIN_MENU_NONE,  n_posix_false, n_posix_false, n_posix_literal( "Test #1"  ), n_win_menu_test_system_id_offset_sub },
		{ N_WIN_MENU_NONE,  n_posix_false, n_posix_false, n_posix_literal( "Test #2"  ), n_win_menu_test_system_id_offset_sub },
		{ N_WIN_MENU_NONE,  n_posix_false, n_posix_false, n_posix_literal( "---"      ), n_win_menu_test_system_id_offset_sub },
		{ N_WIN_MENU_CHECK, n_posix_true , n_posix_false, n_posix_literal( "Checkbox" ), n_win_menu_test_system_id_offset_sub },
		{ N_WIN_MENU_NONE,  n_posix_false, n_posix_false, NULL }

	};


	// [!] : for readability

	const int o_m = n_win_menu_test_system_id_offset_main;
	const int o_s = n_win_menu_test_system_id_offset_sub;


	// [!] : submenu

	static n_posix_bool hmenu_sub_onoff = n_posix_false;

	if ( hmenu_sub_onoff == n_posix_false )
	{
		hmenu_sub_onoff     = n_posix_true;
		menu[ 9 ].hmenu_sub = n_win_menu_popup_hmenu_init();

		n_win_menu_popup_init( menu[ 9 ].hmenu_sub, hwnd, menu_sub, 0 );
	}


	const int menu_offset = 5;
	int ret = n_win_menu_system_proc( hwnd, msg, wparam, lparam, menu, menu_offset );

	if (
		(
			( ret >= ( o_m + 0 ) )
			&&
			( ret <= ( o_m + 9 ) )
		)
		||
		(
			( ret >= ( o_s + 0 ) )
			&&
			( ret <= ( o_s + 3 ) )
		)
	)
	{

		// [!] : debug output

		n_posix_char str[ 1024 ];

		if ( ret <= ( o_m + 9 ) )
		{
			n_posix_sprintf_literal( str, "%s", menu    [ ret - o_m ].string );
		} else {
			n_posix_sprintf_literal( str, "%s", menu_sub[ ret - o_s ].string );
		}

		n_win_hwndprintf_literal( hwnd, "Changed : %s", str );


		// [!] : checkbox-like behavior

		if ( ret == ( o_m + 5 ) )
		{
			n_win_menu_checkbox( menu, ret - o_m );
			//n_win_menu_system_modify( hwnd, menu, menu_offset );
		} else
		if ( ret == ( o_s + 3 ) )
		{
			n_win_menu_checkbox( menu_sub, ret - o_s );
			n_win_menu_popup_modify( menu[ 9 ].hmenu_sub, hwnd, menu_sub, 0 );
		}


		// [!] : radiobutton-like behavior

		if (
			( ret >= ( o_m + 1 ) )
			&&
			( ret <= ( o_m + 2 ) )
		)
		{
			n_win_menu_radiobutton( menu, ret - o_m, 1, 2 );
			//n_win_menu_system_modify( hwnd, menu, menu_offset );
		}

	}


	return;
}

#define n_win_menu_test_popup_id_offset_main ( 200 )
#define n_win_menu_test_popup_id_offset_sub  ( 300 )

void
n_win_menu_test_popup( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam, HMENU hmenu )
{

	static n_win_menu menu[] = {

		{ N_WIN_MENU_NONE,  n_posix_false, n_posix_false, n_posix_literal( "---"      ), n_win_menu_test_popup_id_offset_main },
		{ N_WIN_MENU_RADIO, n_posix_true , n_posix_false, n_posix_literal( "Radio #1" ), n_win_menu_test_popup_id_offset_main },
		{ N_WIN_MENU_RADIO, n_posix_false, n_posix_false, n_posix_literal( "Radio #2" ), n_win_menu_test_popup_id_offset_main },
		{ N_WIN_MENU_NONE,  n_posix_false, n_posix_false, n_posix_literal( "---"      ), n_win_menu_test_popup_id_offset_main },
		{ N_WIN_MENU_NONE,  n_posix_false, n_posix_false, n_posix_literal( "Push"     ), n_win_menu_test_popup_id_offset_main },
		{ N_WIN_MENU_CHECK, n_posix_true , n_posix_false, n_posix_literal( "Checkbox" ), n_win_menu_test_popup_id_offset_main },
		{ N_WIN_MENU_NONE,  n_posix_false, n_posix_false, n_posix_literal( "---"      ), n_win_menu_test_popup_id_offset_main },
		{ N_WIN_MENU_NONE,  n_posix_false, n_posix_true , n_posix_literal( "Grayed"   ), n_win_menu_test_popup_id_offset_main },
		{ N_WIN_MENU_NONE,  n_posix_false, n_posix_false, n_posix_literal( "---"      ), n_win_menu_test_popup_id_offset_main },
		{ N_WIN_MENU_NONE,  n_posix_false, n_posix_false, n_posix_literal( "Sub Menu" ), n_win_menu_test_popup_id_offset_main },
		{ N_WIN_MENU_NONE,  n_posix_false, n_posix_false, NULL }

	};


	// [x] : gcc : bug : you cannot use "const" variable as static variable initializer

	//const int n_win_menu_test_popup_id_offset_sub = 300;

	static n_win_menu menu_sub[] = {

		{ N_WIN_MENU_NONE,  n_posix_false, n_posix_false, n_posix_literal( "Test #1"  ), n_win_menu_test_popup_id_offset_sub },
		{ N_WIN_MENU_NONE,  n_posix_false, n_posix_false, n_posix_literal( "Test #2"  ), n_win_menu_test_popup_id_offset_sub },
		{ N_WIN_MENU_NONE,  n_posix_false, n_posix_false, n_posix_literal( "---"      ), n_win_menu_test_popup_id_offset_sub },
		{ N_WIN_MENU_CHECK, n_posix_true , n_posix_false, n_posix_literal( "Checkbox" ), n_win_menu_test_popup_id_offset_sub },
		{ N_WIN_MENU_NONE,  n_posix_false, n_posix_false, NULL }

	};


	// [!] : for readability

	const int o_m = n_win_menu_test_popup_id_offset_main;
	const int o_s = n_win_menu_test_popup_id_offset_sub;


	// [!] : submenu

	static n_posix_bool hmenu_sub_onoff = n_posix_false;

	if ( hmenu_sub_onoff == n_posix_false )
	{
		hmenu_sub_onoff     = n_posix_true;
		menu[ 9 ].hmenu_sub = n_win_menu_popup_hmenu_init();

		n_win_menu_popup_init( menu[ 9 ].hmenu_sub, hwnd, menu_sub, 0 );
	}


	const int menu_offset = 0;
	int ret = n_win_menu_popup_proc( hwnd, msg, wparam, lparam, hmenu, menu, menu_offset );

	if (
		(
			( ret >= ( o_m + 0 ) )
			&&
			( ret <= ( o_m + 9 ) )
		)
		||
		(
			( ret >= ( o_s + 0 ) )
			&&
			( ret <= ( o_s + 3 ) )
		)
	)
	{

		// [!] : debug output

		n_posix_char str[ 1024 ];

		if ( ret <= ( o_m + 9 ) )
		{
			n_posix_sprintf_literal( str, "%s", menu    [ ret - o_m ].string );
		} else {
			n_posix_sprintf_literal( str, "%s", menu_sub[ ret - o_s ].string );
		}

		n_win_hwndprintf_literal( hwnd, "Changed : %s", str );


		// [!] : checkbox-like behavior

		if ( ret == ( o_m + 5 ) )
		{
			n_win_menu_checkbox( menu, ret - o_m );
			//n_win_menu_popup_modify( hmenu, hwnd, menu, menu_offset );
		} else
		if ( ret == ( o_s + 3 ) )
		{
			n_win_menu_checkbox( menu_sub, ret - o_s );
			n_win_menu_popup_modify( menu[ 9 ].hmenu_sub, hwnd, menu_sub, 0 );
		}


		// [!] : radiobutton-like behavior

		if (
			( ret >= ( o_m + 1 ) )
			&&
			( ret <= ( o_m + 2 ) )
		)
		{
			n_win_menu_radiobutton( menu, ret - o_m, 1, 2 );
			//n_win_menu_popup_modify( hmenu, hwnd, menu, menu_offset );
		}

	}


	return;
}

LRESULT CALLBACK
WndProc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	static HMENU hmenu;


	switch( msg ) {


	case WM_CREATE :

		n_win_init_literal( hwnd, "Nonnon Menu Test", "", "" );

		n_win_style_new( hwnd, WS_OVERLAPPEDWINDOW );


		hmenu = n_win_menu_popup_hmenu_init();


		n_win_set( hwnd, NULL, 512,512, N_WIN_SET_CENTERING );


		ShowWindow( hwnd, SW_NORMAL );

	break;


	case WM_RBUTTONDOWN :

		n_win_menu_popup_show( hmenu, hwnd );

	break;


	case WM_KEYDOWN :

		if ( wparam == VK_ESCAPE )
		{
			n_win_menu_system_reset( hwnd );
		}

	break;


	case WM_CLOSE :

		n_win_menu_popup_hmenu_exit( hmenu );

		ShowWindow( hwnd, SW_HIDE );

		DestroyWindow( hwnd );

	break;

	case WM_DESTROY :

		PostQuitMessage( 0 );

	break;


	} // switch


	n_win_menu_test_system( hwnd, msg, wparam, lparam );
	n_win_menu_test_popup ( hwnd, msg, wparam, lparam, hmenu );


	return DefWindowProc( hwnd, msg, wparam, lparam );
}

int WINAPI
WinMain( HINSTANCE hinst, HINSTANCE prv_hinst, LPSTR cmd, int show )
{
	return n_win_main( NULL, WndProc );
}


*/

