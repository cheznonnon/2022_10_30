// Nonnon Nyaurism
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#include "../nonnon/neutral/wav.c"
#include "../nonnon/neutral/wav/all.c"

#include "../nonnon/win32/win.c"
#include "../nonnon/win32/win_button.c"
#include "../nonnon/win32/win_combobox.c"
#include "../nonnon/win32/win_groupbox.c"
#include "../nonnon/win32/win_inputpopup.c"
#include "../nonnon/win32/win_separator.c"


#include "../nonnon/project/macro.c"




#define H_GROUP   n_nyaurism_resizer_hgui[ 0 ]
#define H_LABEL   n_nyaurism_resizer_hgui[ 1 ]
#define GUI_MAX                            2

#define H_OK      n_nyaurism_resizer_hbtn[ 0 ]
#define H_CANCEL  n_nyaurism_resizer_hbtn[ 1 ]
#define BTN_MAX                            2

#define H_INPUT   n_nyaurism_resizer_input
#define H_COMBO   n_nyaurism_resizer_combo


#define MSG_TITLE    n_posix_literal( " Resizer " )
#define MSG_MSEC     n_posix_literal( "Msec"      )
#define MSG_NORMAL   n_posix_literal( "Normal"    )
#define MSG_CENTER   n_posix_literal( "Center"    )
#define MSG_RESAMPLE n_posix_literal( "Resample"  )


static HWND   n_nyaurism_resizer_hgui[ GUI_MAX ];
static n_bool n_nyaurism_resizer_onoff = n_false;

static n_win_button n_nyaurism_resizer_hbtn[ BTN_MAX ];
static n_win_txtbox n_nyaurism_resizer_input;
static n_win_combo  n_nyaurism_resizer_combo;




void
n_nyaurism_resizer_resize( HWND hwnd )
{

	const n_bool redraw = n_true;


	n_type_gfx ctl,ico,m;
	n_win_stdsize( hwnd, &ctl, &ico, &m );


	n_win w; n_win_set( hwnd, &w, -1,-1, N_WIN_SET_CALCONLY );

	n_type_gfx  unit_x = n_posix_min_n_type_gfx( w.csx / 2, ico * 4 );
	n_type_gfx  unit_y = ctl * 6;

	n_type_gfx start_x = ( w.csx - unit_x ) / 2;
	n_type_gfx start_y = ( w.csy - unit_y ) / 2;

	{

		n_type_gfx  x = start_x - ( ico * 1 );
		n_type_gfx  y = start_y;
		n_type_gfx sx =  unit_x + ( ico * 2 );
		n_type_gfx sy =  unit_y;

		n_win_move( H_GROUP, x,y,sx,sy, redraw );

	}

	{

		n_type_gfx half_x = unit_x / 2;
		n_type_gfx cmb_sx = unit_x;

		n_type_gfx x = start_x;
		n_type_gfx y = start_y + ctl;

		n_win_move       (  H_LABEL , x,y, half_x,ctl, redraw ); x += half_x;
		n_win_txtbox_move( &H_INPUT , x,y, half_x,ctl, redraw ); x = start_x; y += ctl;
		n_win_combo_move ( &H_COMBO , x,y, cmb_sx,  3, redraw ); x = start_x; y += ctl;
		y += ctl;
		n_win_button_move( &H_OK    , x,y, half_x,ctl, redraw ); x += half_x + 1;
		n_win_button_move( &H_CANCEL, x,y, half_x,ctl, redraw );

	}


	return;
}

void
n_nyaurism_resizer_show
(
	HWND            hwnd,
	HWND           *hgui, int gui_max,
	n_win_button   *hbtn, int btn_max,
	n_win_scroller *hscr, int scr_max
)
{

	ShowWindow( n_nyaurism_list.hwnd, SW_HIDE );

	ShowWindow( H_OK    .hwnd, SW_HIDE );
	ShowWindow( H_CANCEL.hwnd, SW_HIDE );

	int i = 0;
	n_posix_loop
	{

		ShowWindow( hgui[ i ], SW_HIDE );

		i++;
		if ( i >= gui_max ) { break; }
	}

	i = 0;
	n_posix_loop
	{

		ShowWindow( hbtn[ i ].hwnd, SW_HIDE );

		i++;
		if ( i >= btn_max ) { break; }
	}

	i = 0;
	n_posix_loop
	{

		nwscr_show( &hscr[ i ], SW_HIDE );

		i++;
		if ( i >= scr_max ) { break; }
	}


	n_nyaurism_resizer_onoff = n_true;


	// [!] : groupbox needs to be initialized last

	n_win_gui( hwnd, LABEL, MSG_MSEC, &H_LABEL );

	n_win_button_init_literal( &H_OK    , hwnd, "OK"    , PBS_NORMAL ); H_OK.default_onoff = n_true;
	n_win_button_init_literal( &H_CANCEL, hwnd, "Cancel", PBS_NORMAL );

	n_win_combo_zero( &H_COMBO );
	n_win_combo_init( &H_COMBO, hwnd );

	{
		int style  = 0;

		style |= N_WIN_TXTBOX_STYLE_ONELINE;

		int option = 0;

		option |= N_WIN_TXTBOX_OPTION_ONELINE_HCENTER;
		option |= N_WIN_TXTBOX_OPTION_ONELINE_DIGITAL;
		option |= N_WIN_TXTBOX_OPTION_COMBOBOX_NOGRAY;

		n_win_txtbox_zero( &H_INPUT );
		n_win_txtbox_init( &H_INPUT, hwnd, style, option );

		n_win_property_init_literal( H_INPUT.hwnd, "Number", n_true );
	}

	{
		n_posix_char str[ N_STRING_INT2STR_CCH_MAX ]; n_string_int2str( str, N_WAV_MSEC( &n_nyaurism_wav ) );

		n_win_txtbox_selection_mod( &H_INPUT, str );
		n_win_txtbox_select_tail_set( &H_INPUT );
	}

	n_win_gui( hwnd, CANVAS, MSG_TITLE, &H_GROUP );


	n_win_flickerfree_win_iconbutton_init( H_OK    .hwnd );
	n_win_flickerfree_win_iconbutton_init( H_CANCEL.hwnd );


	n_txt_set( &H_COMBO.txt, 0, MSG_NORMAL   );
	n_txt_set( &H_COMBO.txt, 1, MSG_CENTER   );
	n_txt_set( &H_COMBO.txt, 2, MSG_RESAMPLE );

	n_win_combo_selection_set_by_string( &H_COMBO, MSG_NORMAL );


	n_win_stdfont_init( n_nyaurism_resizer_hgui, GUI_MAX );


	n_nyaurism_resizer_resize( hwnd );


	return;
}

void
n_nyaurism_resizer_hide
(
	HWND            hwnd,
	HWND           *hgui, int gui_max,
	n_win_button   *hbtn, int btn_max,
	n_win_scroller *hscr, int scr_max
)
{

	n_win_inputpopup_close();


	n_win_stdfont_exit( n_nyaurism_resizer_hgui, GUI_MAX );


	n_win_flickerfree_win_iconbutton_exit( H_OK    .hwnd );
	n_win_flickerfree_win_iconbutton_exit( H_CANCEL.hwnd );

	n_win_button_exit( &H_OK     );
	n_win_button_exit( &H_CANCEL );


	n_win_combo_silent = n_true;
	n_win_combo_exit( &H_COMBO );

	n_win_txtbox_exit( &H_INPUT );

	DestroyWindow( H_LABEL );
	DestroyWindow( H_GROUP );


	n_nyaurism_resizer_onoff = n_false;


	ShowWindow( n_nyaurism_list.hwnd, SW_SHOW );

	int i = 0;
	n_posix_loop
	{

		ShowWindow( hgui[ i ], SW_SHOW );

		i++;
		if ( i >= gui_max ) { break; }
	}

	i = 0;
	n_posix_loop
	{

		ShowWindow( hbtn[ i ].hwnd, SW_SHOW );

		i++;
		if ( i >= btn_max ) { break; }
	}

	i = 0;
	n_posix_loop
	{

		nwscr_show( &hscr[ i ], SW_SHOW );

		i++;
		if ( i >= scr_max ) { break; }
	}


	n_win_refresh( hwnd, n_true );


	return;
}

// internal
void
n_nyaurism_resizer_go( HWND hwnd )
{

	n_posix_char str[ N_PATH_MAX ];

	n_win_txtbox_selection_get( &H_INPUT, str );
	u32 msec = n_posix_atoi( str );


	n_posix_char *str_combo = n_win_combo_selection_get( &H_COMBO );

	int option = N_WAV_RESIZER_NORMAL;

	if ( n_string_is_same( MSG_NORMAL  , str_combo ) )
	{
		option = N_WAV_RESIZER_NORMAL;
	} else
	if ( n_string_is_same( MSG_CENTER  , str_combo ) )
	{
		option = N_WAV_RESIZER_CENTER;
	} else
	if ( n_string_is_same( MSG_RESAMPLE, str_combo ) )
	{
		option = N_WAV_RESIZER_RESAMPLE;
	}// else

	n_wav_resizer( &n_nyaurism_wav, msec, option );


	return;
}

LRESULT CALLBACK
n_nyaurism_resizer_wndproc
(
	HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam,
	HWND           *hgui, int gui_max,
	n_win_button   *hbtn, int btn_max,
	n_win_scroller *hscr, int scr_max
)
{

	static UINT timer_id = 0;


	switch( msg ) {


	case WM_SETTINGCHANGE :

		// [!] : XP or later : this message is sent many times

		// [!] : Win8.1 : SPI_SETNONCLIENTMETRICS will never come

		if ( timer_id == 0 ) { timer_id = n_win_timer_id_get(); }
		n_win_timer_init( hwnd, timer_id, n_project_settingchange_interval() );

	break;


	case WM_TIMER :

		// [!] : Win95 needs to check WPARAM is ID or not

		if ( wparam == 0 ) { break; }

		if ( wparam != timer_id ) { break; }
		n_win_timer_exit( hwnd, timer_id );


		n_project_darkmode();

		n_win_init_background( hwnd );
		n_win_refresh( hwnd, n_true );

		n_win_stdfont_init( n_nyaurism_formatter_hgui, GUI_MAX );

		n_win_button_on_settingchange( &H_OK     );
		n_win_button_on_settingchange( &H_CANCEL );

		n_win_combo_on_settingchange( &H_COMBO );

		n_win_txtbox_on_settingchange( &H_INPUT );

	break;


	case WM_SIZE :

		n_nyaurism_resizer_resize( hwnd );

	break;


	case WM_NCLBUTTONDOWN :
	case WM_LBUTTONDOWN   :

		//if ( H_INPUT.hwnd != GetFocus() )
		{
			n_win_inputpopup_close();
		}

	break;


	case WM_COMMAND :
	{

		HWND h = (HWND) lparam;


		if ( h == H_INPUT.hwnd )
		{

			if ( wparam == WM_SETFOCUS )
			{
				n_win_inputpopup_open_txtbox( hwnd, &H_INPUT );
			}

		} else
		if ( h == H_OK.hwnd )
		{

			n_nyaurism_resizer_go( hwnd );

			n_nyaurism_resizer_hide( hwnd, hgui, gui_max, hbtn, btn_max, hscr, scr_max );

		} else
		if ( h == H_CANCEL.hwnd )
		{

			n_nyaurism_resizer_hide( hwnd, hgui, gui_max, hbtn, btn_max, hscr, scr_max );

		}

	}
	break;


	} // switch


	n_win_group_proc( hwnd, msg, wparam, lparam, H_GROUP );

	{
		int ret = n_win_txtbox_proc( hwnd, msg, wparam, lparam, &H_INPUT );
		if ( ret ) { return ret; }
	}

	n_win_combo_proc( hwnd, msg, &wparam, &lparam, &H_COMBO );

	n_win_button_proc( hwnd, msg, wparam, lparam, &H_OK     );
	n_win_button_proc( hwnd, msg, wparam, lparam, &H_CANCEL );

	//n_win_inputpopup_proc_txtbox( hwnd, msg, wparam, lparam, &H_INPUT );
	n_win_inputpopup_patch( hwnd, msg, &wparam, &lparam );


	return DefWindowProc( hwnd, msg, wparam, lparam );
}


#undef H_GROUP
#undef H_LABEL
#undef GUI_MAX

#undef H_OK
#undef H_CANCEL
#undef BTN_MAX

#undef H_INPUT
#undef H_COMBO

#undef MSG_TITLE
#undef MSG_NORMAL
#undef MSG_CENTER
#undef MSG_RESAMPLE

