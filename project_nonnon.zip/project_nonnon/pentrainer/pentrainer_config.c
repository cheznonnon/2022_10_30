// CatPad
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#include "../nonnon/win32/win.c"
#include "../nonnon/win32/win_button.c"
#include "../nonnon/win32/win_combobox.c"
#include "../nonnon/win32/win_separator.c"
#include "../nonnon/win32/win_txtbox.c"

#include "../nonnon/project/macro.c"




#define H_LINE_1     n_pentrainer_config_hgui[ 0 ]
#define H_LINE_2     n_pentrainer_config_hgui[ 1 ]
#define H_PREVIEW    n_pentrainer_config_hgui[ 2 ]
#define H_LIST       n_pentrainer_config_hgui[ 3 ]
#define GUI_MAX                                4

#define H_BUTTON_GO  n_pentrainer_config_hbtn




// internal

static HWND         n_pentrainer_config_hgui[ GUI_MAX ];
static n_win_button n_pentrainer_config_hbtn;
static n_win_txtbox n_pentrainer_config_htxt;
static n_win_combo  n_pentrainer_config_combo;
static n_type_int   n_pentrainer_config_sel_prv;
static WNDPROC      n_pentrainer_flickerfree_func;




void
n_pentrainer_config_preview_refresh( void )
{

	n_win_refresh( H_PREVIEW, n_false );


	return;
}

// internal
int CALLBACK
n_pentrainer_config_enumfontsproc( const LOGFONT *lf, const TEXTMETRIC *tm, u32 type, LPARAM lparam )
{

	//const int mask = 15;


	if (
		( type != DEVICE_FONTTYPE )
		&&
		( lf->lfCharSet != SYMBOL_CHARSET )
		&&
		( lf->lfCharSet != OEM_CHARSET    )
		&&
		( lf->lfFaceName[ 0 ] != n_posix_literal( '@' ) )
/*
		&&
		(
			( lf->lfCharSet == ANSI_CHARSET )
			||
			( (  932 == GetACP() )&&( lf->lfCharSet == SHIFTJIS_CHARSET ) )
			||
			( ( 1251 == GetACP() )&&( lf->lfCharSet == RUSSIAN_CHARSET  ) )
			||
			( ( 1253 == GetACP() )&&( lf->lfCharSet == GREEK_CHARSET    ) )
		)
*/
	)
	{

		n_posix_char str[ 100 ];
		n_posix_sprintf_literal( str, "%s", lf->lfFaceName );
		//n_posix_sprintf_literal( str, "%d : %s", lf->lfCharSet, lf->lfFaceName );

		n_win_txtbox_line_add( &n_pentrainer_config_htxt, 0, str );

	}


	return n_true;
}

void
n_pentrainer_config_init( HWND hwnd )
{
//n_win_hwndprintf_literal( hwnd, "%s", n_pentrainer_font );

	HDC hdc = GetDC( hwnd );

	EnumFonts( hdc, NULL, n_pentrainer_config_enumfontsproc, (LPARAM) 0 );

	ReleaseDC( hwnd, hdc );


	n_txt_sort_up( &n_pentrainer_config_htxt.txt    );
	n_txt_del    ( &n_pentrainer_config_htxt.txt, 0 );


	// [!] : when a font is not exist : a second call will fail

	n_win_txtbox_str2index( &n_pentrainer_config_htxt, n_posix_literal( "FixedSys" ), n_true );
	n_win_txtbox_str2index( &n_pentrainer_config_htxt, n_pentrainer_font            , n_true );

	n_pentrainer_config_preview_refresh();


	return;
}

void
n_pentrainer_config_exit( void )
{

	n_win_txtbox_selection_get( &n_pentrainer_config_htxt, n_pentrainer_font );

	n_posix_sprintf_literal( n_pentrainer_mode, "%s", n_win_combo_selection_get( &n_pentrainer_config_combo ) );

	n_pentrainer_character_min( n_pentrainer_mode, n_pentrainer_char );
	n_pentrainer_character_move( 0 );
	n_pentrainer_bitmap();


	return;
}

void
n_pentrainer_config_resize( HWND hwnd, n_bool is_first )
{

	int        nwset;
	n_type_gfx csx,csy;

	if ( is_first )
	{

		nwset = N_WIN_SET_CENTERING;

		n_win_desktop_size( &csx, &csy );

		csx = csy = (n_type_gfx) n_posix_max_n_type_real( 256, (n_type_real) n_posix_min( csx, csy ) * 0.4 );

	} else {

		nwset = n_project_n_win_set();

		csx   = -1;
		csy   = -1;

	}


	n_type_gfx ctl,m; n_win_stdsize( hwnd, &ctl, NULL, &m );

	n_type_gfx pad = m;

	n_win w; n_win_set( hwnd, &w, csx,csy, nwset );

	csx = w.csx - ( pad * 2 );
	csy = w.csy - ( pad * 2 );


	const n_bool redraw = n_true;


	n_type_gfx x = pad;
	n_type_gfx y = pad;

	n_type_gfx psy = ( ctl * 2 );
	n_type_gfx lsy = csy - ( ctl + ctl + ctl + psy + ctl );
	n_type_gfx b_x = x; x++;
	n_type_gfx bsx = csx; csx -= 2;
	n_type_gfx c   = (n_type_gfx) n_pentrainer_config_combo.txt.sy;

	n_pentrainer_config_preview_refresh();

	n_win_move       (  H_LINE_1                 ,   x,y, csx,ctl, redraw ); y += ctl;
	n_win_combo_move ( &n_pentrainer_config_combo,   x,y, csx,  c, redraw ); y += ctl;
	n_win_move       (  H_LINE_2                 ,   x,y, csx,ctl, redraw ); y += ctl;
	n_win_move       (  H_PREVIEW                ,   x,y, csx,psy, redraw ); y += psy;
	n_win_move       (  H_LIST                   ,   x,y, csx,lsy, redraw ); y += lsy;
	n_win_button_move( &H_BUTTON_GO              , b_x,y, bsx,ctl, redraw );


	return;
}

void
n_pentrainer_config_preview( void )
{
//n_win_text_set( H_PREVIEW, n_posix_literal( "Jumped Over A Sleepy Cat." ) ); return;


	if ( n_pentrainer_config_sel_prv == n_pentrainer_config_combo.selection_index ) { return; }
	n_pentrainer_config_sel_prv = n_pentrainer_config_combo.selection_index;


	n_posix_char mode[ 100 ]; n_posix_sprintf_literal( mode, "%s", n_win_combo_selection_get( &n_pentrainer_config_combo ) );
	n_posix_char from[ 100 ]; n_string_zero( from, 100 ); n_pentrainer_character_min( mode, from );
	n_posix_char  str[ 100 ]; n_string_zero(  str, 100 );


	n_bool is_dbcs = ( 2 == n_posix_strlen( from ) );

	n_bool is_kana = 
	(
		( n_string_is_same( mode, N_PENTRAINER_HIRAGANA ) )
		||
		( n_string_is_same( mode, N_PENTRAINER_KATAKANA ) )
	);


	// [!] : Kana : skip algorithm is too much difficult
	int maxim = 10;


	int step = 1;
	if ( is_kana )
	{
		if ( is_dbcs ) { from[ 1 ] += 1; } else { from[ 0 ] += 1; }

		step  = 2;
		maxim = 5;
	}


	int i = 0;
	int j = 0;
	int k = 0;
	n_posix_loop
	{//break;

		if ( is_dbcs )
		{
			str[ i + 0 ] = from[ 0 ];
			str[ i + 1 ] = from[ 1 ] + k;

			i += 2;
		} else {
			str[ i + 0 ] = from[ 0 ] + k;

			i += 1;
		}

		k += step;

		j++;
		if ( j >= maxim ) { break; }
	}

	n_win_text_set( H_PREVIEW, str );


	n_pentrainer_config_preview_refresh();


	return;
}

void
n_pentrainer_config_on_settingchange( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	static UINT timer_id = 0;


	switch( msg ) {


	case WM_SETTINGCHANGE :

		// [!] : XP or later : this message is sent many times

		// [!] : Win8.1 : SPI_SETNONCLIENTMETRICS will never come

		if ( timer_id == 0 ) { timer_id = n_win_timer_id_get(); }

		n_win_timer_init( hwnd, timer_id, n_project_settingchange_interval() );

	break;


	case WM_TIMER :

		// [!] : Win95 needs to check WPARAM is ID or not

		if ( wparam == 0 ) { break; }

		if ( wparam != timer_id ) { break; }


		n_win_timer_exit( hwnd, timer_id );


		n_project_darkmode();

		n_win_init_background( hwnd );
		n_win_refresh( hwnd, n_true );

		n_win_combo_on_settingchange( &n_pentrainer_config_combo );

		n_win_button_on_settingchange( &H_BUTTON_GO );

		n_win_stdfont_init( n_pentrainer_config_hgui, GUI_MAX );

		n_pentrainer_config_resize( hwnd, n_false );

	break;


	} // switch


}

LRESULT CALLBACK
n_pentrainer_config_wndproc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	n_pentrainer_config_on_settingchange( hwnd, msg, wparam, lparam );


	switch( msg ) {


	case WM_CREATE :


		// Global

		n_win_ime_disable( hwnd );

		n_pentrainer_config_sel_prv = -1;

		n_win_button_zero( &H_BUTTON_GO );


		// Window

		n_win_init_literal( hwnd, "Config", "", "" );

		n_win_gui_literal( hwnd, CANVAS,  "", &H_LINE_1     );
		n_win_gui_literal( hwnd, CANVAS,  "", &H_LINE_2     );
		n_win_gui_literal( hwnd, CANVAS,  "", &H_PREVIEW    );

		n_win_button_init( &H_BUTTON_GO, hwnd, n_project_string_go, PBS_NORMAL );

		n_win_combo_zero( &n_pentrainer_config_combo );
		n_win_combo_init( &n_pentrainer_config_combo, hwnd );

		{

			int style = 0;

			style = style | N_WIN_TXTBOX_STYLE_LISTBOX;
			style = style | N_WIN_TXTBOX_STYLE_VSCROLL;
			style = style | N_WIN_TXTBOX_STYLE_STRIPED;

			int style_option = 0;

			style_option = style_option | N_WIN_TXTBOX_OPTION_LISTBOX_KEEPSEL;

			if ( n_win_fluent_ui_onoff )
			{
				style_option = style_option | N_WIN_TXTBOX_OPTION_LISTBOX_ROUNDRC;
			}

			n_win_txtbox_zero( &n_pentrainer_config_htxt );
			n_win_txtbox_init( &n_pentrainer_config_htxt, hwnd, style, style_option );

			H_LIST = n_pentrainer_config_htxt.hwnd;
		}


		n_win_text_set( H_LINE_1, n_posix_literal( "Mode" ) );
		n_win_text_set( H_LINE_2, n_posix_literal( "Font" ) );


		// Style

		// [!] : WinXP/Luna : need to set WS_EX_DLGMODALFRAME before WS_*

		n_win_exstyle_new( hwnd, WS_EX_DLGMODALFRAME           );
		n_win_style_new  ( hwnd, N_WS_POPUPWINDOW | WS_SIZEBOX );

		n_win_sysmenu_disable( hwnd, 1,0,0, 1,1, 0, 0 );


		n_win_stdfont_init( n_pentrainer_config_hgui, GUI_MAX );


		n_txt_set( &n_pentrainer_config_combo.txt, 0, N_PENTRAINER_DIGIT );
		n_txt_set( &n_pentrainer_config_combo.txt, 1, N_PENTRAINER_ROMAN );

//n_posix_debug_literal( "%d", GetACP() );

#ifndef UNICODE
		if (  932 == GetACP() )
#endif // #ifndef UNICODE
		{
			n_txt_set( &n_pentrainer_config_combo.txt, 2, N_PENTRAINER_HIRAGANA );
			n_txt_set( &n_pentrainer_config_combo.txt, 3, N_PENTRAINER_KATAKANA );
		}

#ifndef UNICODE
		if ( 1251 == GetACP() )
#endif // #ifndef UNICODE
		{
			n_txt_set( &n_pentrainer_config_combo.txt, 4, N_PENTRAINER_CYRILLIC );
		}

#ifndef UNICODE
		if ( 1253 == GetACP() )
#endif // #ifndef UNICODE
		{
			n_txt_set( &n_pentrainer_config_combo.txt, 5, N_PENTRAINER_GREEK );
		}

		n_win_combo_selection_set_by_string( &n_pentrainer_config_combo, n_pentrainer_mode );


		// [!] : after combo init
		n_pentrainer_config_preview();


		n_win_flickerfree_init( hwnd, &n_pentrainer_flickerfree_func );
		n_win_flickerfree_win_iconbutton_init( H_BUTTON_GO.hwnd );


		// Init

		n_pentrainer_config_init( hwnd );
		n_pentrainer_config_resize( hwnd, n_true );

		n_win_txtbox_autofocus( &n_pentrainer_config_htxt, n_true );


		// Display

		ShowWindow( hwnd, SW_NORMAL );

		EnableWindow( GetParent( hwnd ), n_false );

	break;


	case WM_DRAWITEM :
	{

		DRAWITEMSTRUCT *di = (void*) lparam;
		if ( di == NULL ) { break; }
		if ( H_PREVIEW != di->hwndItem ) { break; }

//n_win_scrollbar_debug_count( &n_pentrainer_config_htxt.vscr );


		HWND hgui = H_PREVIEW;
		RECT rect = di->rcItem;

		n_posix_char fontname[ LF_FACESIZE ];
		n_win_txtbox_selection_get( &n_pentrainer_config_htxt, fontname );

		n_type_gfx x,y,sx,sy; n_win_rect_expand_size( &rect, &x, &y, &sx, &sy );

		n_win_fluent_ui_label( hgui, &rect, fontname, sy );

	}
	break;


	case WM_SIZE :

		n_pentrainer_config_resize( hwnd, n_false );

	break;


	case WM_COMMAND :
	{

		HWND h = (HWND) lparam;


		if ( h == H_LIST )
		{

			if (
				( wparam == WM_LBUTTONDOWN )
				||
				( wparam == WM_MBUTTONDOWN )
				||
				( wparam == WM_RBUTTONDOWN )
			)
			{
				n_pentrainer_config_preview_refresh();
			}

		} else
		if ( h == n_pentrainer_config_combo.input.hwnd )
		{
//n_win_hwndprintf_literal( hwnd, "%d", wparam );

			if ( wparam == n_pentrainer_config_combo.wparam_selection_changed )
			{
				n_pentrainer_config_preview();
			}

		} else
		if ( h == H_BUTTON_GO.hwnd )
		{

			n_pentrainer_config_exit();

			n_win_message_send( hwnd, WM_CLOSE, 0,0 );

		}

	}
	break;


	case WM_LBUTTONDOWN :

		SetFocus( n_pentrainer_config_htxt.hwnd );

	break;


	case WM_CLOSE :

		EnableWindow( GetParent( hwnd ), n_true );
		ShowWindow( hwnd, SW_HIDE );


		n_win_combo_silent = n_true;
		n_win_combo_exit( &n_pentrainer_config_combo );


		n_win_button_exit( &H_BUTTON_GO );


		n_win_flickerfree_exit( hwnd, &n_pentrainer_flickerfree_func );
		n_win_flickerfree_win_iconbutton_exit( H_BUTTON_GO.hwnd );


		n_win_stdfont_exit( n_pentrainer_config_hgui, GUI_MAX );

		n_win_txtbox_exit( &n_pentrainer_config_htxt );


		DestroyWindow( hwnd );

	break;

	case WM_DESTROY :

		//PostQuitMessage( 0 );

	break;


	} // switch


	n_win_separator_proc( hwnd, msg, wparam, lparam, H_LINE_1, PS_SOLID );
	n_win_separator_proc( hwnd, msg, wparam, lparam, H_LINE_2, PS_SOLID );


	n_win_combo_proc( hwnd, msg, &wparam, &lparam, &n_pentrainer_config_combo );


	n_win_button_proc( hwnd, msg, wparam, lparam, &H_BUTTON_GO );


	n_win_txtbox_proc( hwnd, msg, wparam, lparam, &n_pentrainer_config_htxt );


	return DefWindowProc( hwnd, msg, wparam, lparam );
}


#undef H_LINE_1
#undef H_LINE_2
#undef H_PREVIEW
#undef H_LIST
#undef GUI_MAX

#undef H_BUTTON_GO


