// Nonnon Pen Trainer
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Partial File




inline u32
n_pentrainer_pixelgrid_pixel( u32 color )
{

	color = n_bmp_argb2ahsl( color );

	int a = n_bmp_a( color );
	int h = n_bmp_h( color ) + 128;
	int s = n_bmp_s( color ) + 128;
	int l = n_bmp_l( color ) + 128;

	color = n_bmp_ahsl2argb( n_bmp_argb( a,h,s,l ) );


	return color;
}

void
n_pentrainer_refresh( n_type_gfx fx, n_type_gfx fy, n_type_gfx tx, n_type_gfx ty, int mode )
{

	// Debug Center

	const n_bool debug_counter    = n_false;
	const n_bool debug_benchmark  = n_false;
	const n_bool background_onoff = n_true;
	const n_bool n_gdi_draw_onoff = n_true;

	u32 tick = 0;


	// [Needed] : reduce number of accesses at startup

	if ( n_false == IsWindow( n_pentrainer_hwnd_main ) ) { return; }
	if (    NULL == N_BMP_PTR( &n_pentrainer_bmp_data ) ) { return; }

	if ( debug_counter )
	{

		static int w = 0;
		static int c = 0;

		n_win_hwndprintf_literal( n_pentrainer_hwnd_main, "Window %d : Client %d", w, c );

		if ( mode & N_PENTRAINER_REFRESH_WINDOW ) { w++; }
		c++;

	}


	// Init

	const n_type_gfx bitmap_sx = N_BMP_SX( &n_pentrainer_bmp_data );
	const n_type_gfx bitmap_sy = N_BMP_SY( &n_pentrainer_bmp_data );

	const n_type_gfx  z          = n_pentrainer_zoom_get( n_pentrainer_zoom );
	const n_bool      z_out      = n_pentrainer_is_zoom_out( n_pentrainer_zoom );
	const n_type_real grid_blend = 0.33;


	// Window and Canvas

	n_type_gfx canvas_ox = 0;
	n_type_gfx canvas_oy = 0;

	n_pentrainer_margin_get( &canvas_ox, &canvas_oy );

	static n_type_gfx canvas_sx = 0;
	static n_type_gfx canvas_sy = 0;

	if ( mode & N_PENTRAINER_REFRESH_WINDOW )
	{

		int nwinset = N_WIN_SET_CLIPPING | N_WIN_SET_SCROLLBAR;

		static n_bool is_first = n_true;
		if ( is_first )
		{
			is_first = n_false;
			nwinset |= N_WIN_SET_CENTERING;
		}

		n_type_gfx sx = bitmap_sx;
		n_type_gfx sy = bitmap_sy;

		n_pentrainer_zoom_bitmap2canvas( NULL, NULL, &sx, &sy );

		sx += ( canvas_ox * 2 );
		sy += ( canvas_oy * 2 );

		n_win_set( n_pentrainer_hwnd_main, &nwin_main, sx,sy, nwinset );


		canvas_sx = nwin_main.csx;// - ( canvas_ox * 2 );
		canvas_sy = nwin_main.csy;// - ( canvas_oy * 2 );


		static n_type_gfx psx = 0;
		static n_type_gfx psy = 0;

		if (
			( ( psx != sx )||( psy != sy ) )
			||
			( ( nwin_main.rcsx != canvas_sx )||( nwin_main.rcsy != canvas_sy ) )
		)
		{

			psx = sx;
			psy = sy;


//n_bmp_new_fast( &n_pentrainer_bmp_dbuf, canvas_sx, canvas_sy );

			n_type_gfx dbuf_sx = canvas_sx;
			n_type_gfx dbuf_sy = canvas_sy;

			n_gdi_dibsection_init( &n_pentrainer_dibsection, &n_pentrainer_bmp_dbuf, n_pentrainer_hwnd_main, NULL, dbuf_sx,dbuf_sy );
			n_bmp_flush( &n_pentrainer_bmp_dbuf, n_pentrainer_canvas_color );

#ifdef _H_NONNON_WIN32_GAME_DIRECT2D
			if ( n_direct2d_is_on() )
			{
//n_win_hwndprintf_literal( n_pentrainer_hwnd_main, "Direct2D1", 0 );
				n_direct2d_make( n_pentrainer_hwnd_main, N_BMP_PTR( &n_pentrainer_bmp_dbuf ), canvas_sx,canvas_sy );
			}
#endif // #ifdef _H_NONNON_WIN32_GAME_DIRECT2D

		}

	}


	{

		n_type_gfx scr_fx = nwin_main.scrollx;
		n_type_gfx scr_fy = nwin_main.scrolly;
		n_type_gfx scr_tx = nwin_main.scrollx + canvas_sx;
		n_type_gfx scr_ty = nwin_main.scrolly + canvas_sy;

		n_pentrainer_zoom_canvas2bitmap( &scr_fx, &scr_fy, &scr_tx, &scr_ty );

		fx = n_posix_max_n_type_gfx( fx, scr_fx );
		fy = n_posix_max_n_type_gfx( fy, scr_fy );
		tx = n_posix_min_n_type_gfx( tx, scr_tx );
		ty = n_posix_min_n_type_gfx( ty, scr_ty );

		// [!] : for modulo

		tx = n_posix_min_n_type_gfx( tx + 1, bitmap_sx );
		ty = n_posix_min_n_type_gfx( ty + 1, bitmap_sy );

	}


	if ( z_out )
	{

		fx -= fx % z;
		fy -= fy % z;
		tx += z - ( tx % z );
		ty += z - ( ty % z );

	}


	n_type_gfx frame_size = 1;
	if ( z_out ) { frame_size = z; }

	fx = n_posix_max_n_type_gfx( fx - frame_size,         0 );
	fy = n_posix_max_n_type_gfx( fy - frame_size,         0 );
	tx = n_posix_min_n_type_gfx( tx + frame_size, bitmap_sx );
	ty = n_posix_min_n_type_gfx( ty + frame_size, bitmap_sy );


	// Clip

	if ( fx >= tx ) { return; }
	if ( fy >= ty ) { return; }

//n_win_hwndprintf_literal( n_pentrainer_hwnd_main, "%d %d %d %d", fx, fy, tx, ty );return;

	fx = n_posix_min_n_type_gfx( n_posix_max_n_type_gfx( 0, fx ), bitmap_sx );
	fy = n_posix_min_n_type_gfx( n_posix_max_n_type_gfx( 0, fy ), bitmap_sy );
	tx = n_posix_min_n_type_gfx( n_posix_max_n_type_gfx( 0, tx ), bitmap_sx );
	ty = n_posix_min_n_type_gfx( n_posix_max_n_type_gfx( 0, ty ), bitmap_sy );

//n_win_hwndprintf_literal( n_pentrainer_hwnd_main, "%d %d %d %d", fx, fy, tx, ty );return;


	{ // Redraw


	if ( debug_benchmark ) { tick = n_posix_tickcount(); }


	// Zoom

	n_type_gfx bitmap_z = 1;
	n_type_gfx canvas_z = z;

	if ( z_out )
	{
		bitmap_z = z;
		canvas_z = 1;
	}


	n_type_gfx bitmap_fx = fx;
	n_type_gfx bitmap_fy = fy;
	n_type_gfx bitmap_tx = tx;
	n_type_gfx bitmap_ty = ty;
	n_type_gfx canvas_fx = fx;
	n_type_gfx canvas_fy = fy;

	n_pentrainer_zoom_bitmap2canvas( &canvas_fx, &canvas_fy, NULL, NULL );

	canvas_fx -= nwin_main.scrollx;
	canvas_fy -= nwin_main.scrolly;

	canvas_fx += canvas_ox;
	canvas_fy += canvas_oy;


	// [!] : this position is important

	n_type_gfx redraw_x  = canvas_fx;
	n_type_gfx redraw_y  = canvas_fy;
	n_type_gfx redraw_sx = ( tx - fx ) * canvas_z;
	n_type_gfx redraw_sy = ( ty - fy ) * canvas_z;

	redraw_x  -= canvas_ox;
	redraw_y  -= canvas_oy;
	redraw_sx += canvas_ox * 2;
	redraw_sy += canvas_oy * 2;

	if ( redraw_x < 0 ) { redraw_sx += redraw_x; redraw_x = 0; }
	if ( redraw_y < 0 ) { redraw_sy += redraw_y; redraw_y = 0; }

//n_bmp_box( &n_pentrainer_bmp_dbuf, redraw_x, redraw_y, redraw_sx, redraw_sy, n_bmp_black );
//redraw_x = redraw_y = 0;
//redraw_sx = canvas_sx; redraw_sy = canvas_sy;


	// Grid

	n_type_gfx grid_center_fx = 0;
	n_type_gfx grid_center_fy = 0;
	n_type_gfx grid_center_tx = 0;
	n_type_gfx grid_center_ty = 0;
	n_type_gfx grid_unit      = 0;

	if ( n_pentrainer_grid_onoff )
	{

		// Center Line

		grid_center_fx = grid_center_tx = ( bitmap_sx / 2 );
		grid_center_fy = grid_center_ty = ( bitmap_sy / 2 );

		grid_center_fx -= ( 0 == ( bitmap_sx % 2 ) );
		grid_center_fy -= ( 0 == ( bitmap_sy % 2 ) );

		n_pentrainer_zoom_bitmap2canvas( &grid_center_fx, &grid_center_fy, &grid_center_tx, &grid_center_ty );

		grid_center_fx -= nwin_main.scrollx;
		grid_center_fy -= nwin_main.scrolly;
		grid_center_tx -= nwin_main.scrollx;
		grid_center_ty -= nwin_main.scrolly;

		grid_center_fx += canvas_ox;
		grid_center_fy += canvas_oy;
		grid_center_tx += canvas_ox;
		grid_center_ty += canvas_oy;


		// Guide Line

		const n_type_gfx unit     = n_posix_min_n_type_gfx( bitmap_sx, bitmap_sy );
		const n_type_gfx unit_min = N_PENTRAINER_GRID_UNIT;//8;

		grid_unit = n_posix_max_n_type_gfx( unit_min, unit / unit_min );
		n_pentrainer_zoom_bitmap2canvas( &grid_unit, NULL, NULL, NULL );
		grid_unit = n_posix_max_n_type_gfx( 1, grid_unit );

//n_win_hwndprintf_literal( n_pentrainer_hwnd_main, "%d", grid_unit );
	}


	// Combined Scale Copy


	n_type_gfx bitmap_start_x = bitmap_fx;
	n_type_gfx canvas_start_x = canvas_fx;


	n_posix_loop
	{//break;

//if ( bitmap_fx <          0 ) { n_posix_debug_literal( "L" ); break; }
//if ( bitmap_fy <          0 ) { n_posix_debug_literal( "U" ); break; }
//if ( bitmap_fx >= bitmap_tx ) { n_posix_debug_literal( "R" ); break; }
//if ( bitmap_fy >= bitmap_ty ) { n_posix_debug_literal( "D" ); break; }


		u32 color = 0;

		if (
			( NULL != N_BMP_PTR( &n_pentrainer_bmp_data ) )
			&&
			( NULL != N_BMP_PTR( &n_pentrainer_bmp_over ) )
			&&
			( n_bmp_ptr_is_accessible( &n_pentrainer_bmp_data, bitmap_fx, bitmap_fy ) )
		)
		{
			//n_bmp_ptr_get_fast( &n_pentrainer_bmp_data, bitmap_fx, bitmap_fy, &color );

			n_type_gfx x = bitmap_fx;
			n_type_gfx y = bitmap_fy;
			u32 c = n_bmp_composite_pixel( &n_pentrainer_bmp_over, &n_pentrainer_bmp_data, x,y, x,y, n_false,n_false, n_true, 0.0 );

			color = c;
		}


		n_bool contour_onoff = n_false;
		u32    contour_color = color;


		if ( n_pentrainer_pixelgrid_onoff )
		{

			u32 c = n_pentrainer_pixelgrid_pixel( contour_color );

			contour_onoff = n_true;
			contour_color = n_bmp_blend_pixel( contour_color, c, grid_blend );

		}


		if ( n_pentrainer_grid_onoff )
		{
//if ( grid_unit <= 0 ) { break; }

			POINT vert_pt = { canvas_fx, 0 };
			RECT  vert_rc = { grid_center_fx, 0, grid_center_tx + 1, 1 };

			POINT horz_pt = { canvas_fy, 0 };
			RECT  horz_rc = { grid_center_fy, 0, grid_center_ty + 1, 1 };

			if (
				( PtInRect( &vert_rc, vert_pt ) )
				||
				( PtInRect( &horz_rc, horz_pt ) )
			)
			{

				u32 c = n_bmp_rgb( 255,0,128 );

				contour_onoff = n_true;
				contour_color = n_bmp_blend_pixel( contour_color, c, grid_blend );

			} else {

				n_type_gfx gfx = abs( canvas_fx - grid_center_fx ) % grid_unit;
				n_type_gfx gtx = abs( canvas_fx - grid_center_tx ) % grid_unit;

				n_bool gfx_is_frame = ( ( gfx == 0 )||( gfx == ( grid_unit - canvas_z ) ) );
				n_bool gtx_is_frame = ( ( gtx == 0 )||( gtx == ( grid_unit - canvas_z ) ) );

				n_type_gfx gfy = abs( canvas_fy - grid_center_fy ) % grid_unit;
				n_type_gfx gty = abs( canvas_fy - grid_center_ty ) % grid_unit;

				n_bool gfy_is_frame = ( ( gfy == 0 )||( gfy == ( grid_unit - canvas_z ) ) );
				n_bool gty_is_frame = ( ( gty == 0 )||( gty == ( grid_unit - canvas_z ) ) );

				if (
					( ( canvas_fx <= grid_center_fx )&&( gfx_is_frame ) )
					||
					( ( canvas_fx >= grid_center_tx )&&( gtx_is_frame ) )
					||
					( ( canvas_fy <= grid_center_fy )&&( gfy_is_frame ) )
					||
					( ( canvas_fy >= grid_center_ty )&&( gty_is_frame ) )
				)
				{

					u32 c = n_bmp_rgb( 0,128,255 );

					contour_onoff = n_true;
					contour_color = n_bmp_blend_pixel( contour_color, c, grid_blend );

				}

			}

		}


		// [!] : n_bmp_box() : 2x slower than below loop

		//n_bmp_box( &n_pentrainer_bmp_dbuf, canvas_fx, canvas_fy, canvas_z, canvas_z, color_new );

		n_type_gfx zoom_fx = n_posix_minmax( 0, canvas_sx - 1, canvas_fx );
		n_type_gfx zoom_fy = n_posix_minmax( 0, canvas_sy - 1, canvas_fy );
		n_type_gfx zoom_tx = n_posix_minmax( 0, canvas_sx - 0, canvas_fx + canvas_z );
		n_type_gfx zoom_ty = n_posix_minmax( 0, canvas_sy - 0, canvas_fy + canvas_z );

		n_type_gfx zoom_start_x = zoom_fx;
		n_type_gfx zoom_start_y = zoom_fy;

		if ( NULL != N_BMP_PTR( &n_pentrainer_bmp_dbuf ) )
		{

			n_posix_loop
			{

				u32 clr = color;

				if (
					( contour_onoff )
					&&
					(
						( zoom_fx == zoom_start_x )||( zoom_fx == ( zoom_tx - 1 ) )
						||
						( zoom_fy == zoom_start_y )||( zoom_fy == ( zoom_ty - 1 ) )
					)
				)
				{
					//if ( n_bmp_moire_detect( zoom_fx, zoom_fy, 1 ) )
					//{
						clr = contour_color;
					//} else {
						//clr = ~color;
					//}
				}


				n_bmp_ptr_set( &n_pentrainer_bmp_dbuf, zoom_fx, zoom_fy, clr );


				zoom_fx++;
				if ( zoom_fx >= zoom_tx )
				{

					zoom_fx = zoom_start_x;

					zoom_fy++;
					if ( zoom_fy >= zoom_ty ) { break; }
				}
			}

		}


		bitmap_fx += bitmap_z;
		canvas_fx += canvas_z;

		if ( ( bitmap_fx >= bitmap_tx )||( canvas_fx >= canvas_sx ) )
		{

			bitmap_fx = bitmap_start_x;
			canvas_fx = canvas_start_x;


			bitmap_fy += bitmap_z;
			canvas_fy += canvas_z;

			if ( ( bitmap_fy >= bitmap_ty )||( canvas_fy >= canvas_sy ) ) { break; }
		}
	}


	if ( background_onoff )
	{

		n_bmp_box( &n_pentrainer_bmp_dbuf, 0,                    0, canvas_sx, canvas_oy, n_pentrainer_canvas_color );
		n_bmp_box( &n_pentrainer_bmp_dbuf, 0,canvas_sy - canvas_oy, canvas_sx, canvas_oy, n_pentrainer_canvas_color );
		n_bmp_box( &n_pentrainer_bmp_dbuf, 0,                    0, canvas_ox, canvas_sy, n_pentrainer_canvas_color );
		n_bmp_box( &n_pentrainer_bmp_dbuf, canvas_sx - canvas_ox,0, canvas_ox, canvas_sy, n_pentrainer_canvas_color );

		if ( n_pentrainer_frame_onoff )
		{

			const COLORREF fg = n_gdi_systemcolor( COLOR_HIGHLIGHT     );
			const COLORREF bg = n_gdi_systemcolor( COLOR_HIGHLIGHTTEXT );

			n_type_gfx m  = canvas_ox;
			n_type_gfx x  = 0;
			n_type_gfx y  = 0;
			n_type_gfx sx = bitmap_sx;
			n_type_gfx sy = bitmap_sy;

			n_pentrainer_zoom_bitmap2canvas( &x, &y, &sx, &sy );

			x = -nwin_main.scrollx + m;
			y = -nwin_main.scrolly + m;


			n_bmp_line_dot( &n_pentrainer_bmp_dbuf, x, y - 1, x + sx, y - 1, fg, 1 );
			n_bmp_line_dot( &n_pentrainer_bmp_dbuf, x, y - 1, x + sx, y - 1, bg, 2 );

			n_bmp_line_dot( &n_pentrainer_bmp_dbuf, x, y + sy, x + sx, y + sy, fg, 1 );
			n_bmp_line_dot( &n_pentrainer_bmp_dbuf, x, y + sy, x + sx, y + sy, bg, 2 );

			n_bmp_line_dot( &n_pentrainer_bmp_dbuf, x - 1, y, x - 1, y + sy, fg, 1 );
			n_bmp_line_dot( &n_pentrainer_bmp_dbuf, x - 1, y, x - 1, y + sy, bg, 2 );

			n_bmp_line_dot( &n_pentrainer_bmp_dbuf, x + sx, y, x + sx, y + sy, fg, 1 );
			n_bmp_line_dot( &n_pentrainer_bmp_dbuf, x + sx, y, x + sx, y + sy, bg, 2 );

		}

	}


	// UI

	n_pentrainer_ui_draw();


	// Draw


#ifdef _H_NONNON_WIN32_GAME_DIRECT2D

	if ( n_direct2d_is_on() )
	{
//n_win_hwndprintf_literal( n_pentrainer_hwnd_main, "n_direct2d_is_on()" );

		n_direct2d_copy( n_pentrainer_hwnd_main, N_BMP_PTR( &n_pentrainer_bmp_dbuf ),canvas_sx,canvas_sy, 0,0 );
		n_direct2d_draw( n_pentrainer_hwnd_main, 0,0, canvas_sx,canvas_sy );

	} else

#endif // #ifdef _H_NONNON_WIN32_GAME_DIRECT2D

	if ( n_gdi_draw_onoff )
	{
//n_win_hwndprintf_literal( n_pentrainer_hwnd_main, "n_gdi_draw_onoff" );

		n_gdi_bitmap_draw
		(
			n_pentrainer_hwnd_main, &n_pentrainer_bmp_dbuf,
			redraw_x, redraw_y, redraw_sx, redraw_sy,
			redraw_x, redraw_y
		);

	}


	if ( debug_benchmark ) { n_win_hwndprintf_literal( n_pentrainer_hwnd_main, "%d", (int) n_posix_tickcount() - tick ); }


	} // Redraw


	return;
}

