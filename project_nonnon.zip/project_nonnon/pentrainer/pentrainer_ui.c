// Nonnon Pen Trainer
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Partial File




#define N_PENTRAINER_UI_GUI_MAX ( 4 )


#define N_PENTRAINER_UI_ID_CLEAR    ( 0 )
#define N_PENTRAINER_UI_ID_BACK     ( 1 )
#define N_PENTRAINER_UI_ID_FORWARD  ( 2 )
#define N_PENTRAINER_UI_ID_CONFIG   ( 3 )

#define N_PENTRAINER_UI_BTN_CLEAR   n_pentrainer_ui_bmp[ N_PENTRAINER_UI_ID_CLEAR   ]
#define N_PENTRAINER_UI_BTN_BACK    n_pentrainer_ui_bmp[ N_PENTRAINER_UI_ID_BACK    ]
#define N_PENTRAINER_UI_BTN_FORWARD n_pentrainer_ui_bmp[ N_PENTRAINER_UI_ID_FORWARD ]
#define N_PENTRAINER_UI_BTN_CONFIG  n_pentrainer_ui_bmp[ N_PENTRAINER_UI_ID_CONFIG  ]

static n_bmp  n_pentrainer_ui_bmp[ N_PENTRAINER_UI_GUI_MAX ];
static n_bool n_pentrainer_ui_prs[ N_PENTRAINER_UI_GUI_MAX ];
static n_bool n_pentrainer_ui_hvr[ N_PENTRAINER_UI_GUI_MAX ];




void
n_pentrainer_ui_exit( void )
{

	n_bmp_free( &N_PENTRAINER_UI_BTN_CLEAR   );
	n_bmp_free( &N_PENTRAINER_UI_BTN_BACK    );
	n_bmp_free( &N_PENTRAINER_UI_BTN_FORWARD );
	n_bmp_free( &N_PENTRAINER_UI_BTN_CONFIG  );

	return;
}

void
n_pentrainer_ui_gdi_bmp( n_bmp *bmp, int icon_index )
{

	n_bool is_hovered = n_false;
	n_bool is_pressed = n_false;

	if ( bmp == &N_PENTRAINER_UI_BTN_CLEAR   )
	{
		if ( n_pentrainer_ui_prs[ N_PENTRAINER_UI_ID_CLEAR   ] ) { is_pressed = n_true; } else
		if ( n_pentrainer_ui_hvr[ N_PENTRAINER_UI_ID_CLEAR   ] ) { is_hovered = n_true; }
	} else
	if ( bmp == &N_PENTRAINER_UI_BTN_BACK    )
	{
		if ( n_pentrainer_ui_prs[ N_PENTRAINER_UI_ID_BACK    ] ) { is_pressed = n_true; } else
		if ( n_pentrainer_ui_hvr[ N_PENTRAINER_UI_ID_BACK    ] ) { is_hovered = n_true; }
	} else
	if ( bmp == &N_PENTRAINER_UI_BTN_FORWARD )
	{
		if ( n_pentrainer_ui_prs[ N_PENTRAINER_UI_ID_FORWARD ] ) { is_pressed = n_true; } else
		if ( n_pentrainer_ui_hvr[ N_PENTRAINER_UI_ID_FORWARD ] ) { is_hovered = n_true; }
	} else
	if ( bmp == &N_PENTRAINER_UI_BTN_CONFIG  )
	{
		if ( n_pentrainer_ui_prs[ N_PENTRAINER_UI_ID_CONFIG  ] ) { is_pressed = n_true; } else
		if ( n_pentrainer_ui_hvr[ N_PENTRAINER_UI_ID_CONFIG  ] ) { is_hovered = n_true; }
	}// else


	n_posix_char *exename = n_win_exepath_new();


	n_gdi gdi; n_gdi_zero( &gdi );


	gdi.sx                  = n_pentrainer_std_icon_size;
	gdi.sy                  = n_pentrainer_std_icon_size;
	gdi.scale               = N_GDI_SCALE_AUTO;
	gdi.base_unit           = 0;

	if ( n_win_darkmode_onoff )
	{

		if ( n_win_fluent_ui_onoff )
		{

			if ( ( is_hovered )||( is_pressed ) )
			{
				gdi.base_color_fg      = n_win_dwm_windowcolor_arranged();
				gdi.frame_corner_color = n_bmp_alpha_invisible_pixel( gdi.base_color_fg );
				gdi.base_color_bg      = n_win_darkmode_systemcolor_colorref2argb_ui( COLOR_BTNFACE );
				gdi.base_color_bg      = n_bmp_blend_pixel( gdi.base_color_bg, n_bmp_white, 0.5 );
			} else {
				gdi.base_color_fg      = n_win_darkmode_systemcolor_colorref2argb_ui( COLOR_BTNFACE );
				gdi.base_color_bg      = n_bmp_black_invisible;
			}

			gdi.frame_style = N_GDI_FRAME_FLUENT_BTN;

		} else {

			u32 color = n_win_darkmode_systemcolor_colorref2argb_ui( COLOR_3DDKSHADOW );

			if ( ( is_hovered )||( is_pressed ) )
			{
				color = n_bmp_white;
			}

			gdi.base_color_fg = color;
			gdi.base_color_bg = color;

			gdi.frame_style   = N_GDI_FRAME_SIMPLE;

		}

		if ( is_pressed )
		{
			gdi.style = N_GDI_PRESSED;
		}

	} else {

		u32 fg = n_bmp_white_invisible;
		if ( is_hovered )
		{
			fg = n_bmp_rgb( 229,151,0 );
		}
		gdi.base_color_fg = fg;

		gdi.base_color_bg = n_bmp_rgb( 236,233,216 );
		gdi.base_style    = N_GDI_BASE_LUNA;

		if ( is_pressed )
		{
			gdi.base_style = N_GDI_BASE_LUNA_PRESS;
		}

		gdi.frame_style = N_GDI_FRAME_LUNA;

	}

	gdi.icon       = exename;
	gdi.icon_index = icon_index;
	gdi.icon_style = N_GDI_ICON_RESOURCE;


	n_bmp_free( bmp );
	n_gdi_bmp( &gdi, bmp );


	n_string_free( exename );


	return;
}
void
n_pentrainer_ui_init( HWND hwnd )
{

	n_pentrainer_character_min( n_pentrainer_mode, n_pentrainer_char );
	n_pentrainer_character_move( 0 );


	n_pentrainer_ui_gdi_bmp( &N_PENTRAINER_UI_BTN_BACK   , N_APPS_ICON_OFFSET_PENTRAINER + 1 );
	n_pentrainer_ui_gdi_bmp( &N_PENTRAINER_UI_BTN_CLEAR  , N_APPS_ICON_OFFSET_PENTRAINER + 2 );
	n_pentrainer_ui_gdi_bmp( &N_PENTRAINER_UI_BTN_FORWARD, N_APPS_ICON_OFFSET_PENTRAINER + 3 );
	n_pentrainer_ui_gdi_bmp( &N_PENTRAINER_UI_BTN_CONFIG , N_APPS_ICON_OFFSET_PENTRAINER + 4 );


	int i = 0;
	n_posix_loop
	{
		n_pentrainer_ui_prs[ i ] = n_false;
		n_pentrainer_ui_hvr[ i ] = n_false;

		i++; 
		if ( i >= N_PENTRAINER_UI_GUI_MAX ) { break; }
	}


	return;
}

void
n_pentrainer_ui_draw( void )
{

	n_type_gfx size     = N_BMP_SX( &n_pentrainer_bmp_dbuf );
	n_type_gfx ico      = n_pentrainer_std_icon_size;
	n_type_gfx center_x = size / 2;
	n_type_gfx ico_half = ico  / 2;

	n_type_gfx x = center_x - ico_half;
	n_bmp_transcopy( &N_PENTRAINER_UI_BTN_CLEAR  , &n_pentrainer_bmp_dbuf, 0,0,ico,ico, x      ,0 );
	n_bmp_transcopy( &N_PENTRAINER_UI_BTN_BACK   , &n_pentrainer_bmp_dbuf, 0,0,ico,ico, x - ico,0 );
	n_bmp_transcopy( &N_PENTRAINER_UI_BTN_FORWARD, &n_pentrainer_bmp_dbuf, 0,0,ico,ico, x + ico,0 );

	n_type_gfx c = 0;
	if ( n_win_is_lefthanded() ) { c = size - ico; }
	n_bmp_transcopy( &N_PENTRAINER_UI_BTN_CONFIG , &n_pentrainer_bmp_dbuf, 0,0,ico,ico,       c,0 );


	return;
}

n_bool
n_pentrainer_ui_is_hovered( n_bmp *target )
{

	n_type_gfx size     = N_BMP_SX( &n_pentrainer_bmp_dbuf );
	n_type_gfx ico      = n_pentrainer_std_icon_size;
	n_type_gfx center_x = size / 2;
	n_type_gfx ico_half = ico  / 2;

	n_type_gfx x = center_x - ico_half;

	n_type_gfx fx = 0;
	n_type_gfx fy = 0;

	if ( target == &N_PENTRAINER_UI_BTN_CLEAR   )
	{
		fx = x;
	} else
	if ( target == &N_PENTRAINER_UI_BTN_BACK    )
	{
		fx = x - ico;
	} else
	if ( target == &N_PENTRAINER_UI_BTN_FORWARD )
	{
		fx = x + ico;
	} else
	if ( target == &N_PENTRAINER_UI_BTN_CONFIG  )
	{
		if ( n_win_is_lefthanded() ) { fx = size - ico; } else { fx = 0; }
	} else {
		return n_false;
	}


	return n_win_is_hovered_offset( n_pentrainer_hwnd_main, fx,fy,ico,ico );
}

void
n_pentrainer_ui_hover( n_bmp *bmp, int id, int rsrc_id )
{

	n_bool redraw = n_false;

	if ( n_pentrainer_ui_is_hovered( bmp ) )
	{
		if ( n_false == n_pentrainer_ui_hvr[ id ] )
		{
			n_pentrainer_ui_hvr[ id ] =  n_true;
			redraw = n_true;
		}
	} else {
		if ( n_false != n_pentrainer_ui_hvr[ id ] )
		{
			n_pentrainer_ui_hvr[ id ] = n_false;
			redraw = n_true;
		}
	}

	if ( redraw )
	{
		n_pentrainer_ui_gdi_bmp( bmp, N_APPS_ICON_OFFSET_PENTRAINER + rsrc_id );
		n_pentrainer_refresh_client();
	}


	return;
}

void
n_pentrainer_ui_press( n_bmp *bmp, int id, int rsrc_id )
{

	n_bool redraw = n_false;

	if ( n_pentrainer_ui_is_hovered( bmp ) )
	{
		if ( n_false == n_pentrainer_ui_prs[ id ] )
		{
			n_pentrainer_ui_prs[ id ] =  n_true;
			redraw = n_true;
		}
	} else {
		if ( n_false != n_pentrainer_ui_prs[ id ] )
		{
			n_pentrainer_ui_prs[ id ] = n_false;
			redraw = n_true;
		}
	}

	if ( redraw )
	{
		n_pentrainer_ui_gdi_bmp( bmp, N_APPS_ICON_OFFSET_PENTRAINER + rsrc_id );
		n_pentrainer_refresh_client();
	}


	return;
}

void
n_pentrainer_ui_neutral( n_bmp *bmp, int id, int rsrc_id )
{

	n_bool remake = ( ( n_pentrainer_ui_prs[ id ] )||( n_pentrainer_ui_hvr[ id ] ) );

	if ( remake )
	{
		n_pentrainer_ui_prs[ id ] = n_false;
		n_pentrainer_ui_hvr[ id ] = n_false;

		n_pentrainer_ui_gdi_bmp( bmp, N_APPS_ICON_OFFSET_PENTRAINER + rsrc_id );

		n_pentrainer_refresh_client();
	}


	return;
}

n_bool
n_pentrainer_ui_unpress( n_bmp *bmp, int id, int rsrc_id )
{

	if ( n_pentrainer_ui_prs[ id ] )
	{
		n_pentrainer_ui_neutral( bmp, id, rsrc_id );

		n_pentrainer_ui_hover( bmp, id, rsrc_id );

		return n_true;
	}

	return n_false;
}

void
n_pentrainer_ui_proc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	switch( msg ) {


	case WM_MOUSEMOVE :

		n_win_on_mousemove( hwnd );

		n_pentrainer_ui_hover( &N_PENTRAINER_UI_BTN_CLEAR  , N_PENTRAINER_UI_ID_CLEAR  , 2 );
		n_pentrainer_ui_hover( &N_PENTRAINER_UI_BTN_BACK   , N_PENTRAINER_UI_ID_BACK   , 1 );
		n_pentrainer_ui_hover( &N_PENTRAINER_UI_BTN_FORWARD, N_PENTRAINER_UI_ID_FORWARD, 3 );
		n_pentrainer_ui_hover( &N_PENTRAINER_UI_BTN_CONFIG , N_PENTRAINER_UI_ID_CONFIG , 4 );

	break;

	case WM_MOUSEHOVER :
//n_win_hwndprintf_literal( hwnd, " WM_MOUSEHOVER " );
	break;

	case WM_MOUSELEAVE :
//n_win_hwndprintf_literal( hwnd, " WM_MOUSELEAVE " );

		n_pentrainer_ui_neutral( &N_PENTRAINER_UI_BTN_CLEAR  , N_PENTRAINER_UI_ID_CLEAR  , 2 );
		n_pentrainer_ui_neutral( &N_PENTRAINER_UI_BTN_BACK   , N_PENTRAINER_UI_ID_BACK   , 1 );
		n_pentrainer_ui_neutral( &N_PENTRAINER_UI_BTN_FORWARD, N_PENTRAINER_UI_ID_FORWARD, 3 );
		n_pentrainer_ui_neutral( &N_PENTRAINER_UI_BTN_CONFIG , N_PENTRAINER_UI_ID_CONFIG , 4 );

	break;

	case WM_LBUTTONUP :

		if ( n_pentrainer_ui_unpress( &N_PENTRAINER_UI_BTN_CLEAR  , N_PENTRAINER_UI_ID_CLEAR  , 2 ) )
		{
			n_bmp_flush( &n_pentrainer_bmp_data, n_pentrainer_color_bg );
			n_pentrainer_refresh_client();
		} else
		if ( n_pentrainer_ui_unpress( &N_PENTRAINER_UI_BTN_BACK   , N_PENTRAINER_UI_ID_BACK   , 1 ) )
		{
			n_pentrainer_character_move( -1 );
		} else
		if ( n_pentrainer_ui_unpress( &N_PENTRAINER_UI_BTN_FORWARD, N_PENTRAINER_UI_ID_FORWARD, 3 ) )
		{
			n_pentrainer_character_move(  1 );
		} else
		if ( n_pentrainer_ui_unpress( &N_PENTRAINER_UI_BTN_CONFIG , N_PENTRAINER_UI_ID_CONFIG , 4 ) )
		{
			static HWND hpopup = NULL;
			n_win_gui( hwnd, WINDOW, n_pentrainer_config_wndproc, &hpopup );
		}// else

	break;

	case WM_LBUTTONDOWN :

		n_pentrainer_ui_press( &N_PENTRAINER_UI_BTN_CLEAR  , N_PENTRAINER_UI_ID_CLEAR  , 2 );
		n_pentrainer_ui_press( &N_PENTRAINER_UI_BTN_BACK   , N_PENTRAINER_UI_ID_BACK   , 1 );
		n_pentrainer_ui_press( &N_PENTRAINER_UI_BTN_FORWARD, N_PENTRAINER_UI_ID_FORWARD, 3 );
		n_pentrainer_ui_press( &N_PENTRAINER_UI_BTN_CONFIG , N_PENTRAINER_UI_ID_CONFIG , 4 );

	break;


	case WM_KEYDOWN :

		if ( wparam == VK_LEFT )
		{
			n_pentrainer_character_move( -1 );
		} else
		if ( wparam == VK_RIGHT )
		{
			n_pentrainer_character_move(  1 );
		}
/*
		if ( wparam == VK_F1 )
		{
			static HWND hpopup = NULL;
			n_win_gui( hwnd, WINDOW, n_pentrainer_config_wndproc, &hpopup );
		}
*/
	break;


	} // switch


	return;
}

